import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/routing/route_names.dart';
import '../../../../core/utils/validators.dart';
import '../../../../core/widgets/app_snackbar.dart';
import '../../../../core/widgets/primary_button.dart';
import '../providers/auth_providers.dart';
import '../widgets/auth_text_field.dart';
import '../widgets/google_sign_in_button.dart';

class RegisterScreen extends ConsumerStatefulWidget {
  const RegisterScreen({super.key});

  @override
  ConsumerState<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends ConsumerState<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final controller = ref.read(authControllerProvider.notifier);
    final success = await controller.signUp(
      name: _nameController.text.trim(),
      email: _emailController.text.trim(),
      password: _passwordController.text,
    );
    if (success && mounted) {
      AppSnackbar.success(
        context,
        'Account created — ₹1,00,000 virtual balance added!',
      );
      // Router redirect will bounce unverified users to /verify-email.
    } else if (!success && mounted) {
      final error = ref.read(authControllerProvider).errorMessage;
      if (error != null) AppSnackbar.error(context, error);
    }
  }

  Future<void> _submitGoogle() async {
    final controller = ref.read(authControllerProvider.notifier);
    final success = await controller.signInWithGoogle();
    if (!success && mounted) {
      final error = ref.read(authControllerProvider).errorMessage;
      if (error != null) AppSnackbar.error(context, error);
    }
  }

  @override
  Widget build(BuildContext context) {
    final actionState = ref.watch(authControllerProvider);
    final theme = Theme.of(context);

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: AppDimens.space24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: AppDimens.space32),
                Text(AppStrings.createAccount, style: theme.textTheme.headlineMedium)
                    .animate()
                    .fadeIn(duration: 350.ms),
                const SizedBox(height: AppDimens.space8),
                Text(
                  AppStrings.registerSubtitle,
                  style: theme.textTheme.bodyMedium,
                ).animate().fadeIn(delay: 100.ms, duration: 350.ms),
                const SizedBox(height: AppDimens.space12),

                // Virtual balance highlight — reinforces this is a
                // risk-free education product right at sign-up.
                Container(
                  padding: const EdgeInsets.all(AppDimens.space16),
                  decoration: BoxDecoration(
                    color: AppColors.secondary.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(AppDimens.radiusMedium),
                    border: Border.all(
                      color: AppColors.secondary.withValues(alpha: 0.3),
                    ),
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.account_balance_wallet_rounded,
                        color: AppColors.secondary,
                        size: AppDimens.iconMedium,
                      ),
                      const SizedBox(width: AppDimens.space12),
                      Expanded(
                        child: Text(
                          'Get ₹1,00,000 in virtual funds instantly, free',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ).animate().fadeIn(delay: 150.ms, duration: 350.ms),

                const SizedBox(height: AppDimens.space24),
                AuthTextField(
                  label: 'Full Name',
                  hint: 'Your name',
                  controller: _nameController,
                  prefixIcon: Icons.person_outline_rounded,
                  validator: Validators.fullName,
                ),
                const SizedBox(height: AppDimens.space20),
                AuthTextField(
                  label: 'Email',
                  hint: 'you@example.com',
                  controller: _emailController,
                  prefixIcon: Icons.mail_outline_rounded,
                  keyboardType: TextInputType.emailAddress,
                  validator: Validators.email,
                ),
                const SizedBox(height: AppDimens.space20),
                AuthTextField(
                  label: 'Password',
                  hint: 'At least 8 characters',
                  controller: _passwordController,
                  prefixIcon: Icons.lock_outline_rounded,
                  isPassword: true,
                  validator: Validators.password,
                ),
                const SizedBox(height: AppDimens.space20),
                AuthTextField(
                  label: 'Confirm Password',
                  hint: 'Re-enter your password',
                  controller: _confirmPasswordController,
                  prefixIcon: Icons.lock_outline_rounded,
                  isPassword: true,
                  textInputAction: TextInputAction.done,
                  validator: (v) =>
                      Validators.confirmPassword(v, _passwordController.text),
                  onSubmitted: (_) => _submit(),
                ),
                const SizedBox(height: AppDimens.space24),
                PrimaryButton(
                  label: 'Create Account',
                  isLoading: actionState.isLoading,
                  onPressed: _submit,
                ),
                const SizedBox(height: AppDimens.space20),
                Row(
                  children: [
                    Expanded(child: Divider(color: theme.dividerColor)),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppDimens.space12,
                      ),
                      child: Text('or', style: theme.textTheme.bodySmall),
                    ),
                    Expanded(child: Divider(color: theme.dividerColor)),
                  ],
                ),
                const SizedBox(height: AppDimens.space20),
                GoogleSignInButton(
                  onPressed: _submitGoogle,
                  isLoading: actionState.isLoading,
                ),
                const SizedBox(height: AppDimens.space24),
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Already have an account?', style: theme.textTheme.bodyMedium),
                      TextButton(
                        onPressed: () => context.push(RouteNames.login),
                        child: const Text('Log In'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: AppDimens.space8),
                Text(
                  AppStrings.noGuaranteeDisclaimer,
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodySmall,
                ),
                const SizedBox(height: AppDimens.space16),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
