import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_dimens.dart';
import '../../../challenges/presentation/providers/challenges_providers.dart';
import '../../../challenges/presentation/screens/challenges_screen.dart';
import '../../data/content/course_catalog.dart';
import '../../domain/entities/course_entity.dart';
import '../../domain/entities/course_progress_entity.dart';
import '../providers/learn_providers.dart';
import '../widgets/badge_grid.dart';
import '../widgets/course_card.dart';
import '../widgets/xp_header_card.dart';
import 'certificate_screen.dart';
import 'course_detail_screen.dart';

class LearnScreen extends ConsumerWidget {
  const LearnScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Checks + awards any newly-qualified badges from real progress.
    ref.watch(badgeAwardCheckerProvider);

    // Combined XP total (courses + claimed challenges) — see Phase 9 notes.
    final xpSummary = ref.watch(combinedXpSummaryProvider);
    final progressList = ref.watch(courseProgressProvider).value ?? [];
    final earnedBadgeIds = (ref.watch(earnedBadgesProvider).value ?? []).toSet();

    final progressByCourseId = <String, CourseProgressEntity>{
      for (final p in progressList) p.courseId: p,
    };

    return Scaffold(
      appBar: AppBar(
        title: const Text('Learn'),
        actions: [
          IconButton(
            icon: const Icon(Icons.emoji_events_outlined),
            tooltip: 'Challenges & Leaderboard',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const ChallengesScreen()),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(AppDimens.space16),
          children: [
            XpHeaderCard(summary: xpSummary),
            const SizedBox(height: AppDimens.space20),

            Text('Badges', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: AppDimens.space12),
            BadgeGrid(earnedBadgeIds: earnedBadgeIds),
            const SizedBox(height: AppDimens.space24),

            for (final level in CourseLevel.values) ...[
              _LevelSection(
                level: level,
                progressByCourseId: progressByCourseId,
              ),
              const SizedBox(height: AppDimens.space20),
            ],
          ],
        ),
      ),
    );
  }
}

class _LevelSection extends StatelessWidget {
  final CourseLevel level;
  final Map<String, CourseProgressEntity> progressByCourseId;

  const _LevelSection({required this.level, required this.progressByCourseId});

  @override
  Widget build(BuildContext context) {
    final courses = CourseCatalog.byLevel(level);
    final completedCount =
        courses.where((c) => progressByCourseId[c.id]?.isCompleted == true).length;
    final allComplete = completedCount == courses.length && courses.isNotEmpty;
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(level.label, style: theme.textTheme.titleMedium),
            const SizedBox(width: AppDimens.space8),
            Text(
              '$completedCount/${courses.length}',
              style: theme.textTheme.bodySmall,
            ),
            const Spacer(),
            if (allComplete)
              TextButton.icon(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => CertificateScreen(level: level),
                  ),
                ),
                icon: const Icon(Icons.workspace_premium_rounded, size: 16),
                label: const Text('Certificate'),
              ),
          ],
        ),
        const SizedBox(height: AppDimens.space12),
        for (final course in courses)
          CourseCard(
            course: course,
            isCompleted: progressByCourseId[course.id]?.isCompleted == true,
            bestQuizScore: progressByCourseId[course.id]?.bestQuizScorePercent,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => CourseDetailScreen(course: course)),
            ),
          ),
      ],
    );
  }
}
