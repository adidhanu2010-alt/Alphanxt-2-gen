import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../../core/constants/app_strings.dart';
import '../../domain/entities/leaderboard_entry_entity.dart';

class LeaderboardRemoteDataSource {
  final FirebaseFirestore _firestore;

  LeaderboardRemoteDataSource(this._firestore);

  CollectionReference<Map<String, dynamic>> get _ref =>
      _firestore.collection(AppStrings.collectionLeaderboard);

  Future<void> updateMyEntry({
    required String uid,
    required String displayName,
    String? photoUrl,
    required int totalXp,
    required double portfolioReturnPercent,
  }) {
    return _ref.doc(uid).set({
      'uid': uid,
      'displayName': displayName,
      'photoUrl': photoUrl,
      'totalXp': totalXp,
      'portfolioReturnPercent': portfolioReturnPercent,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<List<LeaderboardEntryEntity>> watchTopByXp({int limit = 50}) {
    return _ref
        .orderBy('totalXp', descending: true)
        .limit(limit)
        .snapshots()
        .map((snap) => snap.docs.map(_fromDoc).toList());
  }

  Stream<List<LeaderboardEntryEntity>> watchTopByReturns({int limit = 50}) {
    return _ref
        .orderBy('portfolioReturnPercent', descending: true)
        .limit(limit)
        .snapshots()
        .map((snap) => snap.docs.map(_fromDoc).toList());
  }

  LeaderboardEntryEntity _fromDoc(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data();
    return LeaderboardEntryEntity(
      uid: data['uid'] as String? ?? doc.id,
      displayName: data['displayName'] as String? ?? 'Trader',
      photoUrl: data['photoUrl'] as String?,
      totalXp: data['totalXp'] as int? ?? 0,
      portfolioReturnPercent: (data['portfolioReturnPercent'] as num?)?.toDouble() ?? 0,
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }
}
