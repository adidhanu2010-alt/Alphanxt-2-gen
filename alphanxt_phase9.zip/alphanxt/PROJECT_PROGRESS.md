# AlphaNXT — Project Progress

This file is updated after every phase. It is the single source of truth
for what's been built, what's in progress, and what's left.

## Phase Roadmap

- [x] **Phase 1 — Project Setup & Architecture Foundation** (COMPLETE)
- [x] **Phase 2 — Authentication** (COMPLETE)
- [x] **Phase 3 — Bottom Nav shell + Home screen** (COMPLETE)
- [x] **Phase 4 — Markets** (COMPLETE)
- [x] **Phase 5 — Paper Trading** (COMPLETE)
- [x] **Phase 6 — Portfolio** (COMPLETE)
- [x] **Phase 7 — AI Trading Coach** (COMPLETE)
- [x] **Phase 8 — Learning Academy** (COMPLETE)
- [x] **Phase 9 — Challenges & Leaderboard** (COMPLETE)
- [ ] Phase 10 — Profile & Settings
- [ ] Phase 11 — Firestore schema, security rules, FCM notifications
- [ ] Phase 12 — Polish: animations, responsiveness, QA pass

**Current phase:** Phase 9 complete. Awaiting "Continue" to start Phase 10.

---

## Phase 9 — What Was Built

Daily/Weekly/Monthly Challenges and a Leaderboard, both driven entirely
by real data already in the app — no fake counters.

**Challenges:** 6 challenges (2 per period) measuring real trade/course
activity: Daily Trader (1 trade today), Green Day (1 profitable close
today), Active Week (5 trades this week), Study Time (2 courses this
week), Power Trader (20 trades this month), Scholar (5 courses this
month). Progress is **always recomputed live** from real transaction
and course-completion timestamps for the current period window — no
counters are stored, so nothing can drift out of sync with reality.
Only the "XP already claimed" flag is persisted (mirrors Phase 8's
badge-award pattern), preventing double-claiming.

**Leaderboard:** ranks users by total XP or by portfolio return % (both
tabs). Uses a denormalized `leaderboard` collection each user writes
their own entry to.

**Two things worth your attention:**
1. **New collections added beyond the original spec:** `challenges` and `leaderboard`. Documented in `AppStrings` with the reasoning — the original 8-collection list didn't anticipate per-period claim tracking or a public leaderboard.
2. **Privacy:** the leaderboard is intentionally public among signed-in users (name, photo, XP, returns are all visible to everyone) — that's inherent to what a leaderboard is. `LeaderboardRepository`'s docs flag this explicitly; consider an opt-in/opt-out toggle in Phase 10's Profile/Settings before shipping this publicly, and lock down write-only-your-own-doc in Phase 11's security rules.

**Also fixed while here:** found and corrected a real import bug —
`entities/` is a sibling of `repositories/` under each feature's
`domain/` folder, not a subfolder of it. Four repository contract files
across Phases 5, 7, and 8 (`trading_repository.dart`,
`ai_coach_repository.dart`, `learn_repository.dart`, plus this phase's
two new ones) had `import 'entities/...'` instead of
`import '../entities/...'`, which would have failed to compile. All
fixed and re-audited — every `domain/repositories/*.dart` file across
the whole project now resolves correctly.

### Files Created (Phase 9)

```
lib/features/challenges/domain/entities/challenge_entity.dart
lib/features/challenges/domain/entities/leaderboard_entry_entity.dart
lib/features/challenges/domain/repositories/challenges_repository.dart
lib/features/challenges/domain/repositories/leaderboard_repository.dart
lib/features/challenges/domain/challenge_evaluator.dart

lib/features/challenges/data/content/challenge_catalog.dart
lib/features/challenges/data/datasources/challenges_remote_datasource.dart
lib/features/challenges/data/datasources/leaderboard_remote_datasource.dart
lib/features/challenges/data/repositories/challenges_repository_impl.dart
lib/features/challenges/data/repositories/leaderboard_repository_impl.dart

lib/features/challenges/presentation/providers/challenges_providers.dart
lib/features/challenges/presentation/screens/challenges_screen.dart
lib/features/challenges/presentation/screens/leaderboard_screen.dart
lib/features/challenges/presentation/widgets/challenge_card.dart
lib/features/challenges/presentation/widgets/leaderboard_tile.dart
lib/features/challenges/presentation/widgets/challenge_icons.dart
```

### Files Modified (Phase 9)

```
lib/core/constants/app_strings.dart   (added challenges/leaderboard collection names)
lib/features/learn/presentation/screens/learn_screen.dart  (Challenges entry point in app bar; XP now uses the combined course+challenge total)

Bug fixes (see above):
lib/features/paper_trade/domain/repositories/trading_repository.dart
lib/features/ai_coach/domain/repositories/ai_coach_repository.dart
lib/features/learn/domain/repositories/learn_repository.dart
```

### Notes / Action Items for You

1. Read the privacy note above before enabling the leaderboard for real users.
2. Challenges & Leaderboard are reached via the trophy icon in Learn's app bar — consider also surfacing a "This Week's Challenges" preview on Home in a future polish pass if you want more visibility.

---

## How to Continue

Type **Continue** to begin Phase 10 (Profile & Settings).
