import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/result.dart';
import '../../../auth/presentation/providers/auth_providers.dart';
import '../../../markets/domain/entities/asset_entity.dart';
import '../../../markets/presentation/providers/market_providers.dart';
import '../../data/datasources/trading_remote_datasource.dart';
import '../../data/repositories/trading_repository_impl.dart';
import '../../domain/entities/order_enums.dart';
import '../../domain/entities/position_entity.dart';
import '../../domain/entities/transaction_entity.dart';
import '../../domain/repositories/trading_repository.dart';

// ---------------- Data / Repository ----------------

final tradingRemoteDataSourceProvider = Provider<TradingRemoteDataSource>((ref) {
  return TradingRemoteDataSource(ref.watch(firestoreProvider));
});

final tradingRepositoryProvider = Provider<TradingRepository>((ref) {
  return TradingRepositoryImpl(ref.watch(tradingRemoteDataSourceProvider));
});

// ---------------- Streams ----------------

final openPositionsProvider = StreamProvider.autoDispose<List<PositionEntity>>((ref) {
  final uid = ref.watch(authRepositoryProvider).currentUid;
  if (uid == null) return Stream.value(const []);
  return ref.watch(tradingRepositoryProvider).watchOpenPositions(uid);
});

final closedPositionsProvider = StreamProvider.autoDispose<List<PositionEntity>>((ref) {
  final uid = ref.watch(authRepositoryProvider).currentUid;
  if (uid == null) return Stream.value(const []);
  return ref.watch(tradingRepositoryProvider).watchClosedPositions(uid);
});

final pendingOrdersProvider = StreamProvider.autoDispose<List<TransactionEntity>>((ref) {
  final uid = ref.watch(authRepositoryProvider).currentUid;
  if (uid == null) return Stream.value(const []);
  return ref.watch(tradingRepositoryProvider).watchPendingOrders(uid);
});

final transactionHistoryProvider =
    StreamProvider.autoDispose<List<TransactionEntity>>((ref) {
  final uid = ref.watch(authRepositoryProvider).currentUid;
  if (uid == null) return Stream.value(const []);
  return ref.watch(tradingRepositoryProvider).watchTransactionHistory(uid);
});

/// Live current prices for every asset the user currently holds a
/// position in or has a pending order on — used both to display
/// unrealized P/L and to feed [checkPendingTriggers].
final heldAssetPricesProvider =
    FutureProvider.autoDispose<Map<String, double>>((ref) async {
  final positions = ref.watch(openPositionsProvider).valueOrNull ?? [];
  final pending = ref.watch(pendingOrdersProvider).valueOrNull ?? [];
  final ids = {
    ...positions.map((p) => p.assetId),
    ...pending.map((p) => p.assetId),
  }.toList();

  if (ids.isEmpty) return {};

  final result = await ref.read(marketRepositoryProvider).getAssetsByIds(ids);
  return result.when(
    success: (assets) => {for (final a in assets) a.id: a.currentPrice},
    failure: (_) => {},
  );
});

// ---------------- Trade placement controller ----------------

class TradeActionState {
  final bool isLoading;
  final String? errorMessage;
  const TradeActionState({this.isLoading = false, this.errorMessage});

  static const idle = TradeActionState();
  static const loading = TradeActionState(isLoading: true);
  factory TradeActionState.error(String message) =>
      TradeActionState(errorMessage: message);
}

class TradeController extends StateNotifier<TradeActionState> {
  final TradingRepository _repository;
  final String? _uid;

  TradeController(this._repository, this._uid) : super(TradeActionState.idle);

  Future<bool> placeMarketOrder({
    required AssetEntity asset,
    required OrderSide side,
    required double quantity,
    required double currentMarketPrice,
    double? stopLoss,
    double? takeProfit,
    String? positionId,
  }) async {
    final uid = _uid;
    if (uid == null) return false;
    state = TradeActionState.loading;
    final result = await _repository.placeMarketOrder(
      uid: uid,
      asset: asset,
      side: side,
      quantity: quantity,
      currentMarketPrice: currentMarketPrice,
      stopLoss: stopLoss,
      takeProfit: takeProfit,
      positionId: positionId,
    );
    return _handle(result);
  }

  Future<bool> placeLimitOrder({
    required AssetEntity asset,
    required OrderSide side,
    required double quantity,
    required double limitPrice,
    double? stopLoss,
    double? takeProfit,
    String? positionId,
  }) async {
    final uid = _uid;
    if (uid == null) return false;
    state = TradeActionState.loading;
    final result = await _repository.placeLimitOrder(
      uid: uid,
      asset: asset,
      side: side,
      quantity: quantity,
      limitPrice: limitPrice,
      stopLoss: stopLoss,
      takeProfit: takeProfit,
      positionId: positionId,
    );
    return _handle(result);
  }

  Future<bool> cancelOrder(String transactionId) async {
    final uid = _uid;
    if (uid == null) return false;
    final result = await _repository.cancelPendingOrder(uid, transactionId);
    return result.isSuccess;
  }

  bool _handle(Result<void> result) {
    return result.when(
      success: (_) {
        state = TradeActionState.idle;
        return true;
      },
      failure: (f) {
        state = TradeActionState.error(f.message);
        return false;
      },
    );
  }
}

final tradeControllerProvider =
    StateNotifierProvider.autoDispose<TradeController, TradeActionState>((ref) {
  return TradeController(
    ref.watch(tradingRepositoryProvider),
    ref.watch(authRepositoryProvider).currentUid,
  );
});

/// Runs [TradingRepository.checkPendingTriggers] once immediately and
/// then every 30 seconds while something is watching this provider
/// (i.e. while the Paper Trade or Portfolio screen is open). See
/// [TradingRepository] class docs for the client-side execution caveat
/// this implements.
final triggerCheckerProvider = StreamProvider.autoDispose<void>((ref) async* {
  final uid = ref.watch(authRepositoryProvider).currentUid;
  if (uid == null) return;

  Future<void> runCheck() async {
    final prices = await ref.read(heldAssetPricesProvider.future);
    if (prices.isEmpty) return;
    await ref.read(tradingRepositoryProvider).checkPendingTriggers(
          uid: uid,
          latestPrices: prices,
        );
  }

  await runCheck();
  yield null;

  yield* Stream.periodic(const Duration(seconds: 30)).asyncMap((_) async {
    await runCheck();
  });
});
