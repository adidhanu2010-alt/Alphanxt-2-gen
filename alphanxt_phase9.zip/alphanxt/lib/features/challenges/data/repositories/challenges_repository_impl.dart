import '../../../../core/errors/failures.dart';
import '../../../../core/errors/result.dart';
import '../../../../core/utils/app_logger.dart';
import '../../domain/entities/challenge_entity.dart';
import '../../domain/repositories/challenges_repository.dart';
import '../datasources/challenges_remote_datasource.dart';

class ChallengesRepositoryImpl implements ChallengesRepository {
  final ChallengesRemoteDataSource _remote;

  ChallengesRepositoryImpl(this._remote);

  @override
  Stream<List<ClaimedChallengeEntity>> watchClaimedChallenges(String uid) {
    return _remote.watchClaimed(uid);
  }

  @override
  Future<Result<void>> claimChallenge({
    required String uid,
    required String challengeId,
    required String periodKey,
  }) async {
    try {
      await _remote.claim(uid: uid, challengeId: challengeId, periodKey: periodKey);
      return Result.success(null);
    } catch (e, st) {
      AppLogger.error('claimChallenge failed', e, st);
      return Result.failure(const DataFailure('Could not claim this challenge.'));
    }
  }
}
