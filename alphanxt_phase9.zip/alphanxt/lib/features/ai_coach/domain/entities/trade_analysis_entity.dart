import 'package:equatable/equatable.dart';
import 'trade_metrics.dart';

/// A complete AI Trading Coach analysis for one closed trade: the real
/// computed [metrics], plus the AI's plain-language narrative sections.
///
/// The narrative is explanatory and educational only — see
/// [AiCoachRepository] docs. It never states or implies a guaranteed
/// outcome for future trades.
class TradeAnalysisEntity extends Equatable {
  final TradeMetrics metrics;
  final String summary;
  final List<String> whatWentWell;
  final List<String> mistakes;
  final List<String> riskManagementTips;
  final List<String> entryExitTips;
  final List<String> lessons;
  final DateTime generatedAt;

  const TradeAnalysisEntity({
    required this.metrics,
    required this.summary,
    required this.whatWentWell,
    required this.mistakes,
    required this.riskManagementTips,
    required this.entryExitTips,
    required this.lessons,
    required this.generatedAt,
  });

  @override
  List<Object?> get props => [
        metrics,
        summary,
        whatWentWell,
        mistakes,
        riskManagementTips,
        entryExitTips,
        lessons,
        generatedAt,
      ];
}
