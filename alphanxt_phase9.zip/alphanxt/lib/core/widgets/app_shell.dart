import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'premium_bottom_nav.dart';

/// Wraps go_router's [StatefulNavigationShell], giving each of the 6
/// bottom-nav tabs (Home, Markets, Paper Trade, Portfolio, Learn,
/// Profile) its own independent navigation stack — switching tabs
/// preserves scroll position / pushed screens on the tab you left,
/// exactly like native iOS/Android tab bars.
class AppShell extends StatelessWidget {
  final StatefulNavigationShell navigationShell;

  const AppShell({super.key, required this.navigationShell});

  static const _items = [
    NavItemData(
      icon: Icons.home_outlined,
      activeIcon: Icons.home_rounded,
      label: 'Home',
    ),
    NavItemData(
      icon: Icons.show_chart_outlined,
      activeIcon: Icons.show_chart_rounded,
      label: 'Markets',
    ),
    NavItemData(
      icon: Icons.swap_horiz_outlined,
      activeIcon: Icons.swap_horiz_rounded,
      label: 'Trade',
    ),
    NavItemData(
      icon: Icons.pie_chart_outline_rounded,
      activeIcon: Icons.pie_chart_rounded,
      label: 'Portfolio',
    ),
    NavItemData(
      icon: Icons.school_outlined,
      activeIcon: Icons.school_rounded,
      label: 'Learn',
    ),
    NavItemData(
      icon: Icons.person_outline_rounded,
      activeIcon: Icons.person_rounded,
      label: 'Profile',
    ),
  ];

  void _onTap(int index) {
    // `initialLocation: true` pops back to the branch's root when the
    // user re-taps the tab they're already on — standard tab-bar UX.
    navigationShell.goBranch(
      index,
      initialLocation: index == navigationShell.currentIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: navigationShell,
      bottomNavigationBar: PremiumBottomNav(
        currentIndex: navigationShell.currentIndex,
        onTap: _onTap,
        items: _items,
      ),
    );
  }
}
