import 'package:equatable/equatable.dart';

enum ChallengePeriod { daily, weekly, monthly }

extension ChallengePeriodX on ChallengePeriod {
  String get label => switch (this) {
        ChallengePeriod.daily => 'Daily',
        ChallengePeriod.weekly => 'Weekly',
        ChallengePeriod.monthly => 'Monthly',
      };
}

/// What real, existing app data a challenge's progress is measured
/// against. Every metric here is computed from data that already exists
/// elsewhere in the app (trades, course completions) — nothing is
/// tracked solely for challenges.
enum ChallengeMetric {
  tradesPlaced,
  profitableTradesClosed,
  coursesCompleted,
}

/// Static definition of one challenge. A challenge "resets" each period
/// simply because its progress is always recomputed live from real data
/// filtered to the current period's date range — no stored counters, no
/// backend cron needed. See [ChallengeEvaluator].
class ChallengeDefinitionEntity extends Equatable {
  final String id;
  final String title;
  final String description;
  final ChallengePeriod period;
  final ChallengeMetric metric;
  final int targetCount;
  final int xpReward;
  final String iconKey;

  const ChallengeDefinitionEntity({
    required this.id,
    required this.title,
    required this.description,
    required this.period,
    required this.metric,
    required this.targetCount,
    required this.xpReward,
    required this.iconKey,
  });

  @override
  List<Object?> get props =>
      [id, title, description, period, metric, targetCount, xpReward, iconKey];
}

/// Live-computed progress toward one challenge for the CURRENT period —
/// recalculated on every read from real trade/course data, never stored.
class ChallengeProgressEntity extends Equatable {
  final ChallengeDefinitionEntity definition;
  final int currentCount;
  final String periodKey;

  const ChallengeProgressEntity({
    required this.definition,
    required this.currentCount,
    required this.periodKey,
  });

  bool get isCompleted => currentCount >= definition.targetCount;
  double get progressFraction =>
      definition.targetCount == 0 ? 0 : (currentCount / definition.targetCount).clamp(0, 1);

  @override
  List<Object?> get props => [definition, currentCount, periodKey];
}

/// A real record that XP for a specific challenge+period has already
/// been credited — persisted in Firestore so re-opening the Challenges
/// screen (or the period rolling over later) never double-awards XP.
class ClaimedChallengeEntity extends Equatable {
  final String challengeId;
  final String periodKey;
  final DateTime claimedAt;

  const ClaimedChallengeEntity({
    required this.challengeId,
    required this.periodKey,
    required this.claimedAt,
  });

  @override
  List<Object?> get props => [challengeId, periodKey, claimedAt];
}
