import '../../../../core/errors/failures.dart';
import '../../../../core/errors/result.dart';
import '../../../../core/utils/app_logger.dart';
import '../../../markets/domain/entities/chart_range.dart';
import '../../../markets/domain/repositories/market_repository.dart';
import '../../../paper_trade/domain/entities/position_entity.dart';
import '../../domain/entities/trade_analysis_entity.dart';
import '../../domain/repositories/ai_coach_repository.dart';
import '../../domain/trade_metrics_calculator.dart';
import '../datasources/ai_analysis_cache_datasource.dart';
import '../datasources/claude_ai_datasource.dart';
import '../models/trade_analysis_model.dart';

class AiCoachRepositoryImpl implements AiCoachRepository {
  final ClaudeAiDataSource? _aiDataSource;
  final AiAnalysisCacheDataSource _cacheDataSource;
  final MarketRepository _marketRepository;
  final double Function() _getCurrentTotalAccountValue;

  AiCoachRepositoryImpl({
    required ClaudeAiDataSource? aiDataSource,
    required AiAnalysisCacheDataSource cacheDataSource,
    required MarketRepository marketRepository,
    required double Function() getCurrentTotalAccountValue,
  })  : _aiDataSource = aiDataSource,
        _cacheDataSource = cacheDataSource,
        _marketRepository = marketRepository,
        _getCurrentTotalAccountValue = getCurrentTotalAccountValue;

  @override
  Future<Result<TradeAnalysisEntity>> analyzeTrade({
    required String uid,
    required PositionEntity closedPosition,
    required String closingTransactionId,
    bool forceRegenerate = false,
  }) async {
    try {
      // ---- 1. Real price history for trend/volatility context ----
      final historyResult = await _marketRepository.getPriceHistory(
        closedPosition.assetId,
        _rangeCoveringHold(closedPosition),
      );
      final priceHistory = historyResult.when(
        success: (points) => points,
        failure: (_) => const [],
      );

      final metrics = TradeMetricsCalculator.calculate(
        closedPosition: closedPosition,
        priceHistoryDuringHold: priceHistory,
        currentTotalAccountValue: _getCurrentTotalAccountValue(),
      );

      // ---- 2. Check cache first (saves an API call + keeps it stable) ----
      if (!forceRegenerate) {
        final cached =
            await _cacheDataSource.getCachedAnalysis(closingTransactionId);
        if (cached != null) {
          return Result.success(
            TradeAnalysisModel.fromCacheMap(cached, metrics),
          );
        }
      }

      if (_aiDataSource == null) {
        return Result.failure(const DataFailure(
          'AI Coach isn\'t configured yet — add AI_COACH_API_KEY in .env to enable it.',
        ));
      }

      // ---- 3. Generate via Claude, then cache ----
      final json = await _aiDataSource.generateAnalysis(
        assetName: closedPosition.name,
        assetSymbol: closedPosition.symbol,
        wasProfitable: closedPosition.realizedPnl >= 0,
        metrics: metrics,
      );

      final analysis = TradeAnalysisModel.fromAiJson(json, metrics);
      await _cacheDataSource.saveAnalysis(
        closingTransactionId,
        analysis.toCacheMap(),
      );

      return Result.success(analysis);
    } catch (e, st) {
      AppLogger.error('analyzeTrade failed', e, st);
      return Result.failure(const DataFailure(
        'Could not generate the AI analysis right now. Please try again.',
      ));
    }
  }

  ChartRange _rangeCoveringHold(PositionEntity position) {
    final holdDays = (position.closedAt ?? DateTime.now())
        .difference(position.openedAt)
        .inDays;
    if (holdDays <= 1) return ChartRange.oneWeek;
    if (holdDays <= 30) return ChartRange.oneMonth;
    if (holdDays <= 90) return ChartRange.threeMonths;
    return ChartRange.oneYear;
  }
}
