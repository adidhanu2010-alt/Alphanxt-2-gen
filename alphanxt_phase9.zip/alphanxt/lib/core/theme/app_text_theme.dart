import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../constants/app_colors.dart';

/// Centralized typography for AlphaNXT.
///
/// Uses 'Inter' for body/UI text (excellent legibility at small sizes,
/// ideal for dense financial data) and 'Sora' for display/headline text
/// (distinct, modern, premium feel for a fintech product).
class AppTextTheme {
  AppTextTheme._();

  static TextTheme _base(Color primaryText, Color secondaryText) {
    final base = GoogleFonts.interTextTheme();
    final display = GoogleFonts.soraTextTheme();

    return base.copyWith(
      displayLarge: display.displayLarge?.copyWith(
        color: primaryText,
        fontWeight: FontWeight.w700,
        fontSize: 40,
        letterSpacing: -0.5,
      ),
      displayMedium: display.displayMedium?.copyWith(
        color: primaryText,
        fontWeight: FontWeight.w700,
        fontSize: 32,
        letterSpacing: -0.5,
      ),
      headlineLarge: display.headlineLarge?.copyWith(
        color: primaryText,
        fontWeight: FontWeight.w700,
        fontSize: 28,
      ),
      headlineMedium: display.headlineMedium?.copyWith(
        color: primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 24,
      ),
      headlineSmall: display.headlineSmall?.copyWith(
        color: primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 20,
      ),
      titleLarge: base.titleLarge?.copyWith(
        color: primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 18,
      ),
      titleMedium: base.titleMedium?.copyWith(
        color: primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 16,
      ),
      titleSmall: base.titleSmall?.copyWith(
        color: primaryText,
        fontWeight: FontWeight.w500,
        fontSize: 14,
      ),
      bodyLarge: base.bodyLarge?.copyWith(
        color: primaryText,
        fontWeight: FontWeight.w400,
        fontSize: 16,
        height: 1.5,
      ),
      bodyMedium: base.bodyMedium?.copyWith(
        color: primaryText,
        fontWeight: FontWeight.w400,
        fontSize: 14,
        height: 1.5,
      ),
      bodySmall: base.bodySmall?.copyWith(
        color: secondaryText,
        fontWeight: FontWeight.w400,
        fontSize: 12,
        height: 1.4,
      ),
      labelLarge: base.labelLarge?.copyWith(
        color: primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 14,
      ),
      labelMedium: base.labelMedium?.copyWith(
        color: secondaryText,
        fontWeight: FontWeight.w500,
        fontSize: 12,
      ),
      labelSmall: base.labelSmall?.copyWith(
        color: secondaryText,
        fontWeight: FontWeight.w500,
        fontSize: 11,
      ),
    );
  }

  static TextTheme get light =>
      _base(AppColors.lightTextPrimary, AppColors.lightTextSecondary);

  static TextTheme get dark =>
      _base(AppColors.darkTextPrimary, AppColors.darkTextSecondary);
}
