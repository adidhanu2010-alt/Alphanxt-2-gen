import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/order_enums.dart';
import '../../domain/entities/position_entity.dart';

class PositionModel extends PositionEntity {
  const PositionModel({
    required super.id,
    required super.uid,
    required super.assetId,
    required super.symbol,
    required super.name,
    super.imageUrl,
    required super.quantity,
    required super.avgBuyPrice,
    super.stopLoss,
    super.takeProfit,
    required super.status,
    required super.openedAt,
    super.closedAt,
    super.closePrice,
    super.realizedPnl,
  });

  factory PositionModel.fromMap(Map<String, dynamic> map, String id) {
    return PositionModel(
      id: id,
      uid: map['uid'] as String? ?? '',
      assetId: map['assetId'] as String? ?? '',
      symbol: map['symbol'] as String? ?? '',
      name: map['name'] as String? ?? '',
      imageUrl: map['imageUrl'] as String?,
      quantity: (map['quantity'] as num?)?.toDouble() ?? 0,
      avgBuyPrice: (map['avgBuyPrice'] as num?)?.toDouble() ?? 0,
      stopLoss: (map['stopLoss'] as num?)?.toDouble(),
      takeProfit: (map['takeProfit'] as num?)?.toDouble(),
      status: (map['status'] as String?) == 'closed'
          ? PositionStatus.closed
          : PositionStatus.open,
      openedAt: (map['openedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      closedAt: (map['closedAt'] as Timestamp?)?.toDate(),
      closePrice: (map['closePrice'] as num?)?.toDouble(),
      realizedPnl: (map['realizedPnl'] as num?)?.toDouble() ?? 0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'assetId': assetId,
      'symbol': symbol,
      'name': name,
      'imageUrl': imageUrl,
      'quantity': quantity,
      'avgBuyPrice': avgBuyPrice,
      'stopLoss': stopLoss,
      'takeProfit': takeProfit,
      'status': status == PositionStatus.closed ? 'closed' : 'open',
      'openedAt': Timestamp.fromDate(openedAt),
      'closedAt': closedAt != null ? Timestamp.fromDate(closedAt!) : null,
      'closePrice': closePrice,
      'realizedPnl': realizedPnl,
    };
  }
}
