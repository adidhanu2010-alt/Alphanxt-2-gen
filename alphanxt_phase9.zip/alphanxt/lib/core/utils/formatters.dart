import 'package:intl/intl.dart';

/// Shared formatting helpers for currency, percentages, and dates.
///
/// Centralizing this avoids inconsistent P/L formatting (e.g. some screens
/// showing ₹1,000.5 and others ₹1,000.50) across the app.
class Formatters {
  Formatters._();

  static final NumberFormat _inr = NumberFormat.currency(
    locale: 'en_IN',
    symbol: '₹',
    decimalDigits: 2,
  );

  static final NumberFormat _inrCompact = NumberFormat.compactCurrency(
    locale: 'en_IN',
    symbol: '₹',
    decimalDigits: 1,
  );

  /// e.g. 100000 -> "₹1,00,000.00"
  static String currency(num value) => _inr.format(value);

  /// e.g. 1500000 -> "₹15L" (compact, useful for dashboard tiles)
  static String currencyCompact(num value) => _inrCompact.format(value);

  /// e.g. 0.0532 -> "+5.32%" / -0.0532 -> "-5.32%"
  static String percentSigned(double fraction) {
    final pct = fraction * 100;
    final sign = pct >= 0 ? '+' : '';
    return '$sign${pct.toStringAsFixed(2)}%';
  }

  /// e.g. 5.32 -> "5.32%"
  static String percent(double value) => '${value.toStringAsFixed(2)}%';

  /// e.g. DateTime -> "24 Jul 2026"
  static String date(DateTime date) => DateFormat('d MMM y').format(date);

  /// e.g. DateTime -> "24 Jul 2026, 3:45 PM"
  static String dateTime(DateTime date) =>
      DateFormat('d MMM y, h:mm a').format(date);

  /// e.g. DateTime -> "3:45 PM"
  static String time(DateTime date) => DateFormat('h:mm a').format(date);

  /// Relative time, e.g. "2h ago", "Just now", "3d ago".
  static String relative(DateTime date) {
    final diff = DateTime.now().difference(date);
    if (diff.inSeconds < 60) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays < 7) return '${diff.inDays}d ago';
    return Formatters.date(date);
  }

  /// Formats holding time in a human-readable way for trade analysis,
  /// e.g. Duration(minutes: 95) -> "1h 35m".
  static String holdingDuration(Duration d) {
    if (d.inDays > 0) return '${d.inDays}d ${d.inHours % 24}h';
    if (d.inHours > 0) return '${d.inHours}h ${d.inMinutes % 60}m';
    return '${d.inMinutes}m';
  }
}
