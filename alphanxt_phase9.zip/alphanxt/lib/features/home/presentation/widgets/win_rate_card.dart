import 'package:flutter/material.dart';
import '../../../../core/constants/app_dimens.dart';

/// Win-rate summary card — pairs with [DailyPnlCard] in Home's stats
/// row. Genuinely shows "—" for accounts with no closed trades yet
/// (there is no meaningful win rate to compute); Phase 5/6 wire in the
/// real calculation once trade history exists.
class WinRateCard extends StatelessWidget {
  final double? winRatePercent;
  final int totalTrades;

  const WinRateCard({
    super.key,
    this.winRatePercent,
    this.totalTrades = 0,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.track_changes_rounded,
                  size: AppDimens.iconSmall,
                  color: theme.textTheme.bodySmall?.color,
                ),
                const SizedBox(width: AppDimens.space8),
                Text('Win Rate', style: theme.textTheme.labelMedium),
              ],
            ),
            const SizedBox(height: AppDimens.space12),
            Text(
              winRatePercent == null
                  ? '—'
                  : '${winRatePercent!.toStringAsFixed(0)}%',
              style: theme.textTheme.titleLarge,
            ),
            const SizedBox(height: 2),
            Text(
              totalTrades == 0 ? 'No trades yet' : '$totalTrades trades',
              style: theme.textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}
