import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/utils/formatters.dart';
import '../../domain/entities/position_entity.dart';

/// Summary card for a fully-closed position — entry vs. close price and
/// total realized P/L across its lifetime.
class ClosedPositionCard extends StatelessWidget {
  final PositionEntity position;
  final VoidCallback? onTap;

  const ClosedPositionCard({super.key, required this.position, this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isPositive = position.realizedPnl >= 0;
    final color = isPositive ? AppColors.bullish : AppColors.bearish;

    return Card(
      margin: const EdgeInsets.only(bottom: AppDimens.space12),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppDimens.radiusXLarge),
        onTap: onTap,
        child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(position.name, style: theme.textTheme.titleSmall),
                  Text(
                    '${Formatters.currency(position.avgBuyPrice)} → ${Formatters.currency(position.closePrice ?? 0)}',
                    style: theme.textTheme.bodySmall,
                  ),
                  if (position.closedAt != null)
                    Text(
                      Formatters.date(position.closedAt!),
                      style: theme.textTheme.bodySmall,
                    ),
                ],
              ),
            ),
            Text(
              '${isPositive ? '+' : ''}${Formatters.currency(position.realizedPnl)}',
              style: theme.textTheme.titleSmall?.copyWith(color: color),
            ),
            if (onTap != null) ...[
              const SizedBox(width: AppDimens.space8),
              Icon(Icons.auto_awesome_rounded,
                  size: AppDimens.iconSmall, color: theme.colorScheme.primary),
            ],
          ],
        ),
        ),
      ),
    );
  }
}
