import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../domain/entities/trade_metrics.dart';

/// Calls the Anthropic Claude API to generate the AI Trading Coach's
/// narrative for one closed trade.
///
/// Only the real, already-computed [TradeMetrics] are sent — the model
/// is instructed to explain and teach around those numbers, never to
/// invent additional statistics or guarantee future results. The
/// response is requested as strict JSON so it can be parsed reliably
/// into the app's UI sections.
class ClaudeAiDataSource {
  static const String _apiUrl = 'https://api.anthropic.com/v1/messages';
  static const String _model = 'claude-sonnet-5';
  static const String _anthropicVersion = '2023-06-01';

  final http.Client _client;
  final String apiKey;

  ClaudeAiDataSource({required this.apiKey, http.Client? client})
      : _client = client ?? http.Client();

  Future<Map<String, dynamic>> generateAnalysis({
    required String assetName,
    required String assetSymbol,
    required bool wasProfitable,
    required TradeMetrics metrics,
  }) async {
    final prompt = _buildPrompt(
      assetName: assetName,
      assetSymbol: assetSymbol,
      wasProfitable: wasProfitable,
      metrics: metrics,
    );

    final response = await _client.post(
      Uri.parse(_apiUrl),
      headers: {
        'content-type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': _anthropicVersion,
      },
      body: jsonEncode({
        'model': _model,
        'max_tokens': 1024,
        'system': _systemPrompt,
        'messages': [
          {'role': 'user', 'content': prompt}
        ],
      }),
    );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(
        'AI Coach request failed (${response.statusCode}): ${response.body}',
      );
    }

    final decoded = jsonDecode(response.body) as Map<String, dynamic>;
    final contentBlocks = decoded['content'] as List?;
    final text = contentBlocks
            ?.firstWhere((b) => b['type'] == 'text', orElse: () => null)?['text']
        as String?;

    if (text == null || text.isEmpty) {
      throw Exception('AI Coach returned an empty response.');
    }

    // Model is instructed to return raw JSON, but defensively strip any
    // accidental markdown code-fence wrapping before parsing.
    final cleaned = text.trim().replaceAll(RegExp(r'^```json|```$'), '').trim();
    return jsonDecode(cleaned) as Map<String, dynamic>;
  }

  static const String _systemPrompt = '''
You are AlphaNXT's AI Trading Coach — an educational assistant that helps
users of a PAPER (virtual money) trading app learn from their past trades.

CRITICAL RULES:
- You will be given real, pre-computed trade metrics. Reference ONLY those
  numbers — never invent additional statistics, prices, or percentages.
- NEVER state or imply that any strategy, indicator, or approach guarantees
  profit, or that future trades will succeed. This is a hard requirement.
- Be constructive and specific, not generic. Reference the actual numbers
  given to you (e.g. "your stop-loss was 8% below entry" not "you used a
  stop-loss").
- If a metric is null/missing (e.g. no stop-loss was set), gently note that
  as a learning point rather than skipping it silently.
- Keep each list item to one clear sentence.
- Respond with ONLY raw JSON (no markdown fences, no commentary) matching
  exactly this shape:
{
  "summary": "2-3 sentence plain-language overview of what happened in this trade",
  "whatWentWell": ["...", "..."],
  "mistakes": ["...", "..."],
  "riskManagementTips": ["...", "..."],
  "entryExitTips": ["...", "..."],
  "lessons": ["...", "..."]
}
Any list may be empty if genuinely not applicable, but never omit a key.
''';

  String _buildPrompt({
    required String assetName,
    required String assetSymbol,
    required bool wasProfitable,
    required TradeMetrics metrics,
  }) {
    String fmt(double? v) => v == null ? 'not set' : v.toStringAsFixed(2);
    final hours = metrics.holdingTime.inHours;
    final days = metrics.holdingTime.inDays;
    final holdingStr = days > 0 ? '$days days' : '$hours hours';

    return '''
Analyze this closed paper-trade on $assetName ($assetSymbol):

- Outcome: ${wasProfitable ? 'Profitable' : 'Loss'}
- Entry price: ${metrics.entryPrice.toStringAsFixed(2)}
- Exit price: ${metrics.exitPrice.toStringAsFixed(2)}
- Realized P/L: ${metrics.realizedPnl.toStringAsFixed(2)} (${metrics.realizedPnlPercent.toStringAsFixed(2)}%)
- Stop-loss set: ${fmt(metrics.stopLoss)}
- Take-profit set: ${fmt(metrics.takeProfit)}
- Risk % (entry to stop-loss): ${fmt(metrics.riskPercent)}
- Reward:Risk ratio: ${fmt(metrics.rewardRiskRatio)}
- Market trend during the hold: ${metrics.trend}
- Holding time: $holdingStr
- Position size: ${metrics.positionSizeValue.toStringAsFixed(2)} (~${metrics.positionSizePercent.toStringAsFixed(1)}% of current account value)
- Volatility during the hold: ${fmt(metrics.volatilityPercent)}%

Return the JSON analysis now.
''';
  }
}
