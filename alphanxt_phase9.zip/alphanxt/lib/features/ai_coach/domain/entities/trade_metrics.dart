import 'package:equatable/equatable.dart';

/// All numeric metrics for a closed trade, computed deterministically
/// from real position/transaction data and real market price history —
/// never from the AI. The AI Trading Coach only narrates around these
/// already-computed numbers, so nothing in the explanation can be a
/// hallucinated statistic.
class TradeMetrics extends Equatable {
  final double entryPrice;
  final double exitPrice;
  final double? stopLoss;
  final double? takeProfit;

  /// % distance from entry to stop-loss (null if no SL was set).
  final double? riskPercent;

  /// Reward:risk ratio from entry/SL/TP (null unless both SL and TP set).
  final double? rewardRiskRatio;

  final String trend; // 'Uptrend' | 'Downtrend' | 'Sideways' | 'Insufficient data'
  final Duration holdingTime;
  final double positionSizeValue;

  /// Position cost as a % of current total account value — an
  /// approximation (see [TradeMetricsCalculator] docs for why exact
  /// historical account value isn't always available).
  final double positionSizePercent;

  final double? volatilityPercent;
  final double realizedPnl;
  final double realizedPnlPercent;
  final double quantity;

  const TradeMetrics({
    required this.entryPrice,
    required this.exitPrice,
    this.stopLoss,
    this.takeProfit,
    this.riskPercent,
    this.rewardRiskRatio,
    required this.trend,
    required this.holdingTime,
    required this.positionSizeValue,
    required this.positionSizePercent,
    this.volatilityPercent,
    required this.realizedPnl,
    required this.realizedPnlPercent,
    required this.quantity,
  });

  @override
  List<Object?> get props => [
        entryPrice,
        exitPrice,
        stopLoss,
        takeProfit,
        riskPercent,
        rewardRiskRatio,
        trend,
        holdingTime,
        positionSizeValue,
        positionSizePercent,
        volatilityPercent,
        realizedPnl,
        realizedPnlPercent,
        quantity,
      ];
}
