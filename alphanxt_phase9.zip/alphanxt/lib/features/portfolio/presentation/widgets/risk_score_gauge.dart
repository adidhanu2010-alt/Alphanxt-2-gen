import 'package:flutter/material.dart';
import 'package:percent_indicator/percent_indicator.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../domain/risk_score_calculator.dart';

/// Circular gauge breaking down the risk score into its three factors,
/// with a plain-language explanation — always framed as educational,
/// never as advice or a guarantee.
class RiskScoreGauge extends StatelessWidget {
  final RiskScoreResult result;
  final bool hasHoldings;

  const RiskScoreGauge({super.key, required this.result, required this.hasHoldings});

  Color _colorFor(double score) {
    if (score < 33) return AppColors.bullish;
    if (score < 66) return AppColors.warning;
    return AppColors.bearish;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (!hasHoldings) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(AppDimens.space16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Risk Score', style: theme.textTheme.titleSmall),
              const SizedBox(height: AppDimens.space12),
              Text(
                'Open a position to see your portfolio risk breakdown.',
                style: theme.textTheme.bodySmall,
              ),
            ],
          ),
        ),
      );
    }

    final color = _colorFor(result.score);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text('Risk Score', style: theme.textTheme.titleSmall),
                const Spacer(),
                Text(
                  'Educational indicator, not advice',
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: theme.textTheme.bodySmall?.color,
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppDimens.space16),
            Row(
              children: [
                CircularPercentIndicator(
                  radius: 44,
                  lineWidth: 10,
                  percent: (result.score / 100).clamp(0, 1),
                  animation: true,
                  animationDuration: 700,
                  circularStrokeCap: CircularStrokeCap.round,
                  progressColor: color,
                  backgroundColor: color.withValues(alpha: 0.12),
                  center: Text(
                    result.score.toStringAsFixed(0),
                    style: theme.textTheme.titleMedium?.copyWith(color: color),
                  ),
                ),
                const SizedBox(width: AppDimens.space20),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(result.label, style: theme.textTheme.titleSmall?.copyWith(color: color)),
                      const SizedBox(height: AppDimens.space8),
                      _factorRow(context, 'Concentration', result.concentration),
                      _factorRow(context, 'Volatility', result.volatility),
                      _factorRow(context, 'Exposure', result.exposure),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _factorRow(BuildContext context, String label, double value) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          SizedBox(width: 100, child: Text(label, style: theme.textTheme.bodySmall)),
          Expanded(
            child: LinearProgressIndicator(
              value: (value / 100).clamp(0, 1),
              minHeight: 4,
              backgroundColor: theme.dividerColor.withValues(alpha: 0.3),
              valueColor: AlwaysStoppedAnimation<Color>(_colorFor(value)),
            ),
          ),
        ],
      ),
    );
  }
}
