import 'package:equatable/equatable.dart';

/// Base class for all domain-layer failures.
///
/// Repositories return `Either<Failure, T>`-style results (or throw these
/// wrapped in a Result type) instead of leaking raw exceptions
/// (FirebaseException, SocketException, etc.) into the presentation layer.
/// This keeps ViewModels/providers decoupled from Firebase/Dio/etc.
abstract class Failure extends Equatable {
  final String message;
  const Failure(this.message);

  @override
  List<Object?> get props => [message];
}

/// Auth-related failures (login, register, verification, Google sign-in).
class AuthFailure extends Failure {
  const AuthFailure(super.message);
}

/// Firestore / Storage read-write failures.
class DataFailure extends Failure {
  const DataFailure(super.message);
}

/// No/lost network connectivity.
class NetworkFailure extends Failure {
  const NetworkFailure([super.message = 'No internet connection.']);
}

/// Input validation failures (form fields, trade parameters, etc.).
class ValidationFailure extends Failure {
  const ValidationFailure(super.message);
}

/// Trading-specific failures (insufficient balance, invalid order, etc.).
class TradeFailure extends Failure {
  const TradeFailure(super.message);
}

/// Fallback for anything unexpected — always logged, never silently eaten.
class UnknownFailure extends Failure {
  const UnknownFailure([super.message = 'Something went wrong. Please try again.']);
}
