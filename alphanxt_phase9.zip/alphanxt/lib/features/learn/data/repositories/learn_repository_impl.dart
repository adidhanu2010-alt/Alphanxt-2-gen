import '../../../../core/errors/failures.dart';
import '../../../../core/errors/result.dart';
import '../../../../core/utils/app_logger.dart';
import '../../domain/entities/course_progress_entity.dart';
import '../../domain/repositories/learn_repository.dart';
import '../datasources/learn_remote_datasource.dart';

class LearnRepositoryImpl implements LearnRepository {
  final LearnRemoteDataSource _remote;

  LearnRepositoryImpl(this._remote);

  @override
  Stream<List<CourseProgressEntity>> watchProgress(String uid) {
    return _remote.watchProgress(uid);
  }

  @override
  Future<Result<void>> markLessonRead(String uid, String courseId) async {
    try {
      await _remote.markLessonRead(uid, courseId);
      return Result.success(null);
    } catch (e, st) {
      AppLogger.error('markLessonRead failed', e, st);
      return Result.failure(const DataFailure('Could not save your progress.'));
    }
  }

  @override
  Future<Result<void>> submitQuizResult({
    required String uid,
    required String courseId,
    required int scorePercent,
    required int xpReward,
  }) async {
    try {
      await _remote.submitQuizResult(
        uid: uid,
        courseId: courseId,
        scorePercent: scorePercent,
        xpReward: xpReward,
      );
      return Result.success(null);
    } catch (e, st) {
      AppLogger.error('submitQuizResult failed', e, st);
      return Result.failure(const DataFailure('Could not save your quiz result.'));
    }
  }

  @override
  Stream<List<EarnedBadgeEntity>> watchEarnedBadges(String uid) {
    return _remote.watchEarnedBadges(uid);
  }

  @override
  Future<Result<void>> awardBadgeIfNotEarned(String uid, String badgeId) async {
    try {
      await _remote.awardBadgeIfNotEarned(uid, badgeId);
      return Result.success(null);
    } catch (e, st) {
      AppLogger.error('awardBadgeIfNotEarned failed', e, st);
      return Result.failure(const DataFailure('Could not award badge.'));
    }
  }
}
