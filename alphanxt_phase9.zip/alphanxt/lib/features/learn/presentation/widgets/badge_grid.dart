import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../domain/badge_evaluator.dart';
import 'learn_icons.dart';

/// Grid of all badges — earned ones in full color, unearned ones
/// grayed out with a lock, so the learner can see what's still ahead.
class BadgeGrid extends StatelessWidget {
  final Set<String> earnedBadgeIds;

  const BadgeGrid({super.key, required this.earnedBadgeIds});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        mainAxisSpacing: AppDimens.space12,
        crossAxisSpacing: AppDimens.space12,
        childAspectRatio: 0.85,
      ),
      itemCount: BadgeCatalog.all.length,
      itemBuilder: (context, i) {
        final badge = BadgeCatalog.all[i];
        final earned = earnedBadgeIds.contains(badge.id);

        return Tooltip(
          message: '${badge.title}\n${badge.description}',
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                height: 56,
                width: 56,
                decoration: BoxDecoration(
                  color: earned
                      ? AppColors.warning.withValues(alpha: 0.15)
                      : theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  earned ? learnIconFor(badge.iconKey) : Icons.lock_outline_rounded,
                  color: earned ? AppColors.warning : theme.textTheme.bodySmall?.color,
                  size: 24,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                badge.title,
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: theme.textTheme.labelSmall?.copyWith(
                  color: earned ? null : theme.textTheme.bodySmall?.color,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
