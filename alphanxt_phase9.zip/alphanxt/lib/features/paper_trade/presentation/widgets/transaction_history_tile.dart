import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/utils/formatters.dart';
import '../../domain/entities/order_enums.dart';
import '../../domain/entities/transaction_entity.dart';

/// A single row in the trade history log — buy or sell, filled or
/// cancelled, with realized P/L shown on sells.
class TransactionHistoryTile extends StatelessWidget {
  final TransactionEntity transaction;

  const TransactionHistoryTile({super.key, required this.transaction});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isBuy = transaction.side == OrderSide.buy;
    final isCancelled = transaction.status == TransactionStatus.cancelled;
    final sideColor = isCancelled
        ? theme.textTheme.bodySmall?.color
        : (isBuy ? AppColors.bullish : AppColors.bearish);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppDimens.space12),
      child: Row(
        children: [
          Container(
            height: 36,
            width: 36,
            decoration: BoxDecoration(
              color: (sideColor ?? Colors.grey).withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(AppDimens.radiusMedium),
            ),
            child: Icon(
              isBuy ? Icons.add_rounded : Icons.remove_rounded,
              color: sideColor,
              size: AppDimens.iconSmall,
            ),
          ),
          const SizedBox(width: AppDimens.space12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      '${isBuy ? 'Bought' : 'Sold'} ${transaction.symbol}',
                      style: theme.textTheme.titleSmall,
                    ),
                    if (isCancelled) ...[
                      const SizedBox(width: AppDimens.space8),
                      Text(
                        '· Cancelled',
                        style: theme.textTheme.bodySmall
                            ?.copyWith(color: AppColors.warning),
                      ),
                    ],
                  ],
                ),
                Text(
                  isCancelled && transaction.cancelReason != null
                      ? transaction.cancelReason!
                      : '${transaction.quantity.toStringAsFixed(6)} @ '
                          '${Formatters.currency(transaction.executedPrice ?? transaction.requestedPrice ?? 0)}'
                          ' · ${Formatters.relative(transaction.filledAt ?? transaction.createdAt)}',
                  style: theme.textTheme.bodySmall,
                ),
              ],
            ),
          ),
          if (!isCancelled && transaction.totalValue != null)
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  Formatters.currency(transaction.totalValue!),
                  style: theme.textTheme.titleSmall,
                ),
                if (transaction.realizedPnl != null)
                  Text(
                    '${transaction.realizedPnl! >= 0 ? '+' : ''}${Formatters.currency(transaction.realizedPnl!)}',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: transaction.realizedPnl! >= 0
                          ? AppColors.bullish
                          : AppColors.bearish,
                    ),
                  ),
              ],
            ),
        ],
      ),
    );
  }
}
