import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

/// Shared chart styling so every chart in the app (fl_chart candlesticks,
/// portfolio line charts, Syncfusion technical-indicator charts) shares
/// one consistent, premium fintech look rather than each screen picking
/// its own ad-hoc colors.
///
/// Consumed starting in Phase 4 (Markets) and Phase 6 (Portfolio).
class AppChartTheme {
  AppChartTheme._();

  /// Line/area color for a rising portfolio value or bullish trend line.
  static const Color lineUp = AppColors.bullish;

  /// Line/area color for a falling portfolio value or bearish trend line.
  static const Color lineDown = AppColors.bearish;

  /// Primary accent line (e.g. a single-asset price chart with no
  /// up/down semantic, or the main portfolio equity curve).
  static const Color linePrimary = AppColors.primary;

  /// Soft gradient fill under a line chart (electric blue, fading out).
  static List<Color> areaGradient(Color lineColor) => [
        lineColor.withValues(alpha: 0.28),
        lineColor.withValues(alpha: 0.0),
      ];

  /// Grid line color — kept very subtle on true-black backgrounds so it
  /// doesn't compete with the data itself.
  static Color gridColor(bool isDark) =>
      isDark ? Colors.white.withValues(alpha: 0.06) : Colors.black.withValues(alpha: 0.06);

  /// Axis label color.
  static Color axisLabelColor(bool isDark) =>
      isDark ? AppColors.darkTextSecondary : AppColors.lightTextSecondary;

  /// Candlestick colors (bullish/bearish candle body + wick).
  static const Color candleBullish = AppColors.bullish;
  static const Color candleBearish = AppColors.bearish;

  /// Tooltip container styling shared across chart types.
  static BoxDecoration tooltipDecoration(bool isDark) => BoxDecoration(
        color: isDark ? AppColors.darkSurfaceElevated : AppColors.lightSurface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: isDark ? AppColors.darkBorder : AppColors.lightBorder,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.4 : 0.1),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      );
}
