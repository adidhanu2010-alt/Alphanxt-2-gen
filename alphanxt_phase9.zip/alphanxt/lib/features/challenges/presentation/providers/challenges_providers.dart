import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_strings.dart';
import '../../../auth/presentation/providers/auth_providers.dart';
import '../../../learn/presentation/providers/learn_providers.dart';
import '../../../paper_trade/presentation/providers/trading_providers.dart';
import '../../../portfolio/presentation/providers/portfolio_providers.dart';
import '../../data/content/challenge_catalog.dart';
import '../../data/datasources/challenges_remote_datasource.dart';
import '../../data/datasources/leaderboard_remote_datasource.dart';
import '../../data/repositories/challenges_repository_impl.dart';
import '../../data/repositories/leaderboard_repository_impl.dart';
import '../../domain/challenge_evaluator.dart';
import '../../domain/entities/challenge_entity.dart';
import '../../domain/entities/leaderboard_entry_entity.dart';
import '../../domain/repositories/challenges_repository.dart';
import '../../domain/repositories/leaderboard_repository.dart';

// ---------------- Data / Repository ----------------

final challengesRemoteDataSourceProvider = Provider<ChallengesRemoteDataSource>((ref) {
  return ChallengesRemoteDataSource(ref.watch(firestoreProvider));
});

final challengesRepositoryProvider = Provider<ChallengesRepository>((ref) {
  return ChallengesRepositoryImpl(ref.watch(challengesRemoteDataSourceProvider));
});

final leaderboardRemoteDataSourceProvider = Provider<LeaderboardRemoteDataSource>((ref) {
  return LeaderboardRemoteDataSource(ref.watch(firestoreProvider));
});

final leaderboardRepositoryProvider = Provider<LeaderboardRepository>((ref) {
  return LeaderboardRepositoryImpl(ref.watch(leaderboardRemoteDataSourceProvider));
});

// ---------------- Live challenge progress ----------------

final claimedChallengesProvider =
    StreamProvider.autoDispose<List<ClaimedChallengeEntity>>((ref) {
  final uid = ref.watch(authRepositoryProvider).currentUid;
  if (uid == null) return Stream.value(const []);
  return ref.watch(challengesRepositoryProvider).watchClaimedChallenges(uid);
});

final challengeProgressProvider =
    Provider.autoDispose<List<ChallengeProgressEntity>>((ref) {
  final transactions = ref.watch(transactionHistoryProvider).valueOrNull ?? [];
  final courseProgress = ref.watch(courseProgressProvider).valueOrNull ?? [];

  return ChallengeEvaluator.evaluateAll(
    definitions: ChallengeCatalog.all,
    transactions: transactions,
    courseProgress: courseProgress,
    now: DateTime.now(),
  );
});

/// True XP total across BOTH course completions (Phase 8) and claimed
/// challenges (Phase 9) — this is the definitive total used everywhere
/// XP/Level is shown (Learn screen, Leaderboard).
final combinedXpSummaryProvider = Provider.autoDispose<XpSummary>((ref) {
  final courseProgress = ref.watch(courseProgressProvider).valueOrNull ?? [];
  final courseXp = courseProgress.fold<int>(0, (sum, p) => sum + p.xpEarned);

  final claimed = ref.watch(claimedChallengesProvider).valueOrNull ?? [];
  final challengeXp = claimed.fold<int>(0, (sum, c) {
    final def = ChallengeCatalog.byId(c.challengeId);
    return sum + (def?.xpReward ?? 0);
  });

  final totalXp = courseXp + challengeXp;
  const xpPerLevel = 100;
  return XpSummary(
    totalXp: totalXp,
    level: (totalXp ~/ xpPerLevel) + 1,
    xpIntoLevel: totalXp % xpPerLevel,
    xpForNextLevel: xpPerLevel,
  );
});

class ClaimActionState {
  final bool isLoading;
  const ClaimActionState({this.isLoading = false});
}

class ChallengeClaimController extends StateNotifier<ClaimActionState> {
  final ChallengesRepository _repository;
  final String? _uid;

  ChallengeClaimController(this._repository, this._uid)
      : super(const ClaimActionState());

  Future<bool> claim(ChallengeProgressEntity progress) async {
    final uid = _uid;
    if (uid == null || !progress.isCompleted) return false;
    state = const ClaimActionState(isLoading: true);
    final result = await _repository.claimChallenge(
      uid: uid,
      challengeId: progress.definition.id,
      periodKey: progress.periodKey,
    );
    state = const ClaimActionState();
    return result.isSuccess;
  }
}

final challengeClaimControllerProvider =
    StateNotifierProvider.autoDispose<ChallengeClaimController, ClaimActionState>((ref) {
  return ChallengeClaimController(
    ref.watch(challengesRepositoryProvider),
    ref.watch(authRepositoryProvider).currentUid,
  );
});

// ---------------- Leaderboard ----------------

final leaderboardByXpProvider =
    StreamProvider.autoDispose<List<LeaderboardEntryEntity>>((ref) {
  return ref.watch(leaderboardRepositoryProvider).watchTopByXp();
});

final leaderboardByReturnsProvider =
    StreamProvider.autoDispose<List<LeaderboardEntryEntity>>((ref) {
  return ref.watch(leaderboardRepositoryProvider).watchTopByReturns();
});

/// Publishes the current user's own stats to the leaderboard whenever
/// the Challenges/Leaderboard screen is opened, keeping their entry
/// reasonably fresh without needing a backend job.
final leaderboardSyncProvider = FutureProvider.autoDispose<void>((ref) async {
  final uid = ref.watch(authRepositoryProvider).currentUid;
  final profile = ref.watch(currentUserProfileProvider).valueOrNull;
  if (uid == null || profile == null) return;

  final xp = ref.watch(combinedXpSummaryProvider);
  final portfolio = ref.watch(portfolioSummaryProvider);

  final returnPercent = AppStrings.startingVirtualBalance == 0
      ? 0.0
      : ((portfolio.totalValue - AppStrings.startingVirtualBalance) /
              AppStrings.startingVirtualBalance) *
          100;

  await ref.read(leaderboardRepositoryProvider).updateMyEntry(
        uid: uid,
        displayName: profile.displayName.isNotEmpty ? profile.displayName : 'Trader',
        photoUrl: profile.photoUrl,
        totalXp: xp.totalXp,
        portfolioReturnPercent: returnPercent,
      );
});
