import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/utils/formatters.dart';
import '../../../paper_trade/domain/entities/position_entity.dart';

/// Pie chart breaking down current holdings by market value, with a
/// legend listing each asset's % share.
class AllocationPieChart extends StatelessWidget {
  final List<PositionEntity> positions;
  final Map<String, double> currentPrices;

  const AllocationPieChart({
    super.key,
    required this.positions,
    required this.currentPrices,
  });

  static const _palette = [
    Color(0xFF3B82F6),
    Color(0xFF22C55E),
    Color(0xFFF59E0B),
    Color(0xFFA855F7),
    Color(0xFFEF4444),
    Color(0xFF06B6D4),
    Color(0xFFEC4899),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (positions.isEmpty) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(AppDimens.space16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Allocation', style: theme.textTheme.titleSmall),
              const SizedBox(height: AppDimens.space12),
              Text(
                'Your holdings breakdown will appear here once you open a position.',
                style: theme.textTheme.bodySmall,
              ),
            ],
          ),
        ),
      );
    }

    final values = <String, double>{};
    for (final p in positions) {
      final price = currentPrices[p.assetId] ?? p.avgBuyPrice;
      values[p.symbol] = p.marketValue(price);
    }
    final total = values.values.fold<double>(0, (a, b) => a + b);
    final entries = values.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Allocation', style: theme.textTheme.titleSmall),
            const SizedBox(height: AppDimens.space16),
            Row(
              children: [
                SizedBox(
                  height: 140,
                  width: 140,
                  child: PieChart(
                    PieChartData(
                      sectionsSpace: 2,
                      centerSpaceRadius: 36,
                      sections: List.generate(entries.length, (i) {
                        return PieChartSectionData(
                          value: entries[i].value,
                          color: _palette[i % _palette.length],
                          radius: 28,
                          showTitle: false,
                        );
                      }),
                    ),
                  ),
                ),
                const SizedBox(width: AppDimens.space16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: List.generate(entries.length, (i) {
                      final share = total == 0 ? 0.0 : entries[i].value / total * 100;
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 3),
                        child: Row(
                          children: [
                            Container(
                              height: 10,
                              width: 10,
                              decoration: BoxDecoration(
                                color: _palette[i % _palette.length],
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: AppDimens.space8),
                            Expanded(
                              child: Text(
                                entries[i].key,
                                style: theme.textTheme.bodySmall,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Text(
                              '${share.toStringAsFixed(0)}%',
                              style: theme.textTheme.bodySmall
                                  ?.copyWith(fontWeight: FontWeight.w700),
                            ),
                          ],
                        ),
                      );
                    }),
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppDimens.space8),
            Text(
              'Total invested: ${Formatters.currency(total)}',
              style: theme.textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}
