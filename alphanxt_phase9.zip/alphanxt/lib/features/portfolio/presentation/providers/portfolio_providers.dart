import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../auth/presentation/providers/auth_providers.dart';
import '../../../markets/presentation/providers/market_providers.dart';
import '../../../paper_trade/presentation/providers/trading_providers.dart';
import '../../data/datasources/portfolio_remote_datasource.dart';
import '../../data/repositories/portfolio_repository_impl.dart';
import '../../domain/entities/portfolio_snapshot_entity.dart';
import '../../domain/repositories/portfolio_repository.dart';
import '../../domain/risk_score_calculator.dart';

// ---------------- Data / Repository ----------------

final portfolioRemoteDataSourceProvider = Provider<PortfolioRemoteDataSource>((ref) {
  return PortfolioRemoteDataSource(ref.watch(firestoreProvider));
});

final portfolioRepositoryProvider = Provider<PortfolioRepository>((ref) {
  return PortfolioRepositoryImpl(ref.watch(portfolioRemoteDataSourceProvider));
});

// ---------------- Live prices + 24h change for held assets ----------------

/// Extends Phase 5's heldAssetPricesProvider concept with 24h % change
/// too (needed for the risk score's volatility factor).
final heldAssetMarketDataProvider =
    FutureProvider.autoDispose<Map<String, ({double price, double change24h})>>((ref) async {
  final positions = ref.watch(openPositionsProvider).valueOrNull ?? [];
  final ids = positions.map((p) => p.assetId).toSet().toList();
  if (ids.isEmpty) return {};

  final result = await ref.read(marketRepositoryProvider).getAssetsByIds(ids);
  return result.when(
    success: (assets) => {
      for (final a in assets)
        a.id: (price: a.currentPrice, change24h: a.priceChangePercent24h)
    },
    failure: (_) => {},
  );
});

// ---------------- Aggregate portfolio value ----------------

class PortfolioSummary {
  final double cashBalance;
  final double investedValue;
  final double totalValue;
  final double unrealizedPnl;
  final double realizedPnl;
  final double totalPnl;

  const PortfolioSummary({
    required this.cashBalance,
    required this.investedValue,
    required this.totalValue,
    required this.unrealizedPnl,
    required this.realizedPnl,
    required this.totalPnl,
  });

  static const empty = PortfolioSummary(
    cashBalance: 0,
    investedValue: 0,
    totalValue: 0,
    unrealizedPnl: 0,
    realizedPnl: 0,
    totalPnl: 0,
  );
}

final portfolioSummaryProvider = Provider.autoDispose<PortfolioSummary>((ref) {
  final profile = ref.watch(currentUserProfileProvider).valueOrNull;
  final openPositions = ref.watch(openPositionsProvider).valueOrNull ?? [];
  final closedPositions = ref.watch(closedPositionsProvider).valueOrNull ?? [];
  final marketData = ref.watch(heldAssetMarketDataProvider).valueOrNull ?? {};

  if (profile == null) return PortfolioSummary.empty;

  final cashBalance = profile.virtualBalance;
  double investedValue = 0;
  double unrealizedPnl = 0;

  for (final p in openPositions) {
    final price = marketData[p.assetId]?.price ?? p.avgBuyPrice;
    investedValue += p.marketValue(price);
    unrealizedPnl += p.unrealizedPnl(price);
  }

  double realizedPnl = 0;
  for (final p in openPositions) {
    realizedPnl += p.realizedPnl;
  }
  for (final p in closedPositions) {
    realizedPnl += p.realizedPnl;
  }

  return PortfolioSummary(
    cashBalance: cashBalance,
    investedValue: investedValue,
    totalValue: cashBalance + investedValue,
    unrealizedPnl: unrealizedPnl,
    realizedPnl: realizedPnl,
    totalPnl: unrealizedPnl + realizedPnl,
  );
});

// ---------------- Risk score ----------------

final riskScoreProvider = Provider.autoDispose<RiskScoreResult>((ref) {
  final openPositions = ref.watch(openPositionsProvider).valueOrNull ?? [];
  final marketData = ref.watch(heldAssetMarketDataProvider).valueOrNull ?? {};
  final profile = ref.watch(currentUserProfileProvider).valueOrNull;

  return RiskScoreCalculator.calculate(
    openPositions: openPositions,
    currentPrices: {for (final e in marketData.entries) e.key: e.value.price},
    priceChangePercent24h: {
      for (final e in marketData.entries) e.key: e.value.change24h
    },
    cashBalance: profile?.virtualBalance ?? 0,
  );
});

// ---------------- Value history / snapshots ----------------

final portfolioSnapshotsProvider =
    StreamProvider.autoDispose<List<PortfolioSnapshotEntity>>((ref) {
  final uid = ref.watch(authRepositoryProvider).currentUid;
  if (uid == null) return Stream.value(const []);
  return ref.watch(portfolioRepositoryProvider).watchSnapshots(uid, days: 30);
});

/// Records today's snapshot (once) whenever the Portfolio screen is open
/// and the summary has finished loading. Watching this provider from the
/// Portfolio screen is what triggers the recording — see
/// [PortfolioSnapshotEntity] docs for the "only while app is open" caveat.
final snapshotRecorderProvider = FutureProvider.autoDispose<void>((ref) async {
  final uid = ref.watch(authRepositoryProvider).currentUid;
  if (uid == null) return;

  final profile = ref.watch(currentUserProfileProvider).valueOrNull;
  final positionsAsync = ref.watch(openPositionsProvider);
  final marketDataAsync = ref.watch(heldAssetMarketDataProvider);

  // Wait until everything needed has actually loaded at least once, so we
  // don't record a snapshot using a stale/zero invested value.
  if (profile == null || !positionsAsync.hasValue || !marketDataAsync.hasValue) {
    return;
  }

  final summary = ref.read(portfolioSummaryProvider);
  await ref.read(portfolioRepositoryProvider).recordDailySnapshotIfNeeded(
        uid: uid,
        totalValue: summary.totalValue,
        cashBalance: summary.cashBalance,
        investedValue: summary.investedValue,
      );
});
