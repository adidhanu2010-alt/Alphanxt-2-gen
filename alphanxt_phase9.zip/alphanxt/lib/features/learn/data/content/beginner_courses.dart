import '../../domain/entities/course_entity.dart';

/// Beginner-level courses: the foundational concepts every new trader
/// should understand before anything else. Content authored for
/// AlphaNXT — accurate, general trading education, not financial advice.
class BeginnerCourses {
  BeginnerCourses._();

  static const candlesticks = CourseEntity(
    id: 'candlesticks',
    title: 'Reading Candlesticks',
    level: CourseLevel.beginner,
    description: 'Learn what a candlestick shows and why traders use them.',
    iconKey: 'candlestick_chart',
    estimatedMinutes: 6,
    xpReward: 50,
    lessonContent: '''
A candlestick shows four prices for a time period: the open, high, low, and close. The thick part — the "body" — spans the open and close. If the close is above the open, the body is typically colored green or white (bullish); if the close is below the open, it's red or black (bearish). The thin lines above and below the body — the "wicks" or "shadows" — show the highest and lowest prices reached during that period.

A single candle tells you the story of a battle between buyers and sellers over that period. A long body means one side won decisively. A small body with long wicks (sometimes called a "doji" when open and close are nearly equal) suggests indecision — buyers and sellers fought to a draw.

Candlestick patterns emerge when you look at a few candles together. For example, a small-bodied candle following a long bearish candle can suggest selling pressure is fading. No single candle or pattern predicts the future with certainty — they're one input among many that traders use to gauge market sentiment at a glance.
''',
    quiz: [
      QuizQuestionEntity(
        id: 'c1',
        question: 'What does the body of a candlestick represent?',
        options: [
          'The highest and lowest price of the period',
          'The range between the open and close price',
          'The trading volume for that period',
          'The average price over the period',
        ],
        correctIndex: 1,
        explanation: 'The body spans from the opening price to the closing price for that time period.',
      ),
      QuizQuestionEntity(
        id: 'c2',
        question: 'What do the thin lines above and below the body show?',
        options: [
          'Support and resistance levels',
          'The 24-hour average price',
          'The highest and lowest prices reached in the period',
          'The next period\'s predicted range',
        ],
        correctIndex: 2,
        explanation: 'These "wicks" or "shadows" mark the high and low extremes reached during the period.',
      ),
      QuizQuestionEntity(
        id: 'c3',
        question: 'A candle with a small body and long wicks on both sides generally suggests:',
        options: [
          'A guaranteed reversal is coming',
          'Indecision between buyers and sellers',
          'The asset is about to be delisted',
          'Extremely low trading volume',
        ],
        correctIndex: 1,
        explanation: 'A small body with long wicks means price moved a lot in both directions but ended close to where it started — a tug-of-war with no clear winner.',
      ),
    ],
  );

  static const supportResistance = CourseEntity(
    id: 'support_resistance',
    title: 'Support & Resistance',
    level: CourseLevel.beginner,
    description: 'The price levels where buying or selling pressure tends to show up.',
    iconKey: 'horizontal_rule',
    estimatedMinutes: 7,
    xpReward: 50,
    lessonContent: '''
Support is a price level where an asset has historically stopped falling and bounced back up — it's where buying interest has repeatedly shown up. Resistance is the opposite: a price level where an asset has historically stopped rising and turned back down, where selling interest has repeatedly appeared.

These levels form because traders remember them. If an asset bounced off ₹100 three times before, many traders will watch ₹100 closely again — some will buy there expecting another bounce, which can become a self-fulfilling pattern for a while.

Support and resistance aren't exact lines; think of them as zones. Price often pierces through slightly before reversing, or breaks through cleanly when the pressure at that level is finally overwhelmed. When a resistance level is broken decisively, it often becomes a new support level going forward (and vice versa) — a concept called "role reversal."

These levels are historical observations, not guarantees. An asset can blow through support or resistance at any time if new information changes how the market feels about it.
''',
    quiz: [
      QuizQuestionEntity(
        id: 's1',
        question: 'Support is best described as:',
        options: [
          'A price level where selling pressure has repeatedly appeared',
          'A price level where buying pressure has repeatedly appeared',
          'The average price over the last 30 days',
          'A level set by a regulator',
        ],
        correctIndex: 1,
        explanation: 'Support is where buyers have historically stepped in, stopping further declines.',
      ),
      QuizQuestionEntity(
        id: 's2',
        question: 'What is "role reversal" in support/resistance?',
        options: [
          'When a broken resistance level becomes new support (or vice versa)',
          'When a stock reverses its stock split',
          'When volume flips from buyers to sellers instantly',
          'A rule requiring brokers to reverse trades',
        ],
        correctIndex: 0,
        explanation: 'Once resistance is broken, it often acts as support on future pullbacks, and vice versa.',
      ),
      QuizQuestionEntity(
        id: 's3',
        question: 'Support and resistance levels should be treated as:',
        options: [
          'Exact, unbreakable prices',
          'Guaranteed reversal points',
          'Zones or approximate areas, not precise lines',
          'Irrelevant once identified',
        ],
        correctIndex: 2,
        explanation: 'Price often overshoots slightly, so these levels are better thought of as zones of interest.',
      ),
    ],
  );

  static const riskManagement = CourseEntity(
    id: 'risk_management',
    title: 'Risk Management',
    level: CourseLevel.beginner,
    description: 'How traders protect their capital — arguably the most important skill.',
    iconKey: 'shield',
    estimatedMinutes: 8,
    xpReward: 60,
    lessonContent: '''
Risk management is about controlling how much you can lose, not predicting how much you'll win. It's the difference between traders who survive long enough to improve and those who don't.

A core idea is risking only a small percentage of your total account on any single trade — many traders think in terms of 1-2% per trade. That way, a string of losses (which happens to everyone) doesn't wipe out the account. If you risk 20% per trade, just five bad trades in a row can be catastrophic; at 1-2%, it takes far longer and gives you room to learn.

A stop-loss is an order that automatically exits a position if the price moves against you past a certain point — it caps your downside before you even place the trade, removing the temptation to "hope it comes back" once emotions are involved.

Position sizing — how many units you buy relative to your account size and your stop-loss distance — connects your risk percentage to an actual trade. A wider stop-loss (more room for the price to move) should generally mean a smaller position size, so your total ₹ risk stays consistent.

Risk management does not guarantee profits. It manages the downside so that when you are right, you're still in the game.
''',
    quiz: [
      QuizQuestionEntity(
        id: 'r1',
        question: 'What is a commonly cited guideline for risk per trade?',
        options: ['50% of account', '20-30% of account', '1-2% of account', 'No limit needed'],
        correctIndex: 2,
        explanation: 'Risking a small, consistent percentage per trade helps an account survive a losing streak.',
      ),
      QuizQuestionEntity(
        id: 'r2',
        question: 'A stop-loss order does what?',
        options: [
          'Guarantees a profit on the trade',
          'Automatically exits a position once price moves against you past a set point',
          'Increases your position size automatically',
          'Cancels all your other open orders',
        ],
        correctIndex: 1,
        explanation: 'It caps downside risk by exiting automatically at a pre-decided price.',
      ),
      QuizQuestionEntity(
        id: 'r3',
        question: 'If your stop-loss is placed further from your entry, position size should typically be:',
        options: ['Larger, to compensate', 'Smaller, to keep total ₹ risk consistent', 'Unrelated to stop distance', 'Doubled automatically'],
        correctIndex: 1,
        explanation: 'A wider stop means more risk per unit, so a smaller position keeps your total risk in line with your plan.',
      ),
    ],
  );

  static const tradingPsychology = CourseEntity(
    id: 'trading_psychology',
    title: 'Trading Psychology',
    level: CourseLevel.beginner,
    description: 'The mental patterns that shape trading decisions — for better or worse.',
    iconKey: 'psychology',
    estimatedMinutes: 7,
    xpReward: 50,
    lessonContent: '''
Trading puts money and uncertainty together, which makes it a strong trigger for emotional decision-making. Two of the most common patterns are loss aversion (the pain of losing feels stronger than the pleasure of an equivalent gain) and the disposition effect (a tendency to sell winners too early and hold losers too long, hoping they'll recover).

Fear and greed are the classic pair: fear can cause a trader to exit a good trade too early or avoid taking a valid setup entirely; greed can cause overtrading, oversized positions, or holding a winning trade past the point the original plan called for exiting.

Revenge trading — trying to immediately win back a loss with a bigger, less-planned trade — is one of the most damaging patterns, because it replaces a plan with an emotional reaction.

A trading journal (recording why you entered, why you exited, and how you felt) is one of the most effective tools for building self-awareness over time. Recognizing these patterns in yourself doesn't eliminate them, but it makes it far easier to pause before repeating a costly one.
''',
    quiz: [
      QuizQuestionEntity(
        id: 'p1',
        question: 'The "disposition effect" describes a tendency to:',
        options: [
          'Sell winners too early and hold losers too long',
          'Always follow a trading plan perfectly',
          'Trade only during market hours',
          'Avoid all risk entirely',
        ],
        correctIndex: 0,
        explanation: 'Traders often lock in small wins quickly while holding losing positions hoping for a recovery.',
      ),
      QuizQuestionEntity(
        id: 'p2',
        question: 'Revenge trading refers to:',
        options: [
          'A well-planned trade after research',
          'Trying to immediately win back a loss with an impulsive, larger trade',
          'A type of limit order',
          'Trading two assets that move opposite to each other',
        ],
        correctIndex: 1,
        explanation: 'It replaces a plan with an emotional reaction to a recent loss, often compounding the damage.',
      ),
      QuizQuestionEntity(
        id: 'p3',
        question: 'A trading journal primarily helps by:',
        options: [
          'Guaranteeing future profits',
          'Building self-awareness of your own patterns over time',
          'Automatically executing trades',
          'Replacing the need for a trading plan',
        ],
        correctIndex: 1,
        explanation: 'Reviewing your own entries, exits, and reasoning helps surface recurring emotional patterns.',
      ),
    ],
  );

  static const all = [candlesticks, supportResistance, riskManagement, tradingPsychology];
}
