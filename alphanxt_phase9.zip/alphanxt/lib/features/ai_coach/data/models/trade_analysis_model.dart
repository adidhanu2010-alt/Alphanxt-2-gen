import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/trade_analysis_entity.dart';
import '../../domain/entities/trade_metrics.dart';

class TradeAnalysisModel extends TradeAnalysisEntity {
  const TradeAnalysisModel({
    required super.metrics,
    required super.summary,
    required super.whatWentWell,
    required super.mistakes,
    required super.riskManagementTips,
    required super.entryExitTips,
    required super.lessons,
    required super.generatedAt,
  });

  /// Parses the AI's narrative JSON response (metrics are NOT expected
  /// here — they're computed locally and passed in separately).
  factory TradeAnalysisModel.fromAiJson(
    Map<String, dynamic> json,
    TradeMetrics metrics,
  ) {
    List<String> _list(dynamic v) =>
        (v as List?)?.map((e) => e.toString()).toList() ?? [];

    return TradeAnalysisModel(
      metrics: metrics,
      summary: json['summary'] as String? ?? '',
      whatWentWell: _list(json['whatWentWell']),
      mistakes: _list(json['mistakes']),
      riskManagementTips: _list(json['riskManagementTips']),
      entryExitTips: _list(json['entryExitTips']),
      lessons: _list(json['lessons']),
      generatedAt: DateTime.now(),
    );
  }

  /// Cache format written to/read from Firestore — includes the
  /// narrative only (metrics are cheap to recompute locally each time
  /// from the position/price data, so they aren't duplicated in cache).
  factory TradeAnalysisModel.fromCacheMap(
    Map<String, dynamic> map,
    TradeMetrics metrics,
  ) {
    List<String> _list(dynamic v) =>
        (v as List?)?.map((e) => e.toString()).toList() ?? [];

    return TradeAnalysisModel(
      metrics: metrics,
      summary: map['summary'] as String? ?? '',
      whatWentWell: _list(map['whatWentWell']),
      mistakes: _list(map['mistakes']),
      riskManagementTips: _list(map['riskManagementTips']),
      entryExitTips: _list(map['entryExitTips']),
      lessons: _list(map['lessons']),
      generatedAt:
          (map['generatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toCacheMap() {
    return {
      'summary': summary,
      'whatWentWell': whatWentWell,
      'mistakes': mistakes,
      'riskManagementTips': riskManagementTips,
      'entryExitTips': entryExitTips,
      'lessons': lessons,
      'generatedAt': Timestamp.fromDate(generatedAt),
    };
  }
}
