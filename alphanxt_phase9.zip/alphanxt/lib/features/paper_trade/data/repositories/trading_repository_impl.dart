import '../../../../core/errors/failures.dart';
import '../../../../core/errors/result.dart';
import '../../../../core/utils/app_logger.dart';
import '../../../markets/domain/entities/asset_entity.dart';
import '../../domain/entities/order_enums.dart';
import '../../domain/entities/position_entity.dart';
import '../../domain/entities/transaction_entity.dart';
import '../../domain/repositories/trading_repository.dart';
import '../datasources/trading_remote_datasource.dart';

class TradingRepositoryImpl implements TradingRepository {
  final TradingRemoteDataSource _remote;

  TradingRepositoryImpl(this._remote);

  @override
  Future<Result<void>> placeMarketOrder({
    required String uid,
    required AssetEntity asset,
    required OrderSide side,
    required double quantity,
    required double currentMarketPrice,
    double? stopLoss,
    double? takeProfit,
    String? positionId,
  }) async {
    try {
      if (side == OrderSide.buy) {
        await _remote.executeMarketBuy(
          uid: uid,
          asset: asset,
          quantity: quantity,
          price: currentMarketPrice,
          stopLoss: stopLoss,
          takeProfit: takeProfit,
        );
      } else {
        if (positionId == null) {
          return Result.failure(
            const TradeFailure('No position selected to sell.'),
          );
        }
        await _remote.executeMarketSell(
          uid: uid,
          positionId: positionId,
          quantity: quantity,
          price: currentMarketPrice,
        );
      }
      return Result.success(null);
    } on TradingException catch (e) {
      return Result.failure(TradeFailure(e.message));
    } catch (e, st) {
      AppLogger.error('placeMarketOrder failed', e, st);
      return Result.failure(const UnknownFailure());
    }
  }

  @override
  Future<Result<void>> placeLimitOrder({
    required String uid,
    required AssetEntity asset,
    required OrderSide side,
    required double quantity,
    required double limitPrice,
    double? stopLoss,
    double? takeProfit,
    String? positionId,
  }) async {
    try {
      await _remote.createPendingOrder(
        uid: uid,
        asset: asset,
        side: side,
        quantity: quantity,
        limitPrice: limitPrice,
        stopLoss: stopLoss,
        takeProfit: takeProfit,
        positionId: positionId,
      );
      return Result.success(null);
    } catch (e, st) {
      AppLogger.error('placeLimitOrder failed', e, st);
      return Result.failure(const UnknownFailure());
    }
  }

  @override
  Future<Result<void>> cancelPendingOrder(String uid, String transactionId) async {
    try {
      await _remote.cancelPendingOrder(transactionId, reason: 'Cancelled by user');
      return Result.success(null);
    } catch (e, st) {
      AppLogger.error('cancelPendingOrder failed', e, st);
      return Result.failure(const UnknownFailure());
    }
  }

  @override
  Future<Result<void>> checkPendingTriggers({
    required String uid,
    required Map<String, double> latestPrices,
  }) async {
    try {
      // ---- 1. Pending limit orders ----
      final pendingOrders = await _remote.getPendingOrders(uid);
      for (final order in pendingOrders) {
        final currentPrice = latestPrices[order.assetId];
        if (currentPrice == null || order.requestedPrice == null) continue;

        final shouldFillBuy =
            order.side == OrderSide.buy && currentPrice <= order.requestedPrice!;
        final shouldFillSell =
            order.side == OrderSide.sell && currentPrice >= order.requestedPrice!;

        if (!shouldFillBuy && !shouldFillSell) continue;

        try {
          if (order.side == OrderSide.buy) {
            await _remote.executeMarketBuy(
              uid: uid,
              asset: AssetEntity(
                id: order.assetId,
                symbol: order.symbol,
                name: order.name,
                imageUrl: order.imageUrl,
                type: AssetType.crypto,
                currentPrice: currentPrice,
                priceChangePercent24h: 0,
              ),
              quantity: order.quantity,
              price: currentPrice,
              stopLoss: order.stopLoss,
              takeProfit: order.takeProfit,
              orderType: OrderType.limit,
              requestedPrice: order.requestedPrice,
            );
          } else if (order.positionId != null) {
            await _remote.executeMarketSell(
              uid: uid,
              positionId: order.positionId!,
              quantity: order.quantity,
              price: currentPrice,
              orderType: OrderType.limit,
              requestedPrice: order.requestedPrice,
            );
          }
          // Remove the pending record now that it's filled — a fresh
          // 'filled' transaction was already written by executeMarketBuy/Sell.
          await _remote.deleteOrder(order.id);
        } on TradingException catch (e) {
          // e.g. insufficient balance by the time the price was hit —
          // auto-cancel with a clear reason rather than retry forever.
          await _remote.cancelPendingOrder(order.id, reason: e.message);
        }
      }

      // ---- 2. Stop-loss / take-profit on open positions ----
      final triggerPositions = await _remote.getOpenPositionsWithTriggers(uid);
      for (final position in triggerPositions) {
        final currentPrice = latestPrices[position.assetId];
        if (currentPrice == null) continue;

        final hitStopLoss =
            position.stopLoss != null && currentPrice <= position.stopLoss!;
        final hitTakeProfit =
            position.takeProfit != null && currentPrice >= position.takeProfit!;

        if (!hitStopLoss && !hitTakeProfit) continue;

        try {
          await _remote.executeMarketSell(
            uid: uid,
            positionId: position.id,
            quantity: position.quantity,
            price: currentPrice,
          );
        } on TradingException catch (e) {
          AppLogger.warning('SL/TP auto-close failed for ${position.id}: $e');
        }
      }

      return Result.success(null);
    } catch (e, st) {
      AppLogger.error('checkPendingTriggers failed', e, st);
      return Result.failure(const UnknownFailure());
    }
  }

  @override
  Stream<List<PositionEntity>> watchOpenPositions(String uid) {
    return _remote.watchOpenPositions(uid);
  }

  @override
  Stream<List<PositionEntity>> watchClosedPositions(String uid) {
    return _remote.watchClosedPositions(uid);
  }

  @override
  Stream<List<TransactionEntity>> watchPendingOrders(String uid) {
    return _remote.watchPendingOrders(uid);
  }

  @override
  Stream<List<TransactionEntity>> watchTransactionHistory(String uid) {
    return _remote.watchTransactionHistory(uid);
  }
}
