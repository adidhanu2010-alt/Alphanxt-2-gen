import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../../core/constants/app_strings.dart';
import '../models/portfolio_snapshot_model.dart';

/// Stores daily portfolio value snapshots as documents in the same
/// `portfolio` Firestore collection used for positions (Phase 5),
/// distinguished by `type: 'snapshot'` (positions have no `type` field,
/// so existing position queries — which filter on `status` — are
/// unaffected). Doc id is `{uid}_snapshot_{yyyy-MM-dd}`, making the
/// "already recorded today?" check and the write both simple, idempotent
/// operations.
class PortfolioRemoteDataSource {
  final FirebaseFirestore _firestore;

  PortfolioRemoteDataSource(this._firestore);

  CollectionReference<Map<String, dynamic>> get _portfolioRef =>
      _firestore.collection(AppStrings.collectionPortfolio);

  String _snapshotDocId(String uid, DateTime date) {
    final d = '${date.year.toString().padLeft(4, '0')}-'
        '${date.month.toString().padLeft(2, '0')}-'
        '${date.day.toString().padLeft(2, '0')}';
    return '${uid}_snapshot_$d';
  }

  Future<void> recordDailySnapshotIfNeeded({
    required String uid,
    required double totalValue,
    required double cashBalance,
    required double investedValue,
  }) async {
    final today = DateTime.now();
    final docRef = _portfolioRef.doc(_snapshotDocId(uid, today));
    final existing = await docRef.get();
    if (existing.exists) return; // already recorded today

    final snapshot = PortfolioSnapshotModel(
      date: today,
      totalValue: totalValue,
      cashBalance: cashBalance,
      investedValue: investedValue,
    );
    await docRef.set(snapshot.toMap(uid));
  }

  Stream<List<PortfolioSnapshotModel>> watchSnapshots(String uid, {int days = 30}) {
    final cutoff = DateTime.now().subtract(Duration(days: days));
    return _portfolioRef
        .where('uid', isEqualTo: uid)
        .where('type', isEqualTo: 'snapshot')
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(cutoff))
        .snapshots()
        .map((snap) => snap.docs
            .map((d) => PortfolioSnapshotModel.fromMap(d.data()))
            .toList()
          ..sort((a, b) => a.date.compareTo(b.date)));
  }
}
