import '../../../../core/errors/result.dart';
import '../entities/course_progress_entity.dart';

/// Contract for course-progress and badge persistence. Course *content*
/// (lessons/quizzes) is static and lives in `data/content/` — this
/// repository only deals with the user-specific, real-time state of
/// their learning journey.
abstract class LearnRepository {
  Stream<List<CourseProgressEntity>> watchProgress(String uid);

  Future<Result<void>> markLessonRead(String uid, String courseId);

  /// Records a quiz attempt. XP is only credited the first time a course
  /// is completed (lesson read + quiz passed) to prevent XP farming via
  /// repeated retakes — retakes still update the best score shown.
  Future<Result<void>> submitQuizResult({
    required String uid,
    required String courseId,
    required int scorePercent,
    required int xpReward,
  });

  Stream<List<EarnedBadgeEntity>> watchEarnedBadges(String uid);

  Future<Result<void>> awardBadgeIfNotEarned(String uid, String badgeId);
}
