import 'package:equatable/equatable.dart';

/// A single price point in a time series.
///
/// CoinGecko's free market-chart endpoint returns close-price-only time
/// series (no true OHLC candles), so this is intentionally a simple
/// price+timestamp point — sufficient for line charts and for computing
/// technical indicators (SMA, RSI) client-side. If a provider with true
/// OHLC data is added later, [PricePointEntity] can be extended with
/// open/high/low/volume without breaking existing chart code.
class PricePointEntity extends Equatable {
  final DateTime timestamp;
  final double price;

  const PricePointEntity({required this.timestamp, required this.price});

  @override
  List<Object?> get props => [timestamp, price];
}
