import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';

class OnboardingPageData {
  final IconData icon;
  final String title;
  final String body;

  const OnboardingPageData({
    required this.icon,
    required this.title,
    required this.body,
  });
}

/// A single onboarding slide — large icon in a glowing gradient badge,
/// title, and supporting body copy.
class OnboardingPageView extends StatelessWidget {
  final OnboardingPageData data;

  const OnboardingPageView({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppDimens.space32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: 140,
            width: 140,
            decoration: BoxDecoration(
              gradient: AppColors.heroGlowGradient,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: AppColors.primary.withValues(alpha: 0.35),
                  blurRadius: 40,
                  spreadRadius: 4,
                ),
              ],
            ),
            child: Icon(data.icon, size: 64, color: Colors.white),
          ).animate().scale(duration: 450.ms, curve: Curves.easeOutBack).fadeIn(),
          const SizedBox(height: AppDimens.space40),
          Text(
            data.title,
            textAlign: TextAlign.center,
            style: theme.textTheme.headlineMedium,
          ).animate().fadeIn(delay: 150.ms, duration: 400.ms).slideY(begin: 0.15, end: 0),
          const SizedBox(height: AppDimens.space16),
          Text(
            data.body,
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyLarge?.copyWith(
              color: theme.textTheme.bodySmall?.color,
            ),
          ).animate().fadeIn(delay: 250.ms, duration: 400.ms).slideY(begin: 0.15, end: 0),
        ],
      ),
    );
  }
}
