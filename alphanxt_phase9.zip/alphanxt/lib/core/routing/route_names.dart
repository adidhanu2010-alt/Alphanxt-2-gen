/// Centralized route path constants for go_router.
///
/// Kept separate from app_router.dart so feature modules can reference
/// paths (e.g. for `context.go(RouteNames.login)`) without importing the
/// full router configuration.
class RouteNames {
  RouteNames._();

  // ---------------- Auth ----------------
  static const String splash = '/splash';
  static const String onboarding = '/onboarding';
  static const String login = '/login';
  static const String register = '/register';
  static const String forgotPassword = '/forgot-password';
  static const String verifyEmail = '/verify-email';

  // ---------------- Shell (Bottom Nav) ----------------
  static const String home = '/home';
  static const String markets = '/markets';
  static const String paperTrade = '/paper-trade';
  static const String portfolio = '/portfolio';
  static const String learn = '/learn';
  static const String profile = '/profile';

  // ---------------- Detail routes (added in later phases) ----------------
  /// Nested under /markets — see app_router.dart. Use [assetDetailPath].
  static String assetDetailPath(String assetId) => '$markets/asset/$assetId';

  /// Top-level (outside the bottom-nav shell) so it works as a focused
  /// full-screen push regardless of which tab it was opened from.
  static String tradeFormPath(String assetId, {String side = 'buy'}) =>
      '/trade/$assetId?side=$side';
  static const String courseDetail = '/learn/course';
  static const String editProfile = '/profile/edit';
  static const String settings = '/profile/settings';
}
