import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/routing/route_names.dart';
import '../../../../core/utils/formatters.dart';
import '../../../../core/widgets/primary_button.dart';
import '../../domain/entities/asset_detail_entity.dart';
import '../providers/market_providers.dart';
import '../widgets/price_chart.dart';
import '../widgets/range_selector.dart';
import '../widgets/technical_indicators_card.dart';

class AssetDetailScreen extends ConsumerWidget {
  final String assetId;

  const AssetDetailScreen({super.key, required this.assetId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final detailAsync = ref.watch(assetDetailProvider(assetId));
    final priceHistoryAsync = ref.watch(priceHistoryProvider(assetId));
    final selectedRange = ref.watch(chartRangeProvider);
    final watchlistIds = ref.watch(watchlistIdsProvider).valueOrNull ?? [];
    final isWatchlisted = watchlistIds.contains(assetId);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: detailAsync.value != null ? Text(detailAsync.value!.name) : null,
        actions: [
          detailAsync.maybeWhen(
            data: (asset) => IconButton(
              icon: Icon(
                isWatchlisted ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
                color: isWatchlisted ? AppColors.primary : null,
              ),
              onPressed: () => ref
                  .read(watchlistControllerProvider.notifier)
                  .toggle(asset, isWatchlisted),
            ),
            orElse: () => const SizedBox.shrink(),
          ),
        ],
      ),
      body: SafeArea(
        child: detailAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(
            child: Padding(
              padding: const EdgeInsets.all(AppDimens.space24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.cloud_off_rounded, size: 40),
                  const SizedBox(height: AppDimens.space12),
                  Text('Could not load this asset.', style: theme.textTheme.bodyMedium),
                  const SizedBox(height: AppDimens.space12),
                  OutlinedButton(
                    onPressed: () => ref.invalidate(assetDetailProvider(assetId)),
                    child: const Text('Retry'),
                  ),
                ],
              ),
            ),
          ),
          data: (asset) {
            final changeColor =
                asset.isPositive24h ? AppColors.bullish : AppColors.bearish;

            return ListView(
              padding: const EdgeInsets.all(AppDimens.space20),
              children: [
                Row(
                  children: [
                    if (asset.imageUrl != null)
                      ClipOval(
                        child: CachedNetworkImage(
                          imageUrl: asset.imageUrl!,
                          height: 44,
                          width: 44,
                        ),
                      ),
                    const SizedBox(width: AppDimens.space12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(asset.name, style: theme.textTheme.titleLarge),
                          Text(asset.symbol, style: theme.textTheme.bodyMedium),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppDimens.space20),
                Text(
                  Formatters.currency(asset.currentPrice),
                  style: theme.textTheme.displayMedium,
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(
                      asset.isPositive24h
                          ? Icons.arrow_upward_rounded
                          : Icons.arrow_downward_rounded,
                      size: 16,
                      color: changeColor,
                    ),
                    Text(
                      '${Formatters.percentSigned(asset.priceChangePercent24h / 100)} today',
                      style: theme.textTheme.bodyMedium?.copyWith(color: changeColor),
                    ),
                  ],
                ),
                const SizedBox(height: AppDimens.space24),

                priceHistoryAsync.when(
                  loading: () => const SizedBox(
                    height: 220,
                    child: Center(child: CircularProgressIndicator()),
                  ),
                  error: (e, _) => const SizedBox(
                    height: 220,
                    child: Center(child: Text('Chart unavailable')),
                  ),
                  data: (points) =>
                      PriceChart(points: points, isPositive: asset.isPositive24h),
                ),
                const SizedBox(height: AppDimens.space16),
                RangeSelector(
                  selected: selectedRange,
                  onSelected: (r) => ref.read(chartRangeProvider.notifier).state = r,
                ),
                const SizedBox(height: AppDimens.space24),

                priceHistoryAsync.maybeWhen(
                  data: (points) => TechnicalIndicatorsCard(priceHistory: points),
                  orElse: () => const SizedBox.shrink(),
                ),
                const SizedBox(height: AppDimens.space16),

                _buildInfoCard(context, asset),

                if (asset.description != null) ...[
                  const SizedBox(height: AppDimens.space16),
                  _buildAboutCard(context, asset),
                ],

                const SizedBox(height: AppDimens.space24),
                PrimaryButton(
                  label: 'Trade ${asset.symbol}',
                  icon: Icons.swap_horiz_rounded,
                  onPressed: () => context.push(RouteNames.tradeFormPath(asset.id)),
                ),
                const SizedBox(height: AppDimens.space16),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildInfoCard(BuildContext context, AssetDetailEntity asset) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Market Stats', style: theme.textTheme.titleSmall),
            const SizedBox(height: AppDimens.space12),
            _statRow(context, 'Market Cap',
                asset.marketCap != null ? Formatters.currencyCompact(asset.marketCap!) : '—'),
            _statRow(context, '24h Volume',
                asset.totalVolume24h != null ? Formatters.currencyCompact(asset.totalVolume24h!) : '—'),
            _statRow(context, '24h High',
                asset.high24h != null ? Formatters.currency(asset.high24h!) : '—'),
            _statRow(context, '24h Low',
                asset.low24h != null ? Formatters.currency(asset.low24h!) : '—'),
            if (asset.athPrice != null)
              _statRow(context, 'All-Time High', Formatters.currency(asset.athPrice!)),
            if (asset.circulatingSupply != null)
              _statRow(context, 'Circulating Supply',
                  asset.circulatingSupply!.toStringAsFixed(0)),
          ],
        ),
      ),
    );
  }

  Widget _buildAboutCard(BuildContext context, AssetDetailEntity asset) {
    final theme = Theme.of(context);
    final description = asset.description!
        .replaceAll(RegExp(r'<[^>]*>'), '') // strip any embedded HTML tags
        .trim();
    final truncated =
        description.length > 280 ? '${description.substring(0, 280)}…' : description;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('About ${asset.name}', style: theme.textTheme.titleSmall),
            const SizedBox(height: AppDimens.space8),
            Text(truncated, style: theme.textTheme.bodyMedium),
            if (asset.homepageUrl != null) ...[
              const SizedBox(height: AppDimens.space12),
              TextButton.icon(
                onPressed: () => launchUrl(
                  Uri.parse(asset.homepageUrl!),
                  mode: LaunchMode.externalApplication,
                ),
                icon: const Icon(Icons.open_in_new_rounded, size: 16),
                label: const Text('Official Website'),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _statRow(BuildContext context, String label, String value) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: theme.textTheme.bodyMedium),
          Text(value, style: theme.textTheme.titleSmall),
        ],
      ),
    );
  }
}
