import 'package:flutter/material.dart';
import '../../../../core/constants/app_dimens.dart';

/// Empty-state card for Home sections that genuinely need a later
/// phase's data source (Watchlist and Market News/Trending Assets need
/// the Phase 4 Markets data provider). Shown honestly as "coming soon"
/// rather than faked with placeholder numbers.
class ComingSoonSectionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final String message;
  final VoidCallback? onActionTap;
  final String? actionLabel;

  const ComingSoonSectionCard({
    super.key,
    required this.title,
    required this.icon,
    required this.message,
    this.onActionTap,
    this.actionLabel,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: AppDimens.iconSmall, color: theme.textTheme.bodySmall?.color),
                const SizedBox(width: AppDimens.space8),
                Text(title, style: theme.textTheme.labelMedium),
              ],
            ),
            const SizedBox(height: AppDimens.space16),
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: AppDimens.space16),
                child: Column(
                  children: [
                    Icon(
                      Icons.hourglass_empty_rounded,
                      size: 28,
                      color: theme.textTheme.bodySmall?.color,
                    ),
                    const SizedBox(height: AppDimens.space8),
                    Text(
                      message,
                      textAlign: TextAlign.center,
                      style: theme.textTheme.bodySmall,
                    ),
                    if (onActionTap != null && actionLabel != null) ...[
                      const SizedBox(height: AppDimens.space12),
                      TextButton(onPressed: onActionTap, child: Text(actionLabel!)),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
