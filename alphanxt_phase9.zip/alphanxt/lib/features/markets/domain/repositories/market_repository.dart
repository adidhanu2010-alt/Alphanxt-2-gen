import '../../../../core/errors/result.dart';
import '../entities/asset_entity.dart';
import '../entities/asset_detail_entity.dart';
import '../entities/candle_entity.dart';
import '../entities/chart_range.dart';

/// Contract for all market-data and watchlist operations.
///
/// The presentation layer depends only on this interface, never on the
/// CoinGecko HTTP client or Firestore directly — so a licensed equities
/// provider (NSE/BSE) can be added later as a second implementation (or
/// merged into this one) without any UI changes.
abstract class MarketRepository {
  /// Top assets by market cap — powers the Markets screen's default list
  /// and Home's "Trending Assets" section.
  Future<Result<List<AssetEntity>>> getTrendingAssets({int limit = 50});

  /// Free-text search (by name or symbol).
  Future<Result<List<AssetEntity>>> searchAssets(String query);

  /// Full detail info for the Asset Detail screen.
  Future<Result<AssetDetailEntity>> getAssetDetails(String assetId);

  /// Price history for the chart + technical indicators, for the given
  /// [range].
  Future<Result<List<PricePointEntity>>> getPriceHistory(
    String assetId,
    ChartRange range,
  );

  /// Batch-fetches current data for a specific set of asset ids — used
  /// to hydrate the user's Watchlist efficiently in one call.
  Future<Result<List<AssetEntity>>> getAssetsByIds(List<String> ids);

  // ---------------- Watchlist (Firestore-backed) ----------------

  /// Streams the signed-in user's watchlisted asset ids in real time.
  Stream<List<String>> watchWatchlistIds(String uid);

  Future<Result<void>> addToWatchlist(String uid, AssetEntity asset);

  Future<Result<void>> removeFromWatchlist(String uid, String assetId);
}
