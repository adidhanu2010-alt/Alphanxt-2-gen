import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/utils/formatters.dart';
import '../../../../core/widgets/app_snackbar.dart';
import '../../../../core/widgets/primary_button.dart';
import '../../../auth/presentation/providers/auth_providers.dart';
import '../../../markets/presentation/providers/market_providers.dart';
import '../../domain/entities/order_enums.dart';
import '../../domain/entities/position_entity.dart';
import '../providers/trading_providers.dart';
import '../widgets/segmented_toggle.dart';

class TradeFormScreen extends ConsumerStatefulWidget {
  final String assetId;
  final OrderSide initialSide;

  const TradeFormScreen({
    super.key,
    required this.assetId,
    this.initialSide = OrderSide.buy,
  });

  @override
  ConsumerState<TradeFormScreen> createState() => _TradeFormScreenState();
}

class _TradeFormScreenState extends ConsumerState<TradeFormScreen> {
  late OrderSide _side;
  OrderType _orderType = OrderType.market;
  final _quantityController = TextEditingController();
  final _limitPriceController = TextEditingController();
  final _stopLossController = TextEditingController();
  final _takeProfitController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _side = widget.initialSide;
  }

  @override
  void dispose() {
    _quantityController.dispose();
    _limitPriceController.dispose();
    _stopLossController.dispose();
    _takeProfitController.dispose();
    super.dispose();
  }

  double get _quantity => double.tryParse(_quantityController.text) ?? 0;
  double? get _limitPrice => double.tryParse(_limitPriceController.text);
  double? get _stopLoss => double.tryParse(_stopLossController.text);
  double? get _takeProfit => double.tryParse(_takeProfitController.text);

  Future<void> _confirm({
    required double currentPrice,
    required double balance,
    required double? ownedQuantity,
    required String? positionId,
  }) async {
    if (_quantity <= 0) {
      AppSnackbar.error(context, 'Enter a valid quantity.');
      return;
    }
    if (_orderType == OrderType.limit && (_limitPrice == null || _limitPrice! <= 0)) {
      AppSnackbar.error(context, 'Enter a valid limit price.');
      return;
    }
    if (_side == OrderSide.buy) {
      final refPrice = _orderType == OrderType.market ? currentPrice : _limitPrice!;
      if (_quantity * refPrice > balance) {
        AppSnackbar.error(context, 'Insufficient virtual balance for this order.');
        return;
      }
    } else {
      if (ownedQuantity == null || _quantity > ownedQuantity) {
        AppSnackbar.error(context, "You don't own that much to sell.");
        return;
      }
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => _buildConfirmDialog(currentPrice),
    );
    if (confirmed != true || !mounted) return;

    final asset = ref.read(assetDetailProvider(widget.assetId)).value!;
    final controller = ref.read(tradeControllerProvider.notifier);

    final bool success;
    if (_orderType == OrderType.market) {
      success = await controller.placeMarketOrder(
        asset: asset,
        side: _side,
        quantity: _quantity,
        currentMarketPrice: currentPrice,
        stopLoss: _side == OrderSide.buy ? _stopLoss : null,
        takeProfit: _side == OrderSide.buy ? _takeProfit : null,
        positionId: positionId,
      );
    } else {
      success = await controller.placeLimitOrder(
        asset: asset,
        side: _side,
        quantity: _quantity,
        limitPrice: _limitPrice!,
        stopLoss: _side == OrderSide.buy ? _stopLoss : null,
        takeProfit: _side == OrderSide.buy ? _takeProfit : null,
        positionId: positionId,
      );
    }

    if (!mounted) return;
    if (success) {
      AppSnackbar.success(
        context,
        _orderType == OrderType.market
            ? 'Order executed!'
            : 'Limit order placed — it will fill automatically when the price is reached.',
      );
      context.pop();
    } else {
      final error = ref.read(tradeControllerProvider).errorMessage;
      if (error != null) AppSnackbar.error(context, error);
    }
  }

  Widget _buildConfirmDialog(double currentPrice) {
    final refPrice = _orderType == OrderType.market ? currentPrice : (_limitPrice ?? 0);
    final total = _quantity * refPrice;
    return AlertDialog(
      title: Text('Confirm ${_side.label} Order'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('${_orderType.label} order · ${_quantity.toStringAsFixed(6)} units'),
          const SizedBox(height: AppDimens.space8),
          Text(
            _orderType == OrderType.market
                ? 'Executes now at ${Formatters.currency(currentPrice)}'
                : 'Fills when price reaches ${Formatters.currency(refPrice)}',
          ),
          const SizedBox(height: AppDimens.space8),
          Text(
            'Estimated total: ${Formatters.currency(total)}',
            style: const TextStyle(fontWeight: FontWeight.w700),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: () => Navigator.of(context).pop(true),
          child: const Text('Confirm'),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final detailAsync = ref.watch(assetDetailProvider(widget.assetId));
    final profile = ref.watch(currentUserProfileProvider).value;
    final openPositions = ref.watch(openPositionsProvider).value ?? [];
    PositionEntity? existingPosition;
    for (final p in openPositions) {
      if (p.assetId == widget.assetId) {
        existingPosition = p;
        break;
      }
    }
    final actionState = ref.watch(tradeControllerProvider);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('New Trade')),
      body: SafeArea(
        child: detailAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => const Center(child: Text('Could not load asset.')),
          data: (asset) {
            final canSell = existingPosition != null;
            final ownedQty = existingPosition?.quantity;

            return SingleChildScrollView(
              padding: const EdgeInsets.all(AppDimens.space20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(asset.name, style: theme.textTheme.titleLarge),
                            Text(
                              '${asset.symbol} · ${Formatters.currency(asset.currentPrice)}',
                              style: theme.textTheme.bodyMedium,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppDimens.space20),

                  SegmentedToggle<OrderSide>(
                    optionA: OrderSide.buy,
                    optionB: OrderSide.sell,
                    labelA: 'Buy',
                    labelB: 'Sell',
                    selected: _side,
                    selectedColorA: AppColors.bullish,
                    selectedColorB: AppColors.bearish,
                    onChanged: (v) {
                      if (v == OrderSide.sell && !canSell) {
                        AppSnackbar.info(context, "You don't own any ${asset.symbol} yet.");
                        return;
                      }
                      setState(() => _side = v);
                    },
                  ),
                  const SizedBox(height: AppDimens.space16),

                  SegmentedToggle<OrderType>(
                    optionA: OrderType.market,
                    optionB: OrderType.limit,
                    labelA: 'Market',
                    labelB: 'Limit',
                    selected: _orderType,
                    onChanged: (v) => setState(() => _orderType = v),
                  ),
                  const SizedBox(height: AppDimens.space20),

                  Text('Quantity', style: theme.textTheme.labelLarge),
                  const SizedBox(height: AppDimens.space8),
                  TextField(
                    controller: _quantityController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    onChanged: (_) => setState(() {}),
                    decoration: InputDecoration(
                      hintText: '0.00',
                      suffixText: asset.symbol,
                      helperText: _side == OrderSide.sell && canSell
                          ? 'You own ${ownedQty!.toStringAsFixed(6)} ${asset.symbol}'
                          : profile != null
                              ? 'Balance: ${Formatters.currency(profile.virtualBalance)}'
                              : null,
                    ),
                  ),

                  if (_orderType == OrderType.limit) ...[
                    const SizedBox(height: AppDimens.space16),
                    Text('Limit Price', style: theme.textTheme.labelLarge),
                    const SizedBox(height: AppDimens.space8),
                    TextField(
                      controller: _limitPriceController,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                        hintText: Formatters.currency(asset.currentPrice),
                        prefixText: '₹ ',
                        helperText: _side == OrderSide.buy
                            ? 'Fills when price drops to or below this'
                            : 'Fills when price rises to or above this',
                      ),
                    ),
                  ],

                  if (_side == OrderSide.buy) ...[
                    const SizedBox(height: AppDimens.space20),
                    Text('Risk Management (optional)', style: theme.textTheme.labelLarge),
                    const SizedBox(height: AppDimens.space4),
                    Text(
                      'Auto-sell if the price hits either level — checked while the app is open.',
                      style: theme.textTheme.bodySmall,
                    ),
                    const SizedBox(height: AppDimens.space12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _stopLossController,
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            decoration: const InputDecoration(
                              labelText: 'Stop Loss',
                              prefixText: '₹ ',
                            ),
                          ),
                        ),
                        const SizedBox(width: AppDimens.space12),
                        Expanded(
                          child: TextField(
                            controller: _takeProfitController,
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            decoration: const InputDecoration(
                              labelText: 'Take Profit',
                              prefixText: '₹ ',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],

                  const SizedBox(height: AppDimens.space24),
                  Container(
                    padding: const EdgeInsets.all(AppDimens.space12),
                    decoration: BoxDecoration(
                      color: AppColors.primary.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(AppDimens.radiusMedium),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.info_outline_rounded,
                            size: AppDimens.iconSmall, color: AppColors.primary),
                        const SizedBox(width: AppDimens.space8),
                        Expanded(
                          child: Text(
                            AppStrings.virtualTradingDisclaimer,
                            style: theme.textTheme.bodySmall,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppDimens.space24),

                  PrimaryButton(
                    label: _orderType == OrderType.market
                        ? '${_side.label} ${asset.symbol}'
                        : 'Place Limit ${_side.label} Order',
                    isLoading: actionState.isLoading,
                    backgroundColor:
                        _side == OrderSide.buy ? AppColors.bullish : AppColors.bearish,
                    onPressed: () => _confirm(
                      currentPrice: asset.currentPrice,
                      balance: profile?.virtualBalance ?? 0,
                      ownedQuantity: existingPosition?.quantity,
                      positionId: existingPosition?.id,
                    ),
                  ),
                  const SizedBox(height: AppDimens.space16),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
