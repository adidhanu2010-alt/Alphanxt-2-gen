import '../../paper_trade/domain/entities/position_entity.dart';

/// Computes an educational 0-100 "Risk Score" from the user's real open
/// positions and current prices.
///
/// This is intentionally simple and transparent — three equally-weighted
/// factors — so it can be explained to a learner in one sentence each,
/// not a black-box number. It is NOT a professional risk model and must
/// never be presented as investment advice or a guarantee of anything;
/// it exists purely to teach the concept of portfolio risk factors.
///
/// Factors (each 0-100, averaged):
/// 1. **Concentration** — how much of the portfolio sits in a single
///    asset. 100% in one asset = high concentration risk.
/// 2. **Volatility** — average |24h % change| across held assets, scaled
///    so a ~10%+ average daily swing reads as high risk.
/// 3. **Exposure** — how much of total account value is invested vs.
///    held as cash. Fully invested = higher exposure risk than mostly
///    cash.
class RiskScoreResult {
  final double score; // 0-100
  final double concentration;
  final double volatility;
  final double exposure;

  const RiskScoreResult({
    required this.score,
    required this.concentration,
    required this.volatility,
    required this.exposure,
  });

  String get label {
    if (score < 33) return 'Low';
    if (score < 66) return 'Moderate';
    return 'High';
  }

  static const empty = RiskScoreResult(
    score: 0,
    concentration: 0,
    volatility: 0,
    exposure: 0,
  );
}

class RiskScoreCalculator {
  RiskScoreCalculator._();

  static RiskScoreResult calculate({
    required List<PositionEntity> openPositions,
    required Map<String, double> currentPrices,
    required Map<String, double> priceChangePercent24h,
    required double cashBalance,
  }) {
    if (openPositions.isEmpty) return RiskScoreResult.empty;

    final marketValues = <String, double>{};
    double investedTotal = 0;
    for (final p in openPositions) {
      final price = currentPrices[p.assetId] ?? p.avgBuyPrice;
      final value = p.marketValue(price);
      marketValues[p.assetId] = (marketValues[p.assetId] ?? 0) + value;
      investedTotal += value;
    }
    final accountTotal = investedTotal + cashBalance;
    if (investedTotal <= 0) return RiskScoreResult.empty;

    // ---- 1. Concentration: largest single-asset share of invested value ----
    final maxSingle = marketValues.values.reduce((a, b) => a > b ? a : b);
    final concentration = (maxSingle / investedTotal) * 100;

    // ---- 2. Volatility: average |24h % change| across held assets ----
    final changes = openPositions
        .map((p) => (priceChangePercent24h[p.assetId] ?? 0).abs())
        .toList();
    final avgChange =
        changes.isEmpty ? 0 : changes.reduce((a, b) => a + b) / changes.length;
    // Scale: a 10%+ average daily swing reads as ~100 risk.
    final volatility = (avgChange / 10 * 100).clamp(0, 100).toDouble();

    // ---- 3. Exposure: invested value as a share of total account value ----
    final exposure =
        accountTotal <= 0 ? 0.0 : (investedTotal / accountTotal) * 100;

    final score = (concentration + volatility + exposure) / 3;

    return RiskScoreResult(
      score: score.clamp(0, 100),
      concentration: concentration.clamp(0, 100),
      volatility: volatility,
      exposure: exposure.clamp(0, 100),
    );
  }
}
