import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/widgets/primary_button.dart';
import '../../domain/entities/course_entity.dart';
import '../providers/learn_providers.dart';
import '../widgets/learn_icons.dart';
import 'quiz_screen.dart';

class CourseDetailScreen extends ConsumerStatefulWidget {
  final CourseEntity course;

  const CourseDetailScreen({super.key, required this.course});

  @override
  ConsumerState<CourseDetailScreen> createState() => _CourseDetailScreenState();
}

class _CourseDetailScreenState extends ConsumerState<CourseDetailScreen> {
  @override
  void initState() {
    super.initState();
    // Mark the lesson read as soon as the user opens it — genuine
    // engagement signal (they've seen the content), separate from the
    // quiz which measures whether they retained it.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(learnActionControllerProvider.notifier).markLessonRead(widget.course.id);
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final progress = ref.watch(courseProgressProvider).value
        ?.where((p) => p.courseId == widget.course.id)
        .toList();
    final bestScore = progress?.isNotEmpty == true ? progress!.first.bestQuizScorePercent : null;

    return Scaffold(
      appBar: AppBar(title: Text(widget.course.title)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(AppDimens.space20),
          children: [
            Row(
              children: [
                Container(
                  height: 52,
                  width: 52,
                  decoration: BoxDecoration(
                    color: AppColors.primary.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(AppDimens.radiusMedium),
                  ),
                  child: Icon(
                    learnIconFor(widget.course.iconKey),
                    color: AppColors.primary,
                    size: 26,
                  ),
                ),
                const SizedBox(width: AppDimens.space12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(widget.course.title, style: theme.textTheme.titleLarge),
                      Text(
                        '${widget.course.level.label} · ${widget.course.estimatedMinutes} min read',
                        style: theme.textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppDimens.space24),
            Text(
              widget.course.lessonContent.trim(),
              style: theme.textTheme.bodyLarge?.copyWith(height: 1.6),
            ),
            const SizedBox(height: AppDimens.space32),
            if (bestScore != null)
              Container(
                padding: const EdgeInsets.all(AppDimens.space12),
                margin: const EdgeInsets.only(bottom: AppDimens.space16),
                decoration: BoxDecoration(
                  color: AppColors.bullish.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(AppDimens.radiusMedium),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.check_circle_rounded, color: AppColors.bullish, size: 18),
                    const SizedBox(width: AppDimens.space8),
                    Text('Best quiz score: $bestScore%', style: theme.textTheme.bodyMedium),
                  ],
                ),
              ),
            PrimaryButton(
              label: bestScore == null ? 'Take Quiz (+${widget.course.xpReward} XP)' : 'Retake Quiz',
              icon: Icons.quiz_rounded,
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => QuizScreen(course: widget.course)),
              ),
            ),
            const SizedBox(height: AppDimens.space16),
          ],
        ),
      ),
    );
  }
}
