import '../../domain/entities/challenge_entity.dart';

/// The full set of AlphaNXT challenges — 2 per period, each measuring a
/// real, already-tracked activity (trades placed, profitable closes,
/// courses completed).
class ChallengeCatalog {
  ChallengeCatalog._();

  static const List<ChallengeDefinitionEntity> all = [
    ChallengeDefinitionEntity(
      id: 'daily_trader',
      title: 'Daily Trader',
      description: 'Place 1 trade today.',
      period: ChallengePeriod.daily,
      metric: ChallengeMetric.tradesPlaced,
      targetCount: 1,
      xpReward: 20,
      iconKey: 'swap_horiz',
    ),
    ChallengeDefinitionEntity(
      id: 'green_day',
      title: 'Green Day',
      description: 'Close a profitable trade today.',
      period: ChallengePeriod.daily,
      metric: ChallengeMetric.profitableTradesClosed,
      targetCount: 1,
      xpReward: 25,
      iconKey: 'trending_up',
    ),
    ChallengeDefinitionEntity(
      id: 'active_week',
      title: 'Active Week',
      description: 'Place 5 trades this week.',
      period: ChallengePeriod.weekly,
      metric: ChallengeMetric.tradesPlaced,
      targetCount: 5,
      xpReward: 80,
      iconKey: 'bolt',
    ),
    ChallengeDefinitionEntity(
      id: 'study_time',
      title: 'Study Time',
      description: 'Complete 2 courses this week.',
      period: ChallengePeriod.weekly,
      metric: ChallengeMetric.coursesCompleted,
      targetCount: 2,
      xpReward: 100,
      iconKey: 'school',
    ),
    ChallengeDefinitionEntity(
      id: 'power_trader',
      title: 'Power Trader',
      description: 'Place 20 trades this month.',
      period: ChallengePeriod.monthly,
      metric: ChallengeMetric.tradesPlaced,
      targetCount: 20,
      xpReward: 250,
      iconKey: 'military_tech',
    ),
    ChallengeDefinitionEntity(
      id: 'scholar',
      title: 'Scholar',
      description: 'Complete 5 courses this month.',
      period: ChallengePeriod.monthly,
      metric: ChallengeMetric.coursesCompleted,
      targetCount: 5,
      xpReward: 300,
      iconKey: 'auto_stories',
    ),
  ];

  static List<ChallengeDefinitionEntity> byPeriod(ChallengePeriod period) =>
      all.where((c) => c.period == period).toList();

  static ChallengeDefinitionEntity? byId(String id) {
    for (final c in all) {
      if (c.id == id) return c;
    }
    return null;
  }
}
