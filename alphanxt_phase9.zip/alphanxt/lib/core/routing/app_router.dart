import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/presentation/screens/splash_screen.dart';
import '../../features/auth/presentation/screens/onboarding_screen.dart';
import '../../features/auth/presentation/screens/login_screen.dart';
import '../../features/auth/presentation/screens/register_screen.dart';
import '../../features/auth/presentation/screens/forgot_password_screen.dart';
import '../../features/auth/presentation/screens/verify_email_screen.dart';
import '../../features/auth/presentation/providers/auth_providers.dart';
import '../../features/home/presentation/screens/home_screen.dart';
import '../../features/markets/presentation/screens/markets_screen.dart';
import '../../features/markets/presentation/screens/asset_detail_screen.dart';
import '../../features/paper_trade/presentation/screens/paper_trade_screen.dart';
import '../../features/paper_trade/presentation/screens/trade_form_screen.dart';
import '../../features/paper_trade/domain/entities/order_enums.dart';
import '../../features/portfolio/presentation/screens/portfolio_screen.dart';
import '../../features/learn/presentation/screens/learn_screen.dart';
import '../widgets/app_shell.dart';
import '../widgets/coming_soon_screen.dart';
import 'route_names.dart';

/// Routes reachable only while signed out (or mid-verification) — used
/// by the redirect guard below to avoid loops.
const _publicRoutes = {
  RouteNames.splash,
  RouteNames.onboarding,
  RouteNames.login,
  RouteNames.register,
  RouteNames.forgotPassword,
  RouteNames.verifyEmail,
};

/// App-wide router configuration.
///
/// The 6 bottom-nav destinations (Home, Markets, Paper Trade, Portfolio,
/// Learn, Profile) are wired as branches of a [StatefulShellRoute] so
/// each tab keeps its own navigation stack — see core/widgets/app_shell.dart
/// for the bottom nav bar itself. Home is the real Phase 3 screen; the
/// rest still render [ComingSoonScreen] until their phase lands.
///
/// The `redirect` callback is a lightweight safety net for state changes
/// that happen *after* initial navigation (e.g. the user signs out from
/// deep inside the app, or their session expires) — it bounces them back
/// to Login. The splash screen owns the *initial* routing decision on
/// cold start (see splash_screen.dart), so this guard intentionally does
/// nothing while still on `/splash`.
final routerProvider = Provider<GoRouter>((ref) {
  final isSignedInAsync = ref.watch(isSignedInProvider);

  return GoRouter(
    initialLocation: RouteNames.splash,
    debugLogDiagnostics: true,
    redirect: (context, state) {
      final loc = state.matchedLocation;
      if (loc == RouteNames.splash) return null;

      // While the auth stream hasn't emitted yet, don't redirect —
      // avoids a flash-redirect to Login before Firebase reports the
      // real (possibly signed-in) state.
      if (!isSignedInAsync.hasValue) return null;

      final isSignedIn = isSignedInAsync.value ?? false;
      final isPublicRoute = _publicRoutes.contains(loc);

      if (!isSignedIn && !isPublicRoute) {
        return RouteNames.login;
      }
      if (isSignedIn && (loc == RouteNames.login || loc == RouteNames.register)) {
        return RouteNames.home;
      }
      return null;
    },
    routes: [
      GoRoute(
        path: RouteNames.splash,
        builder: (context, state) => const SplashScreen(),
      ),
      GoRoute(
        path: RouteNames.onboarding,
        builder: (context, state) => const OnboardingScreen(),
      ),
      GoRoute(
        path: RouteNames.login,
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: RouteNames.register,
        builder: (context, state) => const RegisterScreen(),
      ),
      GoRoute(
        path: RouteNames.forgotPassword,
        builder: (context, state) => const ForgotPasswordScreen(),
      ),
      GoRoute(
        path: RouteNames.verifyEmail,
        builder: (context, state) => const VerifyEmailScreen(),
      ),
      GoRoute(
        path: '/trade/:assetId',
        builder: (context, state) {
          final assetId = state.pathParameters['assetId']!;
          final sideParam = state.uri.queryParameters['side'];
          return TradeFormScreen(
            assetId: assetId,
            initialSide: sideParam == 'sell' ? OrderSide.sell : OrderSide.buy,
          );
        },
      ),
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) =>
            AppShell(navigationShell: navigationShell),
        branches: [
          StatefulShellBranch(routes: [
            GoRoute(
              path: RouteNames.home,
              builder: (context, state) => const HomeScreen(),
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: RouteNames.markets,
              builder: (context, state) => const MarketsScreen(),
              routes: [
                GoRoute(
                  path: 'asset/:id',
                  builder: (context, state) => AssetDetailScreen(
                    assetId: state.pathParameters['id']!,
                  ),
                ),
              ],
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: RouteNames.paperTrade,
              builder: (context, state) => const PaperTradeScreen(),
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: RouteNames.portfolio,
              builder: (context, state) => const PortfolioScreen(),
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: RouteNames.learn,
              builder: (context, state) => const LearnScreen(),
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: RouteNames.profile,
              builder: (context, state) =>
                  const ComingSoonScreen(featureName: 'Profile'),
            ),
          ]),
        ],
      ),
    ],
  );
});
