import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';

/// Generic 2-option segmented toggle — used for Buy/Sell and
/// Market/Limit selectors on the trade form.
class SegmentedToggle<T> extends StatelessWidget {
  final T optionA;
  final T optionB;
  final String labelA;
  final String labelB;
  final T selected;
  final ValueChanged<T> onChanged;
  final Color? selectedColorA;
  final Color? selectedColorB;

  const SegmentedToggle({
    super.key,
    required this.optionA,
    required this.optionB,
    required this.labelA,
    required this.labelB,
    required this.selected,
    required this.onChanged,
    this.selectedColorA,
    this.selectedColorB,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(AppDimens.radiusMedium),
      ),
      child: Row(
        children: [
          _segment(context, optionA, labelA, selectedColorA ?? AppColors.primary),
          _segment(context, optionB, labelB, selectedColorB ?? AppColors.primary),
        ],
      ),
    );
  }

  Widget _segment(BuildContext context, T value, String label, Color color) {
    final isSelected = value == selected;
    return Expanded(
      child: GestureDetector(
        onTap: () => onChanged(value),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(vertical: AppDimens.space12),
          decoration: BoxDecoration(
            color: isSelected ? color : Colors.transparent,
            borderRadius: BorderRadius.circular(AppDimens.radiusSmall),
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: Theme.of(context).textTheme.labelLarge?.copyWith(
                  color: isSelected ? Colors.white : null,
                  fontWeight: FontWeight.w700,
                ),
          ),
        ),
      ),
    );
  }
}
