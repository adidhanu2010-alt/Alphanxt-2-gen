import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../../core/constants/app_strings.dart';
import '../../domain/entities/challenge_entity.dart';

/// Firestore access for the `challenges` collection — see project
/// README for why this collection was added beyond the original spec
/// list (it stores only the "XP already claimed" flag; live progress is
/// always recomputed from real trade/course data, never stored here).
class ChallengesRemoteDataSource {
  final FirebaseFirestore _firestore;

  ChallengesRemoteDataSource(this._firestore);

  CollectionReference<Map<String, dynamic>> get _ref =>
      _firestore.collection(AppStrings.collectionChallenges);

  String _docId(String uid, String challengeId, String periodKey) =>
      '${uid}_${challengeId}_$periodKey';

  Stream<List<ClaimedChallengeEntity>> watchClaimed(String uid) {
    return _ref.where('uid', isEqualTo: uid).snapshots().map((snap) {
      return snap.docs.map((d) {
        final data = d.data();
        return ClaimedChallengeEntity(
          challengeId: data['challengeId'] as String? ?? '',
          periodKey: data['periodKey'] as String? ?? '',
          claimedAt: (data['claimedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
        );
      }).toList();
    });
  }

  Future<void> claim({
    required String uid,
    required String challengeId,
    required String periodKey,
  }) async {
    final docRef = _ref.doc(_docId(uid, challengeId, periodKey));
    final existing = await docRef.get();
    if (existing.exists) return; // already claimed — never double-award
    await docRef.set({
      'uid': uid,
      'challengeId': challengeId,
      'periodKey': periodKey,
      'claimedAt': FieldValue.serverTimestamp(),
    });
  }
}
