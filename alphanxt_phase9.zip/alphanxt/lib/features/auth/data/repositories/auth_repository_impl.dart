import 'package:firebase_auth/firebase_auth.dart' as fb;

import '../../../../core/errors/failures.dart';
import '../../../../core/errors/result.dart';
import '../../../../core/utils/app_logger.dart';
import '../../domain/entities/app_user_entity.dart';
import '../../domain/repositories/auth_repository.dart';
import '../datasources/auth_remote_datasource.dart';

/// Concrete [AuthRepository] backed by Firebase Auth + Firestore.
///
/// Responsible for: catching `FirebaseAuthException`/`FirebaseException`
/// and converting them into readable [Failure]s, and orchestrating the
/// "create Firestore profile with starting balance" step that must
/// happen right after every successful sign-up.
class AuthRepositoryImpl implements AuthRepository {
  final AuthRemoteDataSource _remote;

  AuthRepositoryImpl(this._remote);

  @override
  Stream<bool> get isSignedInStream =>
      _remote.authStateChanges().map((user) => user != null);

  @override
  String? get currentUid => _remote.currentFirebaseUser?.uid;

  @override
  Stream<AppUserEntity?> watchCurrentUserProfile() {
    return _remote.authStateChanges().asyncExpand((user) {
      if (user == null) return Stream.value(null);
      return _remote.watchUserProfile(user.uid);
    });
  }

  @override
  Future<Result<AppUserEntity>> signUp({
    required String name,
    required String email,
    required String password,
  }) async {
    try {
      final credential = await _remote.signUpWithEmail(
        email: email,
        password: password,
      );
      final uid = credential.user!.uid;

      await credential.user!.updateDisplayName(name);
      await _remote.sendEmailVerification();

      final profile = await _remote.createUserProfileIfNotExists(
        uid: uid,
        email: email,
        displayName: name,
      );

      return Result.success(profile);
    } on fb.FirebaseAuthException catch (e) {
      return Result.failure(AuthFailure(_mapAuthError(e)));
    } catch (e, st) {
      AppLogger.error('signUp failed', e, st);
      return Result.failure(const UnknownFailure());
    }
  }

  @override
  Future<Result<AppUserEntity>> signIn({
    required String email,
    required String password,
  }) async {
    try {
      final credential = await _remote.signInWithEmail(
        email: email,
        password: password,
      );
      final uid = credential.user!.uid;

      // Defensive: in case a user exists in Auth but their Firestore
      // profile creation failed previously (e.g. dropped connection),
      // this ensures they still get their starting balance rather than
      // being stuck with no profile.
      final profile = await _remote.createUserProfileIfNotExists(
        uid: uid,
        email: credential.user!.email ?? email,
        displayName: credential.user!.displayName ?? '',
        photoUrl: credential.user!.photoURL,
      );

      return Result.success(profile);
    } on fb.FirebaseAuthException catch (e) {
      return Result.failure(AuthFailure(_mapAuthError(e)));
    } catch (e, st) {
      AppLogger.error('signIn failed', e, st);
      return Result.failure(const UnknownFailure());
    }
  }

  @override
  Future<Result<AppUserEntity>> signInWithGoogle() async {
    try {
      final credential = await _remote.signInWithGoogle();
      final fbUser = credential.user!;

      final profile = await _remote.createUserProfileIfNotExists(
        uid: fbUser.uid,
        email: fbUser.email ?? '',
        displayName: fbUser.displayName ?? 'Trader',
        photoUrl: fbUser.photoURL,
      );

      return Result.success(profile);
    } on fb.FirebaseAuthException catch (e) {
      return Result.failure(AuthFailure(_mapAuthError(e)));
    } catch (e, st) {
      AppLogger.error('signInWithGoogle failed', e, st);
      return Result.failure(
        const AuthFailure('Google sign-in was cancelled or failed.'),
      );
    }
  }

  @override
  Future<Result<void>> sendPasswordResetEmail(String email) async {
    try {
      await _remote.sendPasswordResetEmail(email);
      return Result.success(null);
    } on fb.FirebaseAuthException catch (e) {
      return Result.failure(AuthFailure(_mapAuthError(e)));
    } catch (e, st) {
      AppLogger.error('sendPasswordResetEmail failed', e, st);
      return Result.failure(const UnknownFailure());
    }
  }

  @override
  Future<Result<void>> sendEmailVerification() async {
    try {
      await _remote.sendEmailVerification();
      return Result.success(null);
    } on fb.FirebaseAuthException catch (e) {
      return Result.failure(AuthFailure(_mapAuthError(e)));
    } catch (e, st) {
      AppLogger.error('sendEmailVerification failed', e, st);
      return Result.failure(const UnknownFailure());
    }
  }

  @override
  Future<Result<bool>> checkEmailVerified() async {
    try {
      final verified = await _remote.reloadAndCheckEmailVerified();
      final uid = currentUid;
      if (verified && uid != null) {
        await _remote.syncEmailVerifiedFlag(uid, true);
      }
      return Result.success(verified);
    } catch (e, st) {
      AppLogger.error('checkEmailVerified failed', e, st);
      return Result.failure(const UnknownFailure());
    }
  }

  @override
  Future<Result<void>> signOut() async {
    try {
      await _remote.signOut();
      return Result.success(null);
    } catch (e, st) {
      AppLogger.error('signOut failed', e, st);
      return Result.failure(const UnknownFailure());
    }
  }

  /// Converts Firebase's cryptic auth error codes into copy a trader
  /// (not a developer) can actually understand.
  String _mapAuthError(fb.FirebaseAuthException e) {
    switch (e.code) {
      case 'invalid-email':
        return 'That email address looks invalid.';
      case 'user-disabled':
        return 'This account has been disabled.';
      case 'user-not-found':
        return 'No account found with that email.';
      case 'wrong-password':
      case 'invalid-credential':
        return 'Incorrect email or password.';
      case 'email-already-in-use':
        return 'An account already exists with that email.';
      case 'weak-password':
        return 'Choose a stronger password.';
      case 'too-many-requests':
        return 'Too many attempts. Please try again later.';
      case 'network-request-failed':
        return 'Network error. Check your connection and try again.';
      case 'google-sign-in-cancelled':
        return 'Google sign-in was cancelled.';
      default:
        return e.message ?? 'Authentication failed. Please try again.';
    }
  }
}
