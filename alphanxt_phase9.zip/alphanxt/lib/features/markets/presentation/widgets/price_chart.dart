import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../../../../core/theme/app_chart_theme.dart';
import '../../../../core/utils/formatters.dart';
import '../../domain/entities/candle_entity.dart';

/// Full-size price history chart for the Asset Detail screen, with a
/// touch tooltip showing price + date.
class PriceChart extends StatelessWidget {
  final List<PricePointEntity> points;
  final bool isPositive;

  const PriceChart({super.key, required this.points, required this.isPositive});

  @override
  Widget build(BuildContext context) {
    if (points.length < 2) {
      return const SizedBox(
        height: 220,
        child: Center(child: Text('Not enough data to chart yet')),
      );
    }

    final isDark = Theme.of(context).brightness == Brightness.dark;
    final color = isPositive ? AppChartTheme.lineUp : AppChartTheme.lineDown;

    final spots = List.generate(
      points.length,
      (i) => FlSpot(i.toDouble(), points[i].price),
    );
    final prices = points.map((p) => p.price).toList();
    final minY = prices.reduce((a, b) => a < b ? a : b);
    final maxY = prices.reduce((a, b) => a > b ? a : b);
    final pad = (maxY - minY) * 0.1;

    return SizedBox(
      height: 220,
      child: LineChart(
        LineChartData(
          minY: minY - pad,
          maxY: maxY + pad,
          gridData: FlGridData(
            show: true,
            drawVerticalLine: false,
            horizontalInterval: (maxY - minY) / 4 == 0 ? 1 : (maxY - minY) / 4,
            getDrawingHorizontalLine: (value) => FlLine(
              color: AppChartTheme.gridColor(isDark),
              strokeWidth: 1,
            ),
          ),
          titlesData: const FlTitlesData(show: false),
          borderData: FlBorderData(show: false),
          lineTouchData: LineTouchData(
            touchTooltipData: LineTouchTooltipData(
              getTooltipColor: (_) =>
                  isDark ? const Color(0xFF1C2028) : Colors.white,
              tooltipRoundedRadius: 10,
              getTooltipItems: (spots) => spots.map((s) {
                final point = points[s.x.toInt()];
                return LineTooltipItem(
                  '${Formatters.currency(point.price)}\n',
                  TextStyle(
                    color: isDark ? Colors.white : Colors.black87,
                    fontWeight: FontWeight.w700,
                    fontSize: 12,
                  ),
                  children: [
                    TextSpan(
                      text: Formatters.dateTime(point.timestamp),
                      style: TextStyle(
                        color: (isDark ? Colors.white : Colors.black87)
                            .withValues(alpha: 0.6),
                        fontWeight: FontWeight.w400,
                        fontSize: 11,
                      ),
                    ),
                  ],
                );
              }).toList(),
            ),
          ),
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: true,
              barWidth: 2.4,
              color: color,
              dotData: const FlDotData(show: false),
              belowBarData: BarAreaData(
                show: true,
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: AppChartTheme.areaGradient(color),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
