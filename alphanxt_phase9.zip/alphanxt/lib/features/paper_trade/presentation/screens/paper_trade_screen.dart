import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/app_dimens.dart';
import '../../../../core/routing/route_names.dart';
import '../../../../core/widgets/app_snackbar.dart';
import '../../../ai_coach/presentation/screens/trade_analysis_screen.dart';
import '../../../markets/presentation/providers/market_providers.dart';
import '../../../markets/presentation/widgets/asset_list_tile.dart';
import '../../../markets/presentation/widgets/market_search_bar.dart';
import '../../domain/entities/order_enums.dart';
import '../providers/trading_providers.dart';
import '../widgets/closed_position_card.dart';
import '../widgets/pending_order_card.dart';
import '../widgets/position_card.dart';
import '../widgets/transaction_history_tile.dart';

class PaperTradeScreen extends ConsumerStatefulWidget {
  const PaperTradeScreen({super.key});

  @override
  ConsumerState<PaperTradeScreen> createState() => _PaperTradeScreenState();
}

class _PaperTradeScreenState extends ConsumerState<PaperTradeScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _openAssetPicker() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => const _AssetPickerSheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Keeps pending limit orders / SL-TP checked while this screen is open.
    ref.watch(triggerCheckerProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Paper Trade'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Open'),
            Tab(text: 'Pending'),
            Tab(text: 'History'),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openAssetPicker,
        icon: const Icon(Icons.add_rounded),
        label: const Text('New Trade'),
      ),
      body: SafeArea(
        child: TabBarView(
          controller: _tabController,
          children: [
            _buildOpenTab(),
            _buildPendingTab(),
            _buildHistoryTab(),
          ],
        ),
      ),
    );
  }

  Widget _buildOpenTab() {
    final positionsAsync = ref.watch(openPositionsProvider);
    final pricesAsync = ref.watch(heldAssetPricesProvider);

    return positionsAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => _errorState(() => ref.invalidate(openPositionsProvider)),
      data: (positions) {
        if (positions.isEmpty) {
          return _emptyState(
            icon: Icons.inbox_outlined,
            message: 'No open positions yet.\nTap "New Trade" to place your first paper trade.',
          );
        }
        final prices = pricesAsync.value ?? {};
        return RefreshIndicator(
          onRefresh: () => ref.refresh(openPositionsProvider.future),
          child: ListView.builder(
            padding: const EdgeInsets.all(AppDimens.space16),
            itemCount: positions.length,
            itemBuilder: (context, i) {
              final position = positions[i];
              return PositionCard(
                position: position,
                currentPrice: prices[position.assetId],
                onSell: () => context.push(
                  RouteNames.tradeFormPath(
                    position.assetId,
                    side: 'sell',
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildPendingTab() {
    final ordersAsync = ref.watch(pendingOrdersProvider);

    return ordersAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => _errorState(() => ref.invalidate(pendingOrdersProvider)),
      data: (orders) {
        if (orders.isEmpty) {
          return _emptyState(
            icon: Icons.schedule_rounded,
            message: 'No pending limit orders.',
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.all(AppDimens.space16),
          itemCount: orders.length,
          itemBuilder: (context, i) {
            final order = orders[i];
            return PendingOrderCard(
              order: order,
              onCancel: () async {
                final ok = await ref
                    .read(tradeControllerProvider.notifier)
                    .cancelOrder(order.id);
                if (ok && context.mounted) {
                  AppSnackbar.info(context, 'Order cancelled.');
                }
              },
            );
          },
        );
      },
    );
  }

  Widget _buildHistoryTab() {
    final closedAsync = ref.watch(closedPositionsProvider);
    final historyAsync = ref.watch(transactionHistoryProvider);

    return ListView(
      padding: const EdgeInsets.all(AppDimens.space16),
      children: [
        Text('Closed Positions', style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: AppDimens.space12),
        closedAsync.when(
          loading: () => const Padding(
            padding: EdgeInsets.all(AppDimens.space16),
            child: Center(child: CircularProgressIndicator()),
          ),
          error: (e, _) => const Text('Could not load closed positions.'),
          data: (positions) => positions.isEmpty
              ? Padding(
                  padding: const EdgeInsets.only(bottom: AppDimens.space16),
                  child: Text(
                    'No closed positions yet.',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                )
              : Column(
                  children: positions
                      .map((p) => ClosedPositionCard(
                            position: p,
                            onTap: () => Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => TradeAnalysisScreen(position: p),
                              ),
                            ),
                          ))
                      .toList(),
                ),
        ),
        const SizedBox(height: AppDimens.space8),
        Text('Trade History', style: Theme.of(context).textTheme.titleSmall),
        historyAsync.when(
          loading: () => const Padding(
            padding: EdgeInsets.all(AppDimens.space16),
            child: Center(child: CircularProgressIndicator()),
          ),
          error: (e, _) => const Padding(
            padding: EdgeInsets.symmetric(vertical: AppDimens.space12),
            child: Text('Could not load trade history.'),
          ),
          data: (transactions) => transactions.isEmpty
              ? Padding(
                  padding: const EdgeInsets.symmetric(vertical: AppDimens.space12),
                  child: Text(
                    'No trades yet.',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                )
              : Column(
                  children: transactions
                      .map((t) => TransactionHistoryTile(transaction: t))
                      .toList(),
                ),
        ),
      ],
    );
  }

  Widget _emptyState({required IconData icon, required String message}) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 40, color: Theme.of(context).textTheme.bodySmall?.color),
            const SizedBox(height: AppDimens.space12),
            Text(message, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
          ],
        ),
      ),
    );
  }

  Widget _errorState(VoidCallback onRetry) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off_rounded, size: 40),
            const SizedBox(height: AppDimens.space12),
            Text('Something went wrong.', style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: AppDimens.space12),
            OutlinedButton(onPressed: onRetry, child: const Text('Retry')),
          ],
        ),
      ),
    );
  }
}

/// Bottom sheet asset picker for starting a new trade — reuses the same
/// search + trending providers from Markets.
class _AssetPickerSheet extends ConsumerStatefulWidget {
  const _AssetPickerSheet();

  @override
  ConsumerState<_AssetPickerSheet> createState() => _AssetPickerSheetState();
}

class _AssetPickerSheetState extends ConsumerState<_AssetPickerSheet> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final query = ref.watch(searchQueryProvider);
    final isSearching = query.trim().isNotEmpty;

    return DraggableScrollableSheet(
      initialChildSize: 0.75,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      builder: (context, scrollController) {
        return Padding(
          padding: const EdgeInsets.all(AppDimens.space16),
          child: Column(
            children: [
              Text('Select an asset to trade', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: AppDimens.space12),
              MarketSearchBar(
                controller: _controller,
                onChanged: (v) => ref.read(searchQueryProvider.notifier).state = v,
                onClear: () => ref.read(searchQueryProvider.notifier).state = '',
              ),
              const SizedBox(height: AppDimens.space8),
              Expanded(
                child: Consumer(
                  builder: (context, ref, _) {
                    final assetsAsync = isSearching
                        ? ref.watch(searchResultsProvider)
                        : ref.watch(trendingAssetsProvider);
                    return assetsAsync.when(
                      loading: () => const Center(child: CircularProgressIndicator()),
                      error: (e, _) => const Center(child: Text('Could not load assets.')),
                      data: (assets) => ListView.builder(
                        controller: scrollController,
                        itemCount: assets.length,
                        itemBuilder: (context, i) {
                          final asset = assets[i];
                          return AssetListTile(
                            asset: asset,
                            onTap: () {
                              Navigator.of(context).pop();
                              context.push(RouteNames.tradeFormPath(asset.id));
                            },
                          );
                        },
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
