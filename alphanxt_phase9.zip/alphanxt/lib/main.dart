import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:go_router/go_router.dart';

import 'core/routing/app_router.dart';
import 'core/theme/app_theme.dart';
import 'core/theme/theme_provider.dart';
import 'core/constants/app_strings.dart';
import 'core/utils/app_logger.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    // Loads .env (API keys like AI_COACH_API_KEY). Safe to continue even
    // if the file is missing/empty in a fresh checkout — features that
    // need a given key (e.g. AI Coach) surface a clear "not configured"
    // state instead of crashing the whole app.
    await dotenv.load(fileName: '.env');
  } catch (e, st) {
    AppLogger.error('.env load failed (continuing without it)', e, st);
  }

  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e, st) {
    // Logged rather than thrown so the app can still boot in local/dev
    // environments before `flutterfire configure` has been run — the
    // relevant screens will surface a clear "service unavailable" state
    // once auth/Firestore providers are wired in Phase 2.
    AppLogger.error('Firebase initialization failed', e, st);
  }

  runApp(const ProviderScope(child: AlphaNxtApp()));
}

/// Root application widget.
///
/// Wires together:
/// - Riverpod (state management, DI)
/// - go_router (declarative routing, see core/routing/app_router.dart)
/// - Light/dark Material 3 theme (see core/theme/app_theme.dart)
class AlphaNxtApp extends ConsumerWidget {
  const AlphaNxtApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final GoRouter router = ref.watch(routerProvider);
    final ThemeMode themeMode = ref.watch(themeModeProvider);

    return MaterialApp.router(
      title: AppStrings.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: themeMode,
      routerConfig: router,
    );
  }
}
