import 'package:flutter/material.dart';

IconData challengeIconFor(String key) {
  switch (key) {
    case 'swap_horiz':
      return Icons.swap_horiz_rounded;
    case 'trending_up':
      return Icons.trending_up_rounded;
    case 'bolt':
      return Icons.bolt_rounded;
    case 'school':
      return Icons.school_rounded;
    case 'military_tech':
      return Icons.military_tech_rounded;
    case 'auto_stories':
      return Icons.auto_stories_rounded;
    default:
      return Icons.flag_rounded;
  }
}
