import 'package:flutter/material.dart';
import '../../../../core/constants/app_dimens.dart';

/// "Continue with Google" button — outlined style with the multi-color
/// Google 'G' rendered via a simple icon (no network asset dependency).
class GoogleSignInButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final bool isLoading;

  const GoogleSignInButton({
    super.key,
    required this.onPressed,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final disabled = onPressed == null || isLoading;

    return OutlinedButton(
      onPressed: disabled ? null : onPressed,
      style: OutlinedButton.styleFrom(
        minimumSize: const Size.fromHeight(AppDimens.buttonHeight),
        side: BorderSide(color: theme.dividerColor),
        foregroundColor: theme.textTheme.bodyLarge?.color,
      ),
      child: isLoading
          ? SizedBox(
              height: 20,
              width: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2.2,
                valueColor: AlwaysStoppedAnimation<Color>(
                  theme.colorScheme.primary,
                ),
              ),
            )
          : Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 20,
                  width: 20,
                  alignment: Alignment.center,
                  child: const Text(
                    'G',
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 16,
                      color: Color(0xFF4285F4),
                    ),
                  ),
                ),
                const SizedBox(width: AppDimens.space12),
                const Text('Continue with Google'),
              ],
            ),
    );
  }
}
