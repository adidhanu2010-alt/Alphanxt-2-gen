import '../../../../core/errors/failures.dart';
import '../../../../core/errors/result.dart';
import '../../../../core/utils/app_logger.dart';
import '../../domain/entities/portfolio_snapshot_entity.dart';
import '../../domain/repositories/portfolio_repository.dart';
import '../datasources/portfolio_remote_datasource.dart';

class PortfolioRepositoryImpl implements PortfolioRepository {
  final PortfolioRemoteDataSource _remote;

  PortfolioRepositoryImpl(this._remote);

  @override
  Future<Result<void>> recordDailySnapshotIfNeeded({
    required String uid,
    required double totalValue,
    required double cashBalance,
    required double investedValue,
  }) async {
    try {
      await _remote.recordDailySnapshotIfNeeded(
        uid: uid,
        totalValue: totalValue,
        cashBalance: cashBalance,
        investedValue: investedValue,
      );
      return Result.success(null);
    } catch (e, st) {
      AppLogger.error('recordDailySnapshotIfNeeded failed', e, st);
      return Result.failure(const DataFailure('Could not save portfolio snapshot.'));
    }
  }

  @override
  Stream<List<PortfolioSnapshotEntity>> watchSnapshots(String uid, {int days = 30}) {
    return _remote.watchSnapshots(uid, days: days);
  }
}
