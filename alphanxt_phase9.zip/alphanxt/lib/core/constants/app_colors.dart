import 'package:flutter/material.dart';

/// Centralized color palette for AlphaNXT.
///
/// Default theme is Premium Dark Mode: true-black backgrounds with
/// layered near-black surfaces and modern gradients. Light mode is
/// supported as an explicit opt-in from Profile > Settings (see
/// core/theme/theme_provider.dart) — the app does not follow system
/// brightness by default.
///
/// All colors used across the app should be referenced from here rather
/// than hard-coded inline.
class AppColors {
  AppColors._();

  // ---------------- Brand / Accents ----------------
  /// Electric Blue — primary brand color, CTAs, active nav, key accents.
  static const Color primary = Color(0xFF3B82F6);
  static const Color primaryDark = Color(0xFF1D4ED8);
  static const Color primaryLight = Color(0xFF60A5FA);

  /// Emerald Green — secondary accent, success, profit, buy actions.
  static const Color secondary = Color(0xFF22C55E);

  /// Red — danger, loss, sell actions.
  static const Color danger = Color(0xFFEF4444);

  // ---------------- Semantic (Trading) ----------------
  /// Used for profit, buy actions, positive P/L, "up" candles.
  static const Color bullish = Color(0xFF22C55E);
  static const Color bullishBg = Color(0x1A22C55E);

  /// Used for loss, sell actions, negative P/L, "down" candles.
  static const Color bearish = Color(0xFFEF4444);
  static const Color bearishBg = Color(0x1AEF4444);

  /// Neutral warning (e.g. risk score medium, pending orders).
  static const Color warning = Color(0xFFFFB020);
  static const Color warningBg = Color(0x1AFFB020);

  // ---------------- Dark Theme (Premium Black — default) ----------------
  /// True black base background — the signature premium fintech look.
  static const Color darkBackground = Color(0xFF000000);
  /// Slightly lifted black for cards/surfaces so content separates from bg.
  static const Color darkSurface = Color(0xFF0D0F12);
  static const Color darkSurfaceVariant = Color(0xFF16191F);
  static const Color darkSurfaceElevated = Color(0xFF1C2028);
  static const Color darkTextPrimary = Color(0xFFF5F6FA);
  static const Color darkTextSecondary = Color(0xFF9AA1B2);
  static const Color darkBorder = Color(0xFF23262E);

  // ---------------- Light Theme (optional, via Profile setting) ----------------
  static const Color lightBackground = Color(0xFFF7F8FC);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightSurfaceVariant = Color(0xFFEEF1F8);
  static const Color lightTextPrimary = Color(0xFF13161F);
  static const Color lightTextSecondary = Color(0xFF6B7280);
  static const Color lightBorder = Color(0xFFE3E6EE);

  // ---------------- Glassmorphism ----------------
  static const Color glassLight = Color(0x33FFFFFF);
  static const Color glassDark = Color(0x14FFFFFF);
  static const Color glassBorderLight = Color(0x4DFFFFFF);
  static const Color glassBorderDark = Color(0x1FFFFFFF);

  // ---------------- Gradients ----------------
  /// Signature premium dark background gradient — near-black with a
  /// faint electric-blue glow, used behind hero/dashboard sections.
  static const LinearGradient premiumDarkGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Color(0xFF0A0E1A), Color(0xFF000000)],
  );

  /// Radial-style glow gradient for hero cards (balance card, etc).
  static const LinearGradient heroGlowGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF1E3A8A), Color(0xFF0F172A)],
  );

  static const LinearGradient primaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF3B82F6), Color(0xFF1D4ED8)],
  );

  static const LinearGradient bullishGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF22C55E), Color(0xFF16A34A)],
  );

  static const LinearGradient bearishGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFFEF4444), Color(0xFFB91C1C)],
  );

  static const LinearGradient darkCardGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF16191F), Color(0xFF0D0F12)],
  );
}
