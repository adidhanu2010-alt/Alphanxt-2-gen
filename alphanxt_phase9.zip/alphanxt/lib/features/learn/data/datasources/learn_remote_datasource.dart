import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../../core/constants/app_strings.dart';
import '../../domain/entities/course_progress_entity.dart';

class LearnRemoteDataSource {
  final FirebaseFirestore _firestore;

  LearnRemoteDataSource(this._firestore);

  CollectionReference<Map<String, dynamic>> get _coursesRef =>
      _firestore.collection(AppStrings.collectionCourses);
  CollectionReference<Map<String, dynamic>> get _badgesRef =>
      _firestore.collection(AppStrings.collectionBadges);

  String _progressDocId(String uid, String courseId) => '${uid}_$courseId';
  String _badgeDocId(String uid, String badgeId) => '${uid}_$badgeId';

  Stream<List<CourseProgressEntity>> watchProgress(String uid) {
    return _coursesRef.where('uid', isEqualTo: uid).snapshots().map((snap) {
      return snap.docs.map((d) {
        final data = d.data();
        return CourseProgressEntity(
          courseId: data['courseId'] as String? ?? '',
          lessonRead: data['lessonRead'] as bool? ?? false,
          bestQuizScorePercent: data['bestQuizScorePercent'] as int?,
          xpEarned: data['xpEarned'] as int? ?? 0,
          completedAt: (data['completedAt'] as Timestamp?)?.toDate(),
        );
      }).toList();
    });
  }

  Future<void> markLessonRead(String uid, String courseId) {
    return _coursesRef.doc(_progressDocId(uid, courseId)).set({
      'uid': uid,
      'courseId': courseId,
      'lessonRead': true,
    }, SetOptions(merge: true));
  }

  Future<void> submitQuizResult({
    required String uid,
    required String courseId,
    required int scorePercent,
    required int xpReward,
  }) async {
    final docRef = _coursesRef.doc(_progressDocId(uid, courseId));

    await _firestore.runTransaction((transaction) async {
      final snap = await transaction.get(docRef);
      final existingBest = snap.data()?['bestQuizScorePercent'] as int?;
      final alreadyEarnedXp = snap.data()?['xpEarned'] as int? ?? 0;
      final isFirstAttempt = existingBest == null;

      final newBest = existingBest == null
          ? scorePercent
          : (scorePercent > existingBest ? scorePercent : existingBest);

      transaction.set(
        docRef,
        {
          'uid': uid,
          'courseId': courseId,
          'bestQuizScorePercent': newBest,
          // XP is only ever credited once, on the first attempt — retakes
          // can improve the displayed best score but don't farm extra XP.
          'xpEarned': isFirstAttempt ? xpReward : alreadyEarnedXp,
          if (isFirstAttempt) 'completedAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );
    });
  }

  Stream<List<EarnedBadgeEntity>> watchEarnedBadges(String uid) {
    return _badgesRef.where('uid', isEqualTo: uid).snapshots().map((snap) {
      return snap.docs.map((d) {
        final data = d.data();
        return EarnedBadgeEntity(
          badgeId: data['badgeId'] as String? ?? '',
          earnedAt: (data['earnedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
        );
      }).toList();
    });
  }

  Future<void> awardBadgeIfNotEarned(String uid, String badgeId) async {
    final docRef = _badgesRef.doc(_badgeDocId(uid, badgeId));
    final existing = await docRef.get();
    if (existing.exists) return;
    await docRef.set({
      'uid': uid,
      'badgeId': badgeId,
      'earnedAt': FieldValue.serverTimestamp(),
    });
  }
}
