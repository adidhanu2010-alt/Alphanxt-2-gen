import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/theme/app_chart_theme.dart';
import '../../../../core/utils/formatters.dart';
import '../../domain/entities/portfolio_snapshot_entity.dart';

/// Line chart of the user's total portfolio value over time, built from
/// real daily snapshots (see [PortfolioSnapshotEntity] docs — history
/// only exists from days the app was actually opened).
class PortfolioValueChart extends StatelessWidget {
  final List<PortfolioSnapshotEntity> snapshots;

  const PortfolioValueChart({super.key, required this.snapshots});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (snapshots.length < 2) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(AppDimens.space16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Portfolio Value', style: theme.textTheme.titleSmall),
              const SizedBox(height: AppDimens.space12),
              SizedBox(
                height: 140,
                child: Center(
                  child: Text(
                    snapshots.isEmpty
                        ? 'Your portfolio history starts today and builds up\neach day you check in.'
                        : 'One more day of history to draw a trend line.',
                    textAlign: TextAlign.center,
                    style: theme.textTheme.bodySmall,
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    final isDark = theme.brightness == Brightness.dark;
    final values = snapshots.map((s) => s.totalValue).toList();
    final isPositive = values.last >= values.first;
    final color = isPositive ? AppChartTheme.lineUp : AppChartTheme.lineDown;
    final minY = values.reduce((a, b) => a < b ? a : b);
    final maxY = values.reduce((a, b) => a > b ? a : b);
    final pad = ((maxY - minY) * 0.15).clamp(1, double.infinity);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Portfolio Value', style: theme.textTheme.titleSmall),
            const SizedBox(height: AppDimens.space16),
            SizedBox(
              height: 160,
              child: LineChart(
                LineChartData(
                  minY: minY - pad,
                  maxY: maxY + pad,
                  gridData: FlGridData(
                    show: true,
                    drawVerticalLine: false,
                    getDrawingHorizontalLine: (v) =>
                        FlLine(color: AppChartTheme.gridColor(isDark), strokeWidth: 1),
                  ),
                  titlesData: const FlTitlesData(show: false),
                  borderData: FlBorderData(show: false),
                  lineTouchData: LineTouchData(
                    touchTooltipData: LineTouchTooltipData(
                      getTooltipColor: (_) =>
                          isDark ? const Color(0xFF1C2028) : Colors.white,
                      getTooltipItems: (spots) => spots.map((s) {
                        final snap = snapshots[s.x.toInt()];
                        return LineTooltipItem(
                          '${Formatters.currency(snap.totalValue)}\n',
                          TextStyle(
                            color: isDark ? Colors.white : Colors.black87,
                            fontWeight: FontWeight.w700,
                            fontSize: 12,
                          ),
                          children: [
                            TextSpan(
                              text: Formatters.date(snap.date),
                              style: TextStyle(
                                color: (isDark ? Colors.white : Colors.black87)
                                    .withValues(alpha: 0.6),
                                fontSize: 11,
                              ),
                            ),
                          ],
                        );
                      }).toList(),
                    ),
                  ),
                  lineBarsData: [
                    LineChartBarData(
                      spots: List.generate(
                        snapshots.length,
                        (i) => FlSpot(i.toDouble(), snapshots[i].totalValue),
                      ),
                      isCurved: true,
                      barWidth: 2.4,
                      color: color,
                      dotData: const FlDotData(show: false),
                      belowBarData: BarAreaData(
                        show: true,
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: AppChartTheme.areaGradient(color),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
