import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../auth/presentation/providers/auth_providers.dart';
import '../../data/content/course_catalog.dart';
import '../../data/datasources/learn_remote_datasource.dart';
import '../../data/repositories/learn_repository_impl.dart';
import '../../domain/badge_evaluator.dart';
import '../../domain/entities/course_progress_entity.dart';
import '../../domain/repositories/learn_repository.dart';

// ---------------- Data / Repository ----------------

final learnRemoteDataSourceProvider = Provider<LearnRemoteDataSource>((ref) {
  return LearnRemoteDataSource(ref.watch(firestoreProvider));
});

final learnRepositoryProvider = Provider<LearnRepository>((ref) {
  return LearnRepositoryImpl(ref.watch(learnRemoteDataSourceProvider));
});

// ---------------- Progress / badges streams ----------------

final courseProgressProvider =
    StreamProvider.autoDispose<List<CourseProgressEntity>>((ref) {
  final uid = ref.watch(authRepositoryProvider).currentUid;
  if (uid == null) return Stream.value(const []);
  return ref.watch(learnRepositoryProvider).watchProgress(uid);
});

final earnedBadgesProvider = StreamProvider.autoDispose<List<String>>((ref) {
  final uid = ref.watch(authRepositoryProvider).currentUid;
  if (uid == null) return Stream.value(const []);
  return ref
      .watch(learnRepositoryProvider)
      .watchEarnedBadges(uid)
      .map((badges) => badges.map((b) => b.badgeId).toList());
});

// ---------------- XP / Level ----------------

class XpSummary {
  final int totalXp;
  final int level;
  final int xpIntoLevel;
  final int xpForNextLevel;

  const XpSummary({
    required this.totalXp,
    required this.level,
    required this.xpIntoLevel,
    required this.xpForNextLevel,
  });

  double get progressToNextLevel =>
      xpForNextLevel == 0 ? 0 : xpIntoLevel / xpForNextLevel;
}

/// 100 XP per level — simple and transparent so learners can predict
/// their own progress.
const int _xpPerLevel = 100;

final xpSummaryProvider = Provider.autoDispose<XpSummary>((ref) {
  final progress = ref.watch(courseProgressProvider).valueOrNull ?? [];
  final totalXp = progress.fold<int>(0, (sum, p) => sum + p.xpEarned);
  final level = (totalXp ~/ _xpPerLevel) + 1;
  final xpIntoLevel = totalXp % _xpPerLevel;

  return XpSummary(
    totalXp: totalXp,
    level: level,
    xpIntoLevel: xpIntoLevel,
    xpForNextLevel: _xpPerLevel,
  );
});

// ---------------- Badge auto-award side effect ----------------

/// Watches real progress and awards any newly-qualified badges. Wired to
/// run from the Learn screen so badges appear promptly after finishing
/// a course, without needing a backend trigger.
final badgeAwardCheckerProvider = FutureProvider.autoDispose<void>((ref) async {
  final uid = ref.watch(authRepositoryProvider).currentUid;
  if (uid == null) return;

  final progressAsync = ref.watch(courseProgressProvider);
  final earnedAsync = ref.watch(earnedBadgesProvider);
  if (!progressAsync.hasValue || !earnedAsync.hasValue) return;

  final progress = progressAsync.value!;
  final alreadyEarned = earnedAsync.value!.toSet();

  final qualified = BadgeEvaluator.qualifiedBadgeIds(
    allCourses: CourseCatalog.all,
    progress: progress,
  );

  final newlyQualified = qualified.difference(alreadyEarned);
  for (final badgeId in newlyQualified) {
    await ref.read(learnRepositoryProvider).awardBadgeIfNotEarned(uid, badgeId);
  }
});

// ---------------- Quiz-taking controller ----------------

class QuizSubmitState {
  final bool isLoading;
  final String? errorMessage;
  const QuizSubmitState({this.isLoading = false, this.errorMessage});
  static const idle = QuizSubmitState();
  static const loading = QuizSubmitState(isLoading: true);
}

class LearnActionController extends StateNotifier<QuizSubmitState> {
  final LearnRepository _repository;
  final String? _uid;

  LearnActionController(this._repository, this._uid) : super(QuizSubmitState.idle);

  Future<void> markLessonRead(String courseId) async {
    final uid = _uid;
    if (uid == null) return;
    await _repository.markLessonRead(uid, courseId);
  }

  Future<bool> submitQuiz({
    required String courseId,
    required int scorePercent,
    required int xpReward,
  }) async {
    final uid = _uid;
    if (uid == null) return false;
    state = QuizSubmitState.loading;
    final result = await _repository.submitQuizResult(
      uid: uid,
      courseId: courseId,
      scorePercent: scorePercent,
      xpReward: xpReward,
    );
    state = result.isSuccess
        ? QuizSubmitState.idle
        : QuizSubmitState(errorMessage: result.failure.message);
    return result.isSuccess;
  }
}

final learnActionControllerProvider =
    StateNotifierProvider.autoDispose<LearnActionController, QuizSubmitState>((ref) {
  return LearnActionController(
    ref.watch(learnRepositoryProvider),
    ref.watch(authRepositoryProvider).currentUid,
  );
});
