import '../../../../core/errors/result.dart';
import '../../../paper_trade/domain/entities/position_entity.dart';
import '../entities/trade_analysis_entity.dart';

/// Contract for the AI Trading Coach — generates a plain-language
/// analysis of one closed trade.
///
/// IMPORTANT — how this works: [analyzeTrade] first computes real
/// metrics (entry, exit, risk %, reward:risk, trend, holding time,
/// position size, volatility) via [TradeMetricsCalculator], then sends
/// ONLY those already-computed numbers to an LLM (Claude) with strict
/// instructions to narrate around them, not invent new statistics, and
/// never claim or imply a guaranteed profitable outcome. The analysis
/// is cached on the underlying trade record after first generation, so
/// re-opening the same trade doesn't re-call the API.
///
/// This requires an Anthropic API key (`AI_COACH_API_KEY` in `.env`).
/// Calling a paid LLM API directly from a shipped mobile client also
/// means that key is embedded in the app binary and can be extracted —
/// acceptable for development/demo, but a production release should
/// proxy this call through a backend (e.g. a Firebase Cloud Function)
/// so the key never ships to end-user devices. See project README.
abstract class AiCoachRepository {
  Future<Result<TradeAnalysisEntity>> analyzeTrade({
    required String uid,
    required PositionEntity closedPosition,
    required String closingTransactionId,
    bool forceRegenerate = false,
  });
}
