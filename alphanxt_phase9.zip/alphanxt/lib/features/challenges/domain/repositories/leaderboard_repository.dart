import '../../../../core/errors/result.dart';
import '../entities/leaderboard_entry_entity.dart';

/// Handles the denormalized `leaderboard` collection.
///
/// PRIVACY NOTE: every signed-in user can read every other user's
/// leaderboard entry (name, photo, XP, returns) — that's the point of a
/// leaderboard, but it means this data is intentionally NOT protected
/// the way the rest of a user's account is. A user's real name and
/// trading performance become visible to other users. Consider adding
/// an opt-in/opt-out setting in Profile (Phase 10) before shipping this
/// publicly, and enforce write-only-your-own-doc in Firestore security
/// rules (Phase 11).
abstract class LeaderboardRepository {
  Future<Result<void>> updateMyEntry({
    required String uid,
    required String displayName,
    String? photoUrl,
    required int totalXp,
    required double portfolioReturnPercent,
  });

  Stream<List<LeaderboardEntryEntity>> watchTopByXp({int limit});
  Stream<List<LeaderboardEntryEntity>> watchTopByReturns({int limit});
}
