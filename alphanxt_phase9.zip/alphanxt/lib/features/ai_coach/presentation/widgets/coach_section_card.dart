import 'package:flutter/material.dart';
import '../../../../core/constants/app_dimens.dart';

/// A titled, icon-colored list section — used for each of the coach's
/// narrative categories (What Went Well, Mistakes, Risk Tips, etc).
class CoachSectionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final List<String> items;

  const CoachSectionCard({
    super.key,
    required this.title,
    required this.icon,
    required this.color,
    required this.items,
  });

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const SizedBox.shrink();
    final theme = Theme.of(context);

    return Card(
      margin: const EdgeInsets.only(bottom: AppDimens.space12),
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: AppDimens.iconSmall, color: color),
                const SizedBox(width: AppDimens.space8),
                Text(title, style: theme.textTheme.titleSmall?.copyWith(color: color)),
              ],
            ),
            const SizedBox(height: AppDimens.space12),
            ...items.map(
              (text) => Padding(
                padding: const EdgeInsets.only(bottom: AppDimens.space8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Container(
                        height: 5,
                        width: 5,
                        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                      ),
                    ),
                    const SizedBox(width: AppDimens.space12),
                    Expanded(child: Text(text, style: theme.textTheme.bodyMedium)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
