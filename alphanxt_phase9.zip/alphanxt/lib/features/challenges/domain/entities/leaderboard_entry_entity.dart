import 'package:equatable/equatable.dart';

/// One row on the leaderboard — a denormalized snapshot of a user's
/// public stats. Written by each user for themselves whenever their
/// data changes (see [LeaderboardRepository] docs); read by everyone.
class LeaderboardEntryEntity extends Equatable {
  final String uid;
  final String displayName;
  final String? photoUrl;
  final int totalXp;
  final double portfolioReturnPercent;
  final DateTime updatedAt;

  const LeaderboardEntryEntity({
    required this.uid,
    required this.displayName,
    this.photoUrl,
    required this.totalXp,
    required this.portfolioReturnPercent,
    required this.updatedAt,
  });

  @override
  List<Object?> get props =>
      [uid, displayName, photoUrl, totalXp, portfolioReturnPercent, updatedAt];
}
