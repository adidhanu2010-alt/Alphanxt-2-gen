import '../../domain/entities/course_entity.dart';

class AdvancedCourses {
  AdvancedCourses._();

  static const breakouts = CourseEntity(
    id: 'breakouts',
    title: 'Breakout Trading',
    level: CourseLevel.advanced,
    description: 'Trading the move when price escapes a defined range.',
    iconKey: 'call_made',
    estimatedMinutes: 8,
    xpReward: 70,
    lessonContent: '''
A breakout occurs when price moves decisively beyond a defined range — commonly a resistance level, a support level, or the edges of a consolidation pattern (like a triangle or rectangle) where price has been trading sideways. The idea is that once a key level gives way, the shift in supply/demand balance can drive a sustained move in the breakout's direction.

Confirmation matters. A "false breakout" (or "fakeout") happens when price pokes through a level but quickly reverses back inside the range — common when volume behind the move is weak, or when a level is well-known and heavily watched (making it a target for larger players to trigger stop-losses before reversing). Many breakout traders wait for a candle to close beyond the level, and look for volume expansion, before treating a breakout as valid rather than reacting to the first tick through the line.

A common structure is to set a stop-loss just back inside the broken range (so a false breakout exits you quickly and cheaply) with a target based on the height of the prior consolidation range projected from the breakout point.

Breakout trading has an inherent trade-off: waiting for more confirmation reduces false signals but means entering after some of the move has already happened.
''',
    quiz: [
      QuizQuestionEntity(
        id: 'b1',
        question: 'A "false breakout" or "fakeout" is when:',
        options: [
          'Price breaks a level and continues strongly in that direction',
          'Price briefly breaks a level then reverses back inside the range',
          'A breakout happens on very high volume',
          'The market is closed',
        ],
        correctIndex: 1,
        explanation: 'The initial break fails to hold, and price snaps back into the prior range.',
      ),
      QuizQuestionEntity(
        id: 'b2',
        question: 'Many breakout traders look for which two things before treating a breakout as valid?',
        options: [
          'A closed candle beyond the level and volume expansion',
          'A news headline and a full moon',
          'Just the first tick through the level',
          'A decrease in volume',
        ],
        correctIndex: 0,
        explanation: 'A confirmed close beyond the level plus stronger volume adds credibility to the breakout.',
      ),
      QuizQuestionEntity(
        id: 'b3',
        question: 'The trade-off of waiting for more breakout confirmation is:',
        options: [
          'No trade-off exists',
          'You reduce false signals but enter after some of the move has already happened',
          'You guarantee a winning trade',
          'You eliminate all risk',
        ],
        correctIndex: 1,
        explanation: 'More confirmation filters out fakeouts but costs you some of the early move.',
      ),
    ],
  );

  static const swingTrading = CourseEntity(
    id: 'swing_trading',
    title: 'Swing Trading',
    level: CourseLevel.advanced,
    description: 'Holding trades for days to weeks to capture a larger price swing.',
    iconKey: 'waves',
    estimatedMinutes: 8,
    xpReward: 70,
    lessonContent: '''
Swing trading aims to capture a "swing" in price — a multi-day to multi-week move — rather than the very short-term moves of intraday trading or the long holds of buy-and-hold investing. It sits between those two, trading around the ebbs and flows within a larger trend.

Because trades are held overnight (and sometimes over weekends), swing traders are exposed to gap risk — price can open significantly different from where it closed, especially around news events, which a stop-loss can't always protect against precisely since it may fill at a worse price than intended during a gap.

A typical swing approach combines a higher-timeframe view (e.g. is the daily chart in an uptrend?) with a lower-timeframe entry trigger (e.g. a pullback to a moving average or support level on a shorter chart), aiming to enter in the direction of the larger trend rather than against it.

Because swing trades are held longer, position sizing and patience matter more than speed of execution — the trader needs to tolerate some natural back-and-forth movement without exiting the plan prematurely, while still respecting a predefined stop-loss if the original thesis is proven wrong.
''',
    quiz: [
      QuizQuestionEntity(
        id: 'sw1',
        question: 'Swing trading typically holds positions for:',
        options: [
          'Seconds to minutes',
          'Days to weeks',
          'Multiple years',
          'Exactly one trading session',
        ],
        correctIndex: 1,
        explanation: 'It sits between short-term intraday trading and long-term investing.',
      ),
      QuizQuestionEntity(
        id: 'sw2',
        question: 'A key risk of holding trades overnight is:',
        options: [
          'Gap risk — price opening significantly away from where it closed',
          'No risk at all since markets are closed',
          'Guaranteed profit from time decay',
          'Loss of voting rights',
        ],
        correctIndex: 0,
        explanation: 'Price can gap past a stop-loss level, especially around news, filling at a worse price.',
      ),
      QuizQuestionEntity(
        id: 'sw3',
        question: 'A typical swing trading approach combines:',
        options: [
          'Only a 1-minute chart',
          'A higher-timeframe trend view with a lower-timeframe entry trigger',
          'Random entries with no chart analysis',
          'Only news headlines',
        ],
        correctIndex: 1,
        explanation: 'Aligning the entry with the larger trend direction is a common swing-trading framework.',
      ),
    ],
  );

  static const scalping = CourseEntity(
    id: 'scalping',
    title: 'Scalping',
    level: CourseLevel.advanced,
    description: 'Very short-term trading aiming for small, frequent gains.',
    iconKey: 'bolt',
    estimatedMinutes: 8,
    xpReward: 70,
    lessonContent: '''
Scalping is the shortest-timeframe style of trading, with positions often held for seconds to a few minutes. The goal is to capture small price movements repeatedly rather than waiting for a large move, relying on high trade frequency rather than large individual gains.

Because each trade targets a small move, transaction costs (spreads, fees) matter far more to scalping than to swing trading — a cost that's negligible on a large multi-day move can eat a meaningful share of a scalp's small target. This is one reason scalping is generally considered one of the more demanding styles to execute profitably.

Scalping requires intense, sustained focus and fast decision-making, since setups can appear and disappear within moments. It also requires strict discipline around risk per trade, since the frequency of trades means mistakes compound quickly if position sizing or stop-losses aren't followed precisely every single time.

Because AlphaNXT uses real (if slightly delayed) market data and client-side order checking rather than a professional low-latency execution feed, it's a reasonable environment to learn the *concepts* of scalping, but it won't replicate the speed of a live scalping environment.
''',
    quiz: [
      QuizQuestionEntity(
        id: 'sc1',
        question: 'Scalping positions are typically held for:',
        options: ['Months', 'Weeks', 'Seconds to a few minutes', 'Exactly one year'],
        correctIndex: 2,
        explanation: 'It\'s the shortest-timeframe trading style, aiming for many small, quick gains.',
      ),
      QuizQuestionEntity(
        id: 'sc2',
        question: 'Why do transaction costs matter more to scalping than swing trading?',
        options: [
          'They don\'t — costs are the same for every style',
          'Each scalp targets a small move, so costs eat a larger share of the target',
          'Scalping has no fees at all',
          'Scalpers trade only once a year',
        ],
        correctIndex: 1,
        explanation: 'A cost that\'s trivial on a large swing move can be significant relative to a scalp\'s small target.',
      ),
      QuizQuestionEntity(
        id: 'sc3',
        question: 'What does this lesson note about practicing scalping in AlphaNXT specifically?',
        options: [
          'It perfectly replicates professional low-latency execution',
          'It\'s good for learning the concepts, but won\'t replicate live low-latency execution speed',
          'Scalping is disabled in the app',
          'It guarantees profitable scalp trades',
        ],
        correctIndex: 1,
        explanation: 'AlphaNXT is an educational paper-trading environment, not a low-latency execution platform.',
      ),
    ],
  );

  static const all = [breakouts, swingTrading, scalping];
}
