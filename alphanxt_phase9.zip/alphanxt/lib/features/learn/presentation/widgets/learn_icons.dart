import 'package:flutter/material.dart';

/// Maps the string `iconKey` stored on courses/badges to a real
/// [IconData]. Kept as a lookup (rather than storing IconData directly
/// on domain entities) so the domain layer has zero Flutter dependency.
IconData learnIconFor(String key) {
  switch (key) {
    case 'candlestick_chart':
      return Icons.candlestick_chart_rounded;
    case 'horizontal_rule':
      return Icons.horizontal_rule_rounded;
    case 'shield':
      return Icons.shield_rounded;
    case 'psychology':
      return Icons.psychology_rounded;
    case 'show_chart':
      return Icons.show_chart_rounded;
    case 'speed':
      return Icons.speed_rounded;
    case 'ssid_chart':
      return Icons.ssid_chart_rounded;
    case 'bar_chart':
      return Icons.bar_chart_rounded;
    case 'timeline':
      return Icons.timeline_rounded;
    case 'call_made':
      return Icons.call_made_rounded;
    case 'waves':
      return Icons.waves_rounded;
    case 'bolt':
      return Icons.bolt_rounded;
    case 'flag':
      return Icons.flag_rounded;
    case 'school':
      return Icons.school_rounded;
    case 'trending_up':
      return Icons.trending_up_rounded;
    case 'workspace_premium':
      return Icons.workspace_premium_rounded;
    case 'quiz':
      return Icons.quiz_rounded;
    case 'stars':
      return Icons.stars_rounded;
    default:
      return Icons.book_rounded;
  }
}
