import 'package:equatable/equatable.dart';

/// Domain-layer representation of an authenticated AlphaNXT user.
///
/// This is what the rest of the app (providers, UI) works with — never
/// a raw `firebase_auth.User` or a Firestore `DocumentSnapshot`. Keeping
/// this decoupled from Firebase means the data layer can be swapped
/// without touching any UI code.
class AppUserEntity extends Equatable {
  final String uid;
  final String email;
  final String displayName;
  final String? photoUrl;
  final bool emailVerified;
  final double virtualBalance;
  final DateTime createdAt;

  const AppUserEntity({
    required this.uid,
    required this.email,
    required this.displayName,
    this.photoUrl,
    required this.emailVerified,
    required this.virtualBalance,
    required this.createdAt,
  });

  AppUserEntity copyWith({
    String? uid,
    String? email,
    String? displayName,
    String? photoUrl,
    bool? emailVerified,
    double? virtualBalance,
    DateTime? createdAt,
  }) {
    return AppUserEntity(
      uid: uid ?? this.uid,
      email: email ?? this.email,
      displayName: displayName ?? this.displayName,
      photoUrl: photoUrl ?? this.photoUrl,
      emailVerified: emailVerified ?? this.emailVerified,
      virtualBalance: virtualBalance ?? this.virtualBalance,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  List<Object?> get props => [
        uid,
        email,
        displayName,
        photoUrl,
        emailVerified,
        virtualBalance,
        createdAt,
      ];
}
