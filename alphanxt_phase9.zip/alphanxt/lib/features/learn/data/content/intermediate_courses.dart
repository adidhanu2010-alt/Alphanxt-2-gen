import '../../domain/entities/course_entity.dart';

class IntermediateCourses {
  IntermediateCourses._();

  static const ema = CourseEntity(
    id: 'ema',
    title: 'Exponential Moving Average (EMA)',
    level: CourseLevel.intermediate,
    description: 'A trend-following indicator that reacts faster than a simple average.',
    iconKey: 'show_chart',
    estimatedMinutes: 7,
    xpReward: 60,
    lessonContent: '''
A moving average smooths out price data to show the underlying trend by averaging prices over a chosen period (e.g. 20 days). A Simple Moving Average (SMA) weights every price in that window equally. An Exponential Moving Average (EMA) instead gives more weight to recent prices, so it reacts faster to new information than an SMA of the same length.

Traders commonly use EMAs to gauge trend direction: price consistently above a rising EMA suggests an uptrend; price below a falling EMA suggests a downtrend. A "crossover" — a shorter EMA crossing above a longer EMA — is often watched as a potential trend-change signal (and the reverse crossing below as a potential downtrend signal). These are commonly called "golden cross" and "death cross" when using longer-term averages like the 50 and 200.

EMAs are lagging indicators — because they're built from past prices, they confirm a trend after it has already started, not before. They work best combined with other context (like support/resistance or volume) rather than as a signal on their own, and they can generate false signals in a choppy, sideways market.
''',
    quiz: [
      QuizQuestionEntity(
        id: 'e1',
        question: 'Compared to a Simple Moving Average, an EMA:',
        options: [
          'Weights all prices equally',
          'Gives more weight to recent prices, reacting faster',
          'Ignores the most recent price entirely',
          'Only works on daily charts',
        ],
        correctIndex: 1,
        explanation: 'The exponential weighting makes EMAs more responsive to new price action than an SMA.',
      ),
      QuizQuestionEntity(
        id: 'e2',
        question: 'A "golden cross" typically refers to:',
        options: [
          'Price crossing below support',
          'A shorter-term average crossing above a longer-term average',
          'Volume doubling in one day',
          'RSI crossing above 70',
        ],
        correctIndex: 1,
        explanation: 'It\'s often used (e.g. 50 EMA crossing above 200 EMA) as a potential bullish trend signal.',
      ),
      QuizQuestionEntity(
        id: 'e3',
        question: 'Moving averages are considered:',
        options: [
          'Leading indicators that predict future prices exactly',
          'Lagging indicators built from past price data',
          'Only useful for cryptocurrencies',
          'A guarantee of trend continuation',
        ],
        correctIndex: 1,
        explanation: 'Since they\'re calculated from historical prices, they confirm trends after they\'ve begun.',
      ),
    ],
  );

  static const rsi = CourseEntity(
    id: 'rsi',
    title: 'Relative Strength Index (RSI)',
    level: CourseLevel.intermediate,
    description: 'A momentum indicator that measures the speed of recent price changes.',
    iconKey: 'speed',
    estimatedMinutes: 7,
    xpReward: 60,
    lessonContent: '''
RSI is a momentum oscillator scaled from 0 to 100, calculated from the average size of recent gains versus recent losses (typically over 14 periods). It's designed to show how "stretched" a recent move is.

The classic interpretation: an RSI above 70 is often labeled "overbought," suggesting the recent up-move may be extended and due for a pause or pullback. An RSI below 30 is often labeled "oversold," suggesting the recent down-move may be extended. These are guidelines, not rules — in a strong trend, RSI can stay above 70 (or below 30) for a long stretch while price keeps moving in that direction.

A more advanced use is "divergence": if price makes a new high but RSI makes a lower high, that's a bearish divergence, hinting that upward momentum is fading even though price is still rising. The reverse (price makes a lower low, RSI makes a higher low) is bullish divergence.

Like all indicators, RSI works from past price data. It measures existing momentum, not future direction, and is most useful alongside other context like trend and support/resistance rather than as a standalone signal.
''',
    quiz: [
      QuizQuestionEntity(
        id: 'rsi1',
        question: 'RSI is scaled from:',
        options: ['-100 to 100', '0 to 100', '0 to 10', '1 to 5'],
        correctIndex: 1,
        explanation: 'RSI is a bounded oscillator between 0 and 100.',
      ),
      QuizQuestionEntity(
        id: 'rsi2',
        question: 'An RSI reading above 70 is traditionally interpreted as:',
        options: ['Oversold', 'Overbought', 'A guaranteed reversal', 'A sell signal that always works'],
        correctIndex: 1,
        explanation: 'It suggests the recent upward move may be stretched — a guideline, not a certainty.',
      ),
      QuizQuestionEntity(
        id: 'rsi3',
        question: 'Bearish divergence occurs when:',
        options: [
          'Price and RSI both make new highs together',
          'Price makes a new high but RSI makes a lower high',
          'RSI crosses above 50',
          'Volume increases sharply',
        ],
        correctIndex: 1,
        explanation: 'This mismatch can hint that the momentum behind the price rise is fading.',
      ),
    ],
  );

  static const macd = CourseEntity(
    id: 'macd',
    title: 'MACD',
    level: CourseLevel.intermediate,
    description: 'Moving Average Convergence Divergence — a trend and momentum tool in one.',
    iconKey: 'ssid_chart',
    estimatedMinutes: 8,
    xpReward: 60,
    lessonContent: '''
MACD is built from two EMAs. The "MACD line" is the difference between a shorter EMA (commonly 12) and a longer EMA (commonly 26). A "signal line" (commonly a 9-period EMA of the MACD line itself) is plotted alongside it. The "histogram" shows the gap between the two, making crossovers easier to see visually.

When the MACD line crosses above the signal line, it's often read as bullish momentum building; crossing below is often read as bearish momentum building. When the MACD line is above zero, the shorter EMA is above the longer EMA (a broadly bullish setup); below zero suggests the opposite.

MACD combines trend-following (from the EMAs) with momentum (from the rate of change between them), which is why it's popular — but that also means it inherits the lag of moving averages. In choppy, range-bound markets, MACD crossovers can whipsaw back and forth, giving frequent false signals.

As with RSI, divergence between MACD and price is also watched: price making new highs while MACD fails to make a new high can suggest weakening momentum behind the move.
''',
    quiz: [
      QuizQuestionEntity(
        id: 'm1',
        question: 'The MACD line is calculated as:',
        options: [
          'The RSI minus 50',
          'The difference between a shorter EMA and a longer EMA',
          'The total trading volume',
          'The highest high of the last 14 periods',
        ],
        correctIndex: 1,
        explanation: 'Commonly the 12-period EMA minus the 26-period EMA.',
      ),
      QuizQuestionEntity(
        id: 'm2',
        question: 'The MACD histogram visually represents:',
        options: [
          'Trading volume',
          'The gap between the MACD line and the signal line',
          'The asset\'s market capitalization',
          'The number of open positions',
        ],
        correctIndex: 1,
        explanation: 'It makes the distance (and crossovers) between the two lines easier to read at a glance.',
      ),
      QuizQuestionEntity(
        id: 'm3',
        question: 'A known weakness of MACD is that it can:',
        options: [
          'Never be wrong in a trending market',
          'Whipsaw with frequent false signals in choppy, range-bound markets',
          'Only be used on weekly charts',
          'Predict news events',
        ],
        correctIndex: 1,
        explanation: 'Being built from moving averages, it can lag and give false crossover signals when price isn\'t trending clearly.',
      ),
    ],
  );

  static const volume = CourseEntity(
    id: 'volume',
    title: 'Volume Analysis',
    level: CourseLevel.intermediate,
    description: 'Why "how much" traded matters as much as "which direction."',
    iconKey: 'bar_chart',
    estimatedMinutes: 6,
    xpReward: 55,
    lessonContent: '''
Volume is simply the number of units (shares, coins, contracts) traded in a given period. It's a measure of participation and conviction behind a price move.

A price move on high volume generally carries more weight than the same move on low volume — it suggests more market participants agree with the direction, not just a handful of trades pushing price around thin liquidity. A breakout above resistance on strong volume is considered more credible than the same breakout on weak volume, which is more prone to failing and reversing.

Volume can also flag exhaustion: a strong trend that suddenly shows a huge volume spike with little further price progress can indicate that buyers (or sellers) are getting used up — often called a "climax."

Watching volume alongside price, rather than price alone, helps separate a move with real participation behind it from one that might just be noise in thin trading.
''',
    quiz: [
      QuizQuestionEntity(
        id: 'v1',
        question: 'Volume measures:',
        options: [
          'The price change over a day',
          'The number of units traded in a period',
          'The bid-ask spread',
          'The market capitalization',
        ],
        correctIndex: 1,
        explanation: 'It\'s a raw count of trading activity/participation, not a price figure.',
      ),
      QuizQuestionEntity(
        id: 'v2',
        question: 'A breakout above resistance is generally considered more credible when:',
        options: [
          'It happens overnight with no volume data',
          'It occurs on low volume',
          'It occurs on strong volume',
          'Volume is irrelevant to breakouts',
        ],
        correctIndex: 2,
        explanation: 'Higher volume suggests broader participant agreement behind the move.',
      ),
      QuizQuestionEntity(
        id: 'v3',
        question: 'A "volume climax" during a strong trend can suggest:',
        options: [
          'The trend will definitely continue forever',
          'Possible exhaustion of buyers or sellers',
          'A data error in the chart',
          'The asset has been delisted',
        ],
        correctIndex: 1,
        explanation: 'A huge volume spike with little further price progress can hint the move is running out of participants.',
      ),
    ],
  );

  static const priceAction = CourseEntity(
    id: 'price_action',
    title: 'Price Action Basics',
    level: CourseLevel.intermediate,
    description: 'Reading raw price movement without relying on indicators.',
    iconKey: 'timeline',
    estimatedMinutes: 7,
    xpReward: 60,
    lessonContent: '''
Price action trading focuses on the raw movement of price itself — highs, lows, candle patterns, and structure — rather than derived indicators like RSI or MACD. The idea is that price is the most direct information available; indicators are just calculations built from it after the fact.

A key concept is market structure: an uptrend is generally defined as a series of higher highs and higher lows, while a downtrend is a series of lower highs and lower lows. When that pattern breaks — say, an uptrend fails to make a new higher high and instead breaks below the last higher low — it's often an early signal that the trend may be shifting.

Price action traders also study how price reacts at key levels (support, resistance, prior highs/lows). A sharp rejection with long wicks at a level suggests that level is being defended; a clean break through with strong bodies suggests it's giving way.

Price action isn't "indicator-free" magic — it takes practice to read objectively rather than seeing whatever pattern you expect to see, which is a common pitfall for traders new to this approach.
''',
    quiz: [
      QuizQuestionEntity(
        id: 'pa1',
        question: 'An uptrend in market structure is typically defined as:',
        options: [
          'A series of higher highs and higher lows',
          'A series of lower highs and lower lows',
          'Any single green candle',
          'A period of zero volatility',
        ],
        correctIndex: 0,
        explanation: 'Each swing high and swing low is higher than the last one before it.',
      ),
      QuizQuestionEntity(
        id: 'pa2',
        question: 'Price action trading primarily relies on:',
        options: [
          'Only news headlines',
          'Raw price movement and structure rather than derived indicators',
          'Random number generation',
          'Only company fundamentals',
        ],
        correctIndex: 1,
        explanation: 'It studies price and candle behavior directly, treating indicators as secondary/derived.',
      ),
      QuizQuestionEntity(
        id: 'pa3',
        question: 'A common pitfall for new price-action traders is:',
        options: [
          'Using too many indicators',
          'Seeing whatever pattern they expect to see rather than reading objectively',
          'Trading too infrequently',
          'Avoiding charts altogether',
        ],
        correctIndex: 1,
        explanation: 'Without objective rules, it\'s easy to unconsciously fit patterns to a desired conclusion.',
      ),
    ],
  );

  static const all = [ema, rsi, macd, volume, priceAction];
}
