import 'package:equatable/equatable.dart';

enum CourseLevel { beginner, intermediate, advanced }

extension CourseLevelX on CourseLevel {
  String get label => switch (this) {
        CourseLevel.beginner => 'Beginner',
        CourseLevel.intermediate => 'Intermediate',
        CourseLevel.advanced => 'Advanced',
      };
}

class QuizQuestionEntity extends Equatable {
  final String id;
  final String question;
  final List<String> options;
  final int correctIndex;
  final String explanation;

  const QuizQuestionEntity({
    required this.id,
    required this.question,
    required this.options,
    required this.correctIndex,
    required this.explanation,
  });

  @override
  List<Object?> get props => [id, question, options, correctIndex, explanation];
}

/// A course covers one trading topic — real, authored educational
/// content bundled with the app (not fetched from an external CMS).
/// Only the user's *progress* through a course lives in Firestore; the
/// content itself ships with the app so it always works offline and
/// doesn't depend on any content-management backend that wasn't part of
/// this project's scope.
class CourseEntity extends Equatable {
  final String id;
  final String title;
  final CourseLevel level;
  final String description;
  final String iconKey;
  final int estimatedMinutes;
  final int xpReward;
  final String lessonContent;
  final List<QuizQuestionEntity> quiz;

  const CourseEntity({
    required this.id,
    required this.title,
    required this.level,
    required this.description,
    required this.iconKey,
    required this.estimatedMinutes,
    required this.xpReward,
    required this.lessonContent,
    required this.quiz,
  });

  @override
  List<Object?> get props => [
        id,
        title,
        level,
        description,
        iconKey,
        estimatedMinutes,
        xpReward,
        lessonContent,
        quiz,
      ];
}
