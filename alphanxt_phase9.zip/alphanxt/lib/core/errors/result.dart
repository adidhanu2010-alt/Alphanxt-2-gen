import 'failures.dart';

/// A minimal Either-style Result type: either a [Failure] or a success
/// value of type [T].
///
/// Chosen over adding the full `fpdart`/`dartz` dependency to keep the
/// core lightweight and the failure-handling explicit and readable for
/// every contributor on the team.
///
/// Example:
/// ```dart
/// Future<Result<UserEntity>> login(String email, String password) async {
///   try {
///     final user = await _authDataSource.login(email, password);
///     return Result.success(user);
///   } on FirebaseAuthException catch (e) {
///     return Result.failure(AuthFailure(e.message ?? 'Login failed'));
///   }
/// }
/// ```
class Result<T> {
  final T? _value;
  final Failure? _failure;

  const Result._(this._value, this._failure);

  factory Result.success(T value) => Result._(value, null);
  factory Result.failure(Failure failure) => Result._(null, failure);

  bool get isSuccess => _failure == null;
  bool get isFailure => _failure != null;

  T get value {
    if (_failure != null) {
      throw StateError('Tried to read value from a failed Result: ${_failure.message}');
    }
    return _value as T;
  }

  Failure get failure {
    if (_failure == null) {
      throw StateError('Tried to read failure from a successful Result.');
    }
    return _failure;
  }

  /// Pattern-match style handling without needing a package dependency.
  R when<R>({
    required R Function(T value) success,
    required R Function(Failure failure) failure,
  }) {
    if (isSuccess) return success(_value as T);
    return failure(_failure!);
  }
}
