import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/order_enums.dart';
import '../../domain/entities/transaction_entity.dart';

class TransactionModel extends TransactionEntity {
  const TransactionModel({
    required super.id,
    required super.uid,
    required super.assetId,
    required super.symbol,
    required super.name,
    super.imageUrl,
    required super.side,
    required super.orderType,
    required super.status,
    super.requestedPrice,
    super.executedPrice,
    required super.quantity,
    super.stopLoss,
    super.takeProfit,
    super.realizedPnl,
    super.positionId,
    required super.createdAt,
    super.filledAt,
    super.cancelReason,
  });

  factory TransactionModel.fromMap(Map<String, dynamic> map, String id) {
    return TransactionModel(
      id: id,
      uid: map['uid'] as String? ?? '',
      assetId: map['assetId'] as String? ?? '',
      symbol: map['symbol'] as String? ?? '',
      name: map['name'] as String? ?? '',
      imageUrl: map['imageUrl'] as String?,
      side: (map['side'] as String?) == 'sell' ? OrderSide.sell : OrderSide.buy,
      orderType: (map['orderType'] as String?) == 'limit'
          ? OrderType.limit
          : OrderType.market,
      status: switch (map['status'] as String?) {
        'filled' => TransactionStatus.filled,
        'cancelled' => TransactionStatus.cancelled,
        _ => TransactionStatus.pending,
      },
      requestedPrice: (map['requestedPrice'] as num?)?.toDouble(),
      executedPrice: (map['executedPrice'] as num?)?.toDouble(),
      quantity: (map['quantity'] as num?)?.toDouble() ?? 0,
      stopLoss: (map['stopLoss'] as num?)?.toDouble(),
      takeProfit: (map['takeProfit'] as num?)?.toDouble(),
      realizedPnl: (map['realizedPnl'] as num?)?.toDouble(),
      positionId: map['positionId'] as String?,
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      filledAt: (map['filledAt'] as Timestamp?)?.toDate(),
      cancelReason: map['cancelReason'] as String?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'assetId': assetId,
      'symbol': symbol,
      'name': name,
      'imageUrl': imageUrl,
      'side': side == OrderSide.sell ? 'sell' : 'buy',
      'orderType': orderType == OrderType.limit ? 'limit' : 'market',
      'status': switch (status) {
        TransactionStatus.filled => 'filled',
        TransactionStatus.cancelled => 'cancelled',
        TransactionStatus.pending => 'pending',
      },
      'requestedPrice': requestedPrice,
      'executedPrice': executedPrice,
      'quantity': quantity,
      'stopLoss': stopLoss,
      'takeProfit': takeProfit,
      'realizedPnl': realizedPnl,
      'positionId': positionId,
      'createdAt': Timestamp.fromDate(createdAt),
      'filledAt': filledAt != null ? Timestamp.fromDate(filledAt!) : null,
      'cancelReason': cancelReason,
    };
  }
}
