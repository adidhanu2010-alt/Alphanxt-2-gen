/// A small rotating set of general trading-education tips shown on the
/// Home screen's "Daily Tip" card.
///
/// IMPORTANT: These are static, curated educational reminders — NOT
/// AI-generated and NOT personalized trade analysis. The real AI Trading
/// Coach (which analyzes a user's actual trades) is built in Phase 7;
/// this card is intentionally simple and generic so it never implies
/// personalized advice or guaranteed outcomes.
class EducationTip {
  final String title;
  final String body;

  const EducationTip({required this.title, required this.body});
}

class EducationTips {
  EducationTips._();

  static const List<EducationTip> all = [
    EducationTip(
      title: 'Risk Per Trade',
      body: 'Many traders cap risk on a single trade to a small percentage '
          'of their account — it keeps one bad trade from doing lasting '
          'damage to your capital.',
    ),
    EducationTip(
      title: 'Plan Before You Enter',
      body: 'Decide your entry, stop-loss, and take-profit levels before '
          'placing a trade — not after. A plan removes emotion from exits.',
    ),
    EducationTip(
      title: 'Cut Losses, Let Winners Run',
      body: 'A common pattern in trading psychology is exiting winners too '
          'early and holding losers too long. Awareness of this bias is the '
          'first step to managing it.',
    ),
    EducationTip(
      title: 'Volume Confirms Price',
      body: 'A price breakout on low volume is often less reliable than one '
          'backed by strong volume — volume can help confirm conviction '
          'behind a move.',
    ),
    EducationTip(
      title: 'Journal Every Trade',
      body: 'Recording why you entered, and why you exited, builds the '
          'pattern-recognition that turns experience into skill over time.',
    ),
  ];

  /// Deterministic "tip of the day" based on the calendar day, so it
  /// stays the same all day but rotates daily without needing a backend.
  static EducationTip tipOfTheDay() {
    final dayOfYear = DateTime.now()
        .difference(DateTime(DateTime.now().year, 1, 1))
        .inDays;
    return all[dayOfYear % all.length];
  }
}
