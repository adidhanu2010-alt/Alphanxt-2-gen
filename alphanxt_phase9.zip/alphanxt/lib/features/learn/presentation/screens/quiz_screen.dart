import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/widgets/primary_button.dart';
import '../../domain/entities/course_entity.dart';
import '../providers/learn_providers.dart';

class QuizScreen extends ConsumerStatefulWidget {
  final CourseEntity course;

  const QuizScreen({super.key, required this.course});

  @override
  ConsumerState<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends ConsumerState<QuizScreen> {
  int _questionIndex = 0;
  int? _selectedOption;
  bool _showExplanation = false;
  final List<bool> _results = [];
  bool _finished = false;

  QuizQuestionEntity get _question => widget.course.quiz[_questionIndex];
  bool get _isLastQuestion => _questionIndex == widget.course.quiz.length - 1;

  void _selectOption(int index) {
    if (_showExplanation) return;
    setState(() {
      _selectedOption = index;
      _showExplanation = true;
      _results.add(index == _question.correctIndex);
    });
  }

  Future<void> _next() async {
    if (_isLastQuestion) {
      final scorePercent =
          ((_results.where((r) => r).length / _results.length) * 100).round();
      final success = await ref.read(learnActionControllerProvider.notifier).submitQuiz(
            courseId: widget.course.id,
            scorePercent: scorePercent,
            xpReward: widget.course.xpReward,
          );
      if (!mounted) return;
      if (success) {
        setState(() => _finished = true);
      }
    } else {
      setState(() {
        _questionIndex++;
        _selectedOption = null;
        _showExplanation = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_finished) {
      return _buildResultScreen(context);
    }

    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.course.title} Quiz'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(AppDimens.space20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              LinearProgressIndicator(
                value: (_questionIndex + 1) / widget.course.quiz.length,
                minHeight: 6,
                borderRadius: BorderRadius.circular(AppDimens.radiusPill),
              ),
              const SizedBox(height: AppDimens.space8),
              Text(
                'Question ${_questionIndex + 1} of ${widget.course.quiz.length}',
                style: theme.textTheme.bodySmall,
              ),
              const SizedBox(height: AppDimens.space20),
              Text(_question.question, style: theme.textTheme.titleMedium),
              const SizedBox(height: AppDimens.space20),
              Expanded(
                child: ListView.builder(
                  itemCount: _question.options.length,
                  itemBuilder: (context, i) => _buildOption(context, i),
                ),
              ),
              if (_showExplanation)
                Padding(
                  padding: const EdgeInsets.only(bottom: AppDimens.space16),
                  child: Container(
                    padding: const EdgeInsets.all(AppDimens.space12),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
                      borderRadius: BorderRadius.circular(AppDimens.radiusMedium),
                    ),
                    child: Text(_question.explanation, style: theme.textTheme.bodySmall),
                  ),
                ),
              PrimaryButton(
                label: _isLastQuestion ? 'Finish Quiz' : 'Next Question',
                onPressed: _showExplanation ? _next : null,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOption(BuildContext context, int i) {
    final theme = Theme.of(context);
    final isSelected = _selectedOption == i;
    final isCorrect = i == _question.correctIndex;

    Color? borderColor;
    Color? bgColor;
    if (_showExplanation) {
      if (isCorrect) {
        borderColor = AppColors.bullish;
        bgColor = AppColors.bullish.withValues(alpha: 0.08);
      } else if (isSelected) {
        borderColor = AppColors.bearish;
        bgColor = AppColors.bearish.withValues(alpha: 0.08);
      }
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: AppDimens.space12),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppDimens.radiusMedium),
        onTap: () => _selectOption(i),
        child: Container(
          padding: const EdgeInsets.all(AppDimens.space16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppDimens.radiusMedium),
            border: Border.all(color: borderColor ?? theme.dividerColor),
            color: bgColor,
          ),
          child: Row(
            children: [
              Expanded(child: Text(_question.options[i], style: theme.textTheme.bodyMedium)),
              if (_showExplanation && isCorrect)
                const Icon(Icons.check_circle_rounded, color: AppColors.bullish, size: 18),
              if (_showExplanation && isSelected && !isCorrect)
                const Icon(Icons.cancel_rounded, color: AppColors.bearish, size: 18),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResultScreen(BuildContext context) {
    final theme = Theme.of(context);
    final correctCount = _results.where((r) => r).length;
    final scorePercent = ((correctCount / _results.length) * 100).round();
    final passed = scorePercent >= 60;

    return Scaffold(
      appBar: AppBar(title: const Text('Quiz Results')),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(AppDimens.space24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  height: 96,
                  width: 96,
                  decoration: BoxDecoration(
                    color: (passed ? AppColors.bullish : AppColors.warning)
                        .withValues(alpha: 0.12),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    passed ? Icons.emoji_events_rounded : Icons.refresh_rounded,
                    color: passed ? AppColors.bullish : AppColors.warning,
                    size: 48,
                  ),
                ),
                const SizedBox(height: AppDimens.space20),
                Text('$scorePercent%', style: theme.textTheme.displayMedium),
                const SizedBox(height: AppDimens.space8),
                Text(
                  '$correctCount of ${_results.length} correct',
                  style: theme.textTheme.bodyMedium,
                ),
                const SizedBox(height: AppDimens.space24),
                Text(
                  passed
                      ? 'Nice work! You\'ve completed this course.'
                      : 'Review the lesson and try again — 60%+ completes the course.',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodyMedium,
                ),
                const SizedBox(height: AppDimens.space32),
                PrimaryButton(
                  label: 'Done',
                  onPressed: () {
                    Navigator.of(context).pop(); // close QuizScreen -> CourseDetailScreen
                    Navigator.of(context).pop(); // close CourseDetailScreen -> LearnScreen
                  },
                ),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Back to Course'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
