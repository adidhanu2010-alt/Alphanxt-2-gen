/// Centralized spacing, radius, and sizing tokens.
///
/// Using a consistent 4pt/8pt spacing scale keeps the UI visually aligned
/// across every screen. Prefer these constants over magic numbers.
class AppDimens {
  AppDimens._();

  // ---------------- Spacing (4pt scale) ----------------
  static const double space4 = 4;
  static const double space8 = 8;
  static const double space12 = 12;
  static const double space16 = 16;
  static const double space20 = 20;
  static const double space24 = 24;
  static const double space32 = 32;
  static const double space40 = 40;
  static const double space48 = 48;
  static const double space64 = 64;

  // ---------------- Radius ----------------
  static const double radiusSmall = 8;
  static const double radiusMedium = 12;
  static const double radiusLarge = 16;
  static const double radiusXLarge = 24;
  static const double radiusPill = 999;

  // ---------------- Elevation ----------------
  static const double elevationNone = 0;
  static const double elevationLow = 2;
  static const double elevationMedium = 6;
  static const double elevationHigh = 12;

  // ---------------- Icon Sizes ----------------
  static const double iconSmall = 16;
  static const double iconMedium = 24;
  static const double iconLarge = 32;

  // ---------------- Component Heights ----------------
  static const double buttonHeight = 52;
  static const double inputHeight = 56;
  static const double bottomNavHeight = 64;
  static const double appBarHeight = 56;

  // ---------------- Glassmorphism ----------------
  static const double glassBlurSigma = 12;
  static const double glassBorderWidth = 1.2;
}
