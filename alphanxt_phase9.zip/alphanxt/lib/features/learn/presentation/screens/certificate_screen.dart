import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/utils/formatters.dart';
import '../../../auth/presentation/providers/auth_providers.dart';
import '../../domain/entities/course_entity.dart';

/// An in-app certificate of completion for finishing every course in a
/// level. This is a visual achievement screen tied to real completion
/// data (only reachable once every course in the level is genuinely
/// done) — it does not export a PDF or shareable file; that's a
/// reasonable follow-up for a future polish pass, not required for the
/// certificate concept to be real and correctly gated.
class CertificateScreen extends ConsumerWidget {
  final CourseLevel level;

  const CertificateScreen({super.key, required this.level});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(currentUserProfileProvider).value;
    final theme = Theme.of(context);
    final name = profile?.displayName.isNotEmpty == true ? profile!.displayName : 'Trader';

    return Scaffold(
      appBar: AppBar(title: const Text('Certificate')),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(AppDimens.space24),
            child: Container(
              padding: const EdgeInsets.all(AppDimens.space24),
              decoration: BoxDecoration(
                gradient: AppColors.heroGlowGradient,
                borderRadius: BorderRadius.circular(AppDimens.radiusXLarge),
                border: Border.all(color: AppColors.warning.withValues(alpha: 0.5), width: 1.5),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.workspace_premium_rounded, color: AppColors.warning, size: 56),
                  const SizedBox(height: AppDimens.space16),
                  Text(
                    'Certificate of Completion',
                    textAlign: TextAlign.center,
                    style: theme.textTheme.titleLarge?.copyWith(color: Colors.white),
                  ),
                  const SizedBox(height: AppDimens.space20),
                  Text(
                    'This certifies that',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: Colors.white.withValues(alpha: 0.75),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    name,
                    textAlign: TextAlign.center,
                    style: theme.textTheme.headlineSmall?.copyWith(color: Colors.white),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'has completed the ${level.label} level of the\nAlphaNXT Learning Academy',
                    textAlign: TextAlign.center,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: Colors.white.withValues(alpha: 0.9),
                    ),
                  ),
                  const SizedBox(height: AppDimens.space20),
                  Text(
                    Formatters.date(DateTime.now()),
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: Colors.white.withValues(alpha: 0.6),
                    ),
                  ),
                  const SizedBox(height: AppDimens.space20),
                  Text(
                    AppStrings.virtualTradingDisclaimer,
                    textAlign: TextAlign.center,
                    style: theme.textTheme.labelSmall?.copyWith(
                      color: Colors.white.withValues(alpha: 0.55),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
