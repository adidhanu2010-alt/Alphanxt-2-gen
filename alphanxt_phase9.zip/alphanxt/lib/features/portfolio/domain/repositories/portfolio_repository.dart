import '../../../../core/errors/result.dart';
import '../entities/portfolio_snapshot_entity.dart';

/// Contract for portfolio analytics persistence — currently just the
/// daily value snapshots that power the Portfolio Value chart and (once
/// enough history exists) an accurate Daily P/L figure. See
/// [PortfolioSnapshotEntity] docs for the client-side recording caveat.
abstract class PortfolioRepository {
  Future<Result<void>> recordDailySnapshotIfNeeded({
    required String uid,
    required double totalValue,
    required double cashBalance,
    required double investedValue,
  });

  Stream<List<PortfolioSnapshotEntity>> watchSnapshots(String uid, {int days});
}
