import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart' show User;

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/routing/route_names.dart';
import '../providers/auth_providers.dart';
import 'onboarding_screen.dart' show onboardingSeenPrefsKey;

/// The app's entry screen — shows branding for a beat, then decides
/// where to send the user based on real auth state:
///   not signed in + never seen onboarding -> Onboarding
///   not signed in + has seen onboarding    -> Login
///   signed in but email not verified       -> Verify Email
///   signed in and verified                 -> Home
class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _decideDestination();
  }

  Future<void> _decideDestination() async {
    // Keep the branded splash on screen for a minimum beat, while the
    // auth-state check and prefs read happen in parallel.
    final delayFuture = Future<void>.delayed(const Duration(milliseconds: 1400));
    final userFuture = ref.read(firebaseAuthProvider).authStateChanges().first;
    final prefsFuture = SharedPreferences.getInstance();

    final User? user;
    final SharedPreferences prefs;
    await delayFuture;
    user = await userFuture;
    prefs = await prefsFuture;

    if (!mounted) return;

    final onboardingSeen = prefs.getBool(onboardingSeenPrefsKey) ?? false;

    if (user == null) {
      context.go(onboardingSeen ? RouteNames.login : RouteNames.onboarding);
    } else if (!user.emailVerified) {
      context.go(RouteNames.verifyEmail);
    } else {
      context.go(RouteNames.home);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.premiumDarkGradient),
        child: SafeArea(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 96,
                  width: 96,
                  decoration: BoxDecoration(
                    gradient: AppColors.primaryGradient,
                    borderRadius: BorderRadius.circular(AppDimens.radiusXLarge),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.primary.withValues(alpha: 0.45),
                        blurRadius: 32,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.candlestick_chart_rounded,
                    color: Colors.white,
                    size: 52,
                  ),
                ).animate().scale(
                      duration: 500.ms,
                      curve: Curves.easeOutBack,
                    ).fadeIn(),
                const SizedBox(height: AppDimens.space24),
                Text(
                  AppStrings.appName,
                  style: Theme.of(context).textTheme.displayMedium?.copyWith(
                        color: Colors.white,
                      ),
                ).animate().fadeIn(delay: 200.ms, duration: 500.ms),
                const SizedBox(height: AppDimens.space8),
                Text(
                  AppStrings.appTagline,
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        color: Colors.white.withValues(alpha: 0.85),
                      ),
                ).animate().fadeIn(delay: 350.ms, duration: 500.ms),
                const SizedBox(height: AppDimens.space64),
                SizedBox(
                  height: 22,
                  width: 22,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.4,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      Colors.white.withValues(alpha: 0.9),
                    ),
                  ),
                ).animate().fadeIn(delay: 500.ms),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: AppDimens.space24,
            vertical: AppDimens.space16,
          ),
          child: Text(
            AppStrings.virtualTradingDisclaimer,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      ),
    );
  }
}
