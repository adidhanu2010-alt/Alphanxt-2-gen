import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/utils/formatters.dart';
import '../../domain/entities/leaderboard_entry_entity.dart';

class LeaderboardTile extends StatelessWidget {
  final int rank;
  final LeaderboardEntryEntity entry;
  final bool isMe;
  final bool showReturns;

  const LeaderboardTile({
    super.key,
    required this.rank,
    required this.entry,
    required this.isMe,
    required this.showReturns,
  });

  Color? _rankColor() {
    switch (rank) {
      case 1:
        return const Color(0xFFFFD700);
      case 2:
        return const Color(0xFFC0C0C0);
      case 3:
        return const Color(0xFFCD7F32);
      default:
        return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final rankColor = _rankColor();
    final isPositive = entry.portfolioReturnPercent >= 0;

    return Container(
      margin: const EdgeInsets.only(bottom: AppDimens.space8),
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimens.space12,
        vertical: AppDimens.space8,
      ),
      decoration: BoxDecoration(
        color: isMe ? AppColors.primary.withValues(alpha: 0.08) : null,
        borderRadius: BorderRadius.circular(AppDimens.radiusMedium),
        border: isMe ? Border.all(color: AppColors.primary.withValues(alpha: 0.3)) : null,
      ),
      child: Row(
        children: [
          SizedBox(
            width: 28,
            child: Text(
              '$rank',
              style: theme.textTheme.titleSmall?.copyWith(color: rankColor),
            ),
          ),
          CircleAvatar(
            radius: 16,
            backgroundColor: theme.colorScheme.primary.withValues(alpha: 0.15),
            backgroundImage: entry.photoUrl != null ? NetworkImage(entry.photoUrl!) : null,
            child: entry.photoUrl == null
                ? Icon(Icons.person_rounded, size: 16, color: theme.colorScheme.primary)
                : null,
          ),
          const SizedBox(width: AppDimens.space12),
          Expanded(
            child: Text(
              isMe ? '${entry.displayName} (You)' : entry.displayName,
              style: theme.textTheme.bodyMedium?.copyWith(
                fontWeight: isMe ? FontWeight.w700 : FontWeight.w500,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Text(
            showReturns
                ? Formatters.percentSigned(entry.portfolioReturnPercent / 100)
                : '${entry.totalXp} XP',
            style: theme.textTheme.titleSmall?.copyWith(
              color: showReturns ? (isPositive ? AppColors.bullish : AppColors.bearish) : null,
            ),
          ),
        ],
      ),
    );
  }
}
