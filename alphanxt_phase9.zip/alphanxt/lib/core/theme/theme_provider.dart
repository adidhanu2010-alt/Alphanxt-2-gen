import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Key used to persist the user's theme choice locally so the app opens
/// in the correct mode before Firestore settings have synced.
const String _themePrefsKey = 'alphanxt_theme_mode';

/// Controls the app's active [ThemeMode] (light / dark) and persists the
/// choice locally via SharedPreferences.
///
/// AlphaNXT's default is Premium Dark Mode — the app does NOT follow the
/// device's system brightness. Light mode is only ever activated via an
/// explicit toggle in Profile > Settings.
///
/// Usage:
/// ```dart
/// final themeMode = ref.watch(themeModeProvider);
/// ref.read(themeModeProvider.notifier).setThemeMode(ThemeMode.light);
/// ```
class ThemeModeNotifier extends StateNotifier<ThemeMode> {
  ThemeModeNotifier() : super(ThemeMode.dark) {
    _loadSavedTheme();
  }

  Future<void> _loadSavedTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_themePrefsKey);
    switch (saved) {
      case 'light':
        state = ThemeMode.light;
      default:
        // Covers 'dark' and the no-preference-saved-yet case — Premium
        // Dark Mode is the default experience.
        state = ThemeMode.dark;
    }
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    state = mode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_themePrefsKey, mode.name);
  }

  Future<void> toggleLightDark() async {
    final next = state == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    await setThemeMode(next);
  }
}

final themeModeProvider =
    StateNotifierProvider<ThemeModeNotifier, ThemeMode>((ref) {
  return ThemeModeNotifier();
});
