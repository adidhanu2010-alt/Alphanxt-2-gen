import 'entities/course_entity.dart';
import 'entities/course_progress_entity.dart';

/// Static badge catalog. Earning logic lives in [BadgeEvaluator], driven
/// entirely by real course-progress data — no badge is ever awarded
/// without the underlying completion actually having happened.
class BadgeCatalog {
  BadgeCatalog._();

  static const List<BadgeDefinitionEntity> all = [
    BadgeDefinitionEntity(
      id: 'first_lesson',
      title: 'First Steps',
      description: 'Complete your first course.',
      iconKey: 'flag',
    ),
    BadgeDefinitionEntity(
      id: 'beginner_graduate',
      title: 'Beginner Graduate',
      description: 'Complete every Beginner course.',
      iconKey: 'school',
    ),
    BadgeDefinitionEntity(
      id: 'intermediate_graduate',
      title: 'Intermediate Graduate',
      description: 'Complete every Intermediate course.',
      iconKey: 'trending_up',
    ),
    BadgeDefinitionEntity(
      id: 'advanced_graduate',
      title: 'Advanced Graduate',
      description: 'Complete every Advanced course.',
      iconKey: 'workspace_premium',
    ),
    BadgeDefinitionEntity(
      id: 'quiz_master',
      title: 'Quiz Master',
      description: 'Score 100% on any course quiz.',
      iconKey: 'quiz',
    ),
    BadgeDefinitionEntity(
      id: 'risk_aware',
      title: 'Risk Aware',
      description: 'Complete the Risk Management course.',
      iconKey: 'shield',
    ),
    BadgeDefinitionEntity(
      id: 'mind_over_market',
      title: 'Mind Over Market',
      description: 'Complete the Trading Psychology course.',
      iconKey: 'psychology',
    ),
    BadgeDefinitionEntity(
      id: 'well_rounded',
      title: 'Well Rounded',
      description: 'Complete 6 or more courses across any levels.',
      iconKey: 'stars',
    ),
  ];

  static BadgeDefinitionEntity? byId(String id) {
    for (final b in all) {
      if (b.id == id) return b;
    }
    return null;
  }
}

class BadgeEvaluator {
  BadgeEvaluator._();

  /// Returns the ids of every badge [progress] currently qualifies for
  /// (regardless of whether it's already been recorded as earned —
  /// callers diff against [LearnRepository.watchEarnedBadges] to decide
  /// what's newly earned).
  static Set<String> qualifiedBadgeIds({
    required List<CourseEntity> allCourses,
    required List<CourseProgressEntity> progress,
  }) {
    final completedIds =
        progress.where((p) => p.isCompleted).map((p) => p.courseId).toSet();

    final earned = <String>{};

    if (completedIds.isNotEmpty) earned.add('first_lesson');

    bool levelComplete(CourseLevel level) {
      final coursesInLevel =
          allCourses.where((c) => c.level == level).map((c) => c.id).toSet();
      return coursesInLevel.isNotEmpty && coursesInLevel.every(completedIds.contains);
    }

    if (levelComplete(CourseLevel.beginner)) earned.add('beginner_graduate');
    if (levelComplete(CourseLevel.intermediate)) earned.add('intermediate_graduate');
    if (levelComplete(CourseLevel.advanced)) earned.add('advanced_graduate');

    if (progress.any((p) => p.bestQuizScorePercent == 100)) {
      earned.add('quiz_master');
    }

    if (completedIds.contains('risk_management')) earned.add('risk_aware');
    if (completedIds.contains('trading_psychology')) earned.add('mind_over_market');
    if (completedIds.length >= 6) earned.add('well_rounded');

    return earned;
  }
}
