import '../../../../core/errors/failures.dart';
import '../../../../core/errors/result.dart';
import '../../../../core/utils/app_logger.dart';
import '../../domain/entities/asset_entity.dart';
import '../../domain/entities/asset_detail_entity.dart';
import '../../domain/entities/candle_entity.dart';
import '../../domain/entities/chart_range.dart';
import '../../domain/repositories/market_repository.dart';
import '../datasources/market_remote_datasource.dart';
import '../datasources/watchlist_remote_datasource.dart';

class MarketRepositoryImpl implements MarketRepository {
  final MarketRemoteDataSource _marketRemote;
  final WatchlistRemoteDataSource _watchlistRemote;

  MarketRepositoryImpl(this._marketRemote, this._watchlistRemote);

  @override
  Future<Result<List<AssetEntity>>> getTrendingAssets({int limit = 50}) async {
    try {
      final assets = await _marketRemote.getTrendingAssets(limit: limit);
      return Result.success(assets);
    } catch (e, st) {
      AppLogger.error('getTrendingAssets failed', e, st);
      return Result.failure(DataFailure(_mapError(e)));
    }
  }

  @override
  Future<Result<List<AssetEntity>>> searchAssets(String query) async {
    try {
      final assets = await _marketRemote.searchAssets(query);
      return Result.success(assets);
    } catch (e, st) {
      AppLogger.error('searchAssets failed', e, st);
      return Result.failure(DataFailure(_mapError(e)));
    }
  }

  @override
  Future<Result<AssetDetailEntity>> getAssetDetails(String assetId) async {
    try {
      final detail = await _marketRemote.getAssetDetails(assetId);
      return Result.success(detail);
    } catch (e, st) {
      AppLogger.error('getAssetDetails failed', e, st);
      return Result.failure(DataFailure(_mapError(e)));
    }
  }

  @override
  Future<Result<List<PricePointEntity>>> getPriceHistory(
    String assetId,
    ChartRange range,
  ) async {
    try {
      final points = await _marketRemote.getPriceHistory(assetId, range.days);
      return Result.success(points);
    } catch (e, st) {
      AppLogger.error('getPriceHistory failed', e, st);
      return Result.failure(DataFailure(_mapError(e)));
    }
  }

  @override
  Future<Result<List<AssetEntity>>> getAssetsByIds(List<String> ids) async {
    try {
      final assets = await _marketRemote.getAssetsByIds(ids);
      return Result.success(assets);
    } catch (e, st) {
      AppLogger.error('getAssetsByIds failed', e, st);
      return Result.failure(DataFailure(_mapError(e)));
    }
  }

  @override
  Stream<List<String>> watchWatchlistIds(String uid) {
    return _watchlistRemote.watchWatchlistIds(uid);
  }

  @override
  Future<Result<void>> addToWatchlist(String uid, AssetEntity asset) async {
    try {
      await _watchlistRemote.addToWatchlist(uid, asset);
      return Result.success(null);
    } catch (e, st) {
      AppLogger.error('addToWatchlist failed', e, st);
      return Result.failure(const DataFailure('Could not add to watchlist.'));
    }
  }

  @override
  Future<Result<void>> removeFromWatchlist(String uid, String assetId) async {
    try {
      await _watchlistRemote.removeFromWatchlist(uid, assetId);
      return Result.success(null);
    } catch (e, st) {
      AppLogger.error('removeFromWatchlist failed', e, st);
      return Result.failure(
        const DataFailure('Could not remove from watchlist.'),
      );
    }
  }

  String _mapError(Object e) {
    final message = e.toString();
    if (message.contains('rate limit')) {
      return 'Market data rate limit reached — please wait a moment and try again.';
    }
    if (message.contains('SocketException') || message.contains('Failed host lookup')) {
      return 'No internet connection.';
    }
    return 'Could not load market data. Please try again.';
  }
}
