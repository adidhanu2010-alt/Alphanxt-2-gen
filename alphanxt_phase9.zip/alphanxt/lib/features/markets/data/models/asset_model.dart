import '../../domain/entities/asset_entity.dart';

/// Data-layer model — parses a CoinGecko `/coins/markets` list item into
/// the domain [AssetEntity]. Only the data layer should construct this.
class AssetModel extends AssetEntity {
  const AssetModel({
    required super.id,
    required super.symbol,
    required super.name,
    super.imageUrl,
    required super.type,
    required super.currentPrice,
    required super.priceChangePercent24h,
    super.marketCap,
    super.totalVolume24h,
    super.high24h,
    super.low24h,
    super.sparkline,
  });

  factory AssetModel.fromCoinGeckoMarket(Map<String, dynamic> json) {
    final sparklineRaw = json['sparkline_in_7d'];
    List<double> sparkline = const [];
    if (sparklineRaw is Map && sparklineRaw['price'] is List) {
      sparkline = (sparklineRaw['price'] as List)
          .map((e) => (e as num).toDouble())
          .toList();
    }

    return AssetModel(
      id: json['id'] as String? ?? '',
      symbol: (json['symbol'] as String? ?? '').toUpperCase(),
      name: json['name'] as String? ?? '',
      imageUrl: json['image'] as String?,
      type: AssetType.crypto,
      currentPrice: (json['current_price'] as num?)?.toDouble() ?? 0,
      priceChangePercent24h:
          (json['price_change_percentage_24h'] as num?)?.toDouble() ?? 0,
      marketCap: (json['market_cap'] as num?)?.toDouble(),
      totalVolume24h: (json['total_volume'] as num?)?.toDouble(),
      high24h: (json['high_24h'] as num?)?.toDouble(),
      low24h: (json['low_24h'] as num?)?.toDouble(),
      sparkline: sparkline,
    );
  }
}
