import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../../../../core/theme/app_chart_theme.dart';

/// Small inline 7-day price trend line, used in asset list tiles.
/// No axes/labels/grid — purely a compact visual trend indicator.
class SparklineChart extends StatelessWidget {
  final List<double> prices;
  final bool isPositive;
  final double height;
  final double width;

  const SparklineChart({
    super.key,
    required this.prices,
    required this.isPositive,
    this.height = 36,
    this.width = 80,
  });

  @override
  Widget build(BuildContext context) {
    if (prices.length < 2) {
      return SizedBox(height: height, width: width);
    }

    final color = isPositive ? AppChartTheme.lineUp : AppChartTheme.lineDown;
    final spots = List.generate(
      prices.length,
      (i) => FlSpot(i.toDouble(), prices[i]),
    );

    return SizedBox(
      height: height,
      width: width,
      child: LineChart(
        LineChartData(
          gridData: const FlGridData(show: false),
          titlesData: const FlTitlesData(show: false),
          borderData: FlBorderData(show: false),
          lineTouchData: const LineTouchData(enabled: false),
          minY: prices.reduce((a, b) => a < b ? a : b),
          maxY: prices.reduce((a, b) => a > b ? a : b),
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: true,
              barWidth: 1.8,
              color: color,
              dotData: const FlDotData(show: false),
              belowBarData: BarAreaData(
                show: true,
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: AppChartTheme.areaGradient(color),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
