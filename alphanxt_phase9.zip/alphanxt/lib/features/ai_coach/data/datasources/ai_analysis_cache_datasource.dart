import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../../core/constants/app_strings.dart';

/// Reads/writes the cached AI analysis on the closing sell transaction
/// doc (in the existing `transactions` collection), under an
/// `aiAnalysis` field. Kept as a raw field access here rather than
/// extending `TransactionModel` (Phase 5), so this feature can't
/// accidentally destabilize the trading engine's schema.
class AiAnalysisCacheDataSource {
  final FirebaseFirestore _firestore;

  AiAnalysisCacheDataSource(this._firestore);

  CollectionReference<Map<String, dynamic>> get _transactionsRef =>
      _firestore.collection(AppStrings.collectionTransactions);

  Future<Map<String, dynamic>?> getCachedAnalysis(String transactionId) async {
    final doc = await _transactionsRef.doc(transactionId).get();
    return doc.data()?['aiAnalysis'] as Map<String, dynamic>?;
  }

  Future<void> saveAnalysis(
    String transactionId,
    Map<String, dynamic> analysisMap,
  ) {
    return _transactionsRef.doc(transactionId).update({
      'aiAnalysis': analysisMap,
    });
  }
}
