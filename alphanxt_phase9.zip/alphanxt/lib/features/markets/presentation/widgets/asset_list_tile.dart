import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/utils/formatters.dart';
import '../../domain/entities/asset_entity.dart';
import 'sparkline_chart.dart';

/// A single asset row — icon, name/symbol, sparkline, price + 24h change.
/// Reused across the Markets list, Watchlist, and Search results.
class AssetListTile extends StatelessWidget {
  final AssetEntity asset;
  final VoidCallback onTap;
  final VoidCallback? onWatchlistTap;
  final bool? isWatchlisted;

  const AssetListTile({
    super.key,
    required this.asset,
    required this.onTap,
    this.onWatchlistTap,
    this.isWatchlisted,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final changeColor =
        asset.isPositive24h ? AppColors.bullish : AppColors.bearish;

    return InkWell(
      borderRadius: BorderRadius.circular(AppDimens.radiusMedium),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          vertical: AppDimens.space12,
          horizontal: AppDimens.space4,
        ),
        child: Row(
          children: [
            ClipOval(
              child: asset.imageUrl != null
                  ? CachedNetworkImage(
                      imageUrl: asset.imageUrl!,
                      height: 36,
                      width: 36,
                      errorWidget: (_, __, ___) => _fallbackIcon(theme),
                    )
                  : _fallbackIcon(theme),
            ),
            const SizedBox(width: AppDimens.space12),
            Expanded(
              flex: 3,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    asset.name,
                    style: theme.textTheme.titleSmall,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(asset.symbol, style: theme.textTheme.bodySmall),
                ],
              ),
            ),
            if (asset.sparkline.length > 1)
              Expanded(
                flex: 2,
                child: SparklineChart(
                  prices: asset.sparkline,
                  isPositive: asset.isPositive24h,
                ),
              ),
            const SizedBox(width: AppDimens.space8),
            Expanded(
              flex: 2,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    Formatters.currency(asset.currentPrice),
                    style: theme.textTheme.titleSmall,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    Formatters.percentSigned(asset.priceChangePercent24h / 100),
                    style: theme.textTheme.bodySmall?.copyWith(color: changeColor),
                  ),
                ],
              ),
            ),
            if (onWatchlistTap != null) ...[
              const SizedBox(width: AppDimens.space4),
              IconButton(
                icon: Icon(
                  isWatchlisted == true
                      ? Icons.bookmark_rounded
                      : Icons.bookmark_border_rounded,
                  color: isWatchlisted == true
                      ? AppColors.primary
                      : theme.textTheme.bodySmall?.color,
                  size: AppDimens.iconSmall,
                ),
                onPressed: onWatchlistTap,
                visualDensity: VisualDensity.compact,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _fallbackIcon(ThemeData theme) {
    return Container(
      height: 36,
      width: 36,
      color: theme.colorScheme.primary.withValues(alpha: 0.12),
      alignment: Alignment.center,
      child: Text(
        asset.symbol.isNotEmpty ? asset.symbol[0] : '?',
        style: TextStyle(
          fontWeight: FontWeight.w700,
          color: theme.colorScheme.primary,
        ),
      ),
    );
  }
}
