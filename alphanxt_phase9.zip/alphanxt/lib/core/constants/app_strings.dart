/// Centralized text constants for AlphaNXT.
///
/// Keeping copy here (rather than scattered as literals) makes future
/// localization and legal-copy review much easier — especially important
/// given this is a trading-education app that must never imply guaranteed
/// profits.
class AppStrings {
  AppStrings._();

  // ---------------- App ----------------
  static const String appName = 'AlphaNXT';
  static const String appTagline = 'Learn to trade. Risk-free.';

  // ---------------- Legal / Safety ----------------
  /// Shown on splash, onboarding, and disclaimers throughout the app.
  /// This copy must NEVER be removed or weakened — AlphaNXT is a paper
  /// trading education app only, not a real-money brokerage.
  static const String virtualTradingDisclaimer =
      'AlphaNXT is a virtual paper trading simulator for education only. '
      'No real money is used, deposited, or withdrawn. Past or simulated '
      'performance does not guarantee future results.';

  static const String noGuaranteeDisclaimer =
      'Trading involves risk. AlphaNXT does not guarantee profits or '
      '"winning strategies." All insights are educational in nature.';

  // ---------------- Onboarding ----------------
  static const String onboardTitle1 = 'Trade Without Risk';
  static const String onboardBody1 =
      'Practice trading with ₹1,00,000 in virtual funds — no real money, '
      'zero financial risk.';

  static const String onboardTitle2 = 'Learn From Every Trade';
  static const String onboardBody2 =
      'Your AI Trading Coach breaks down each trade — entries, exits, risk, '
      'and what you could improve.';

  static const String onboardTitle3 = 'Master the Markets';
  static const String onboardBody3 =
      'Structured lessons, quizzes, and challenges take you from beginner '
      'to confident trader.';

  // ---------------- Auth ----------------
  static const String welcomeBack = 'Welcome back';
  static const String createAccount = 'Create your account';
  static const String loginSubtitle = 'Log in to continue your trading journey';
  static const String registerSubtitle = 'Start learning to trade — risk free';
  static const String forgotPasswordTitle = 'Reset your password';
  static const String forgotPasswordBody =
      "Enter the email associated with your account and we'll send a link "
      'to reset your password.';
  static const String verifyEmailTitle = 'Verify your email';
  static const String verifyEmailBody =
      "We've sent a verification link to your email. Please verify to "
      'continue.';

  // ---------------- Starting Balance ----------------
  static const double startingVirtualBalance = 100000.0; // ₹1,00,000

  // ---------------- Firestore Collections ----------------
  static const String collectionUsers = 'users';
  static const String collectionPortfolio = 'portfolio';
  static const String collectionTransactions = 'transactions';
  static const String collectionWatchlist = 'watchlist';
  static const String collectionCourses = 'courses';
  static const String collectionBadges = 'badges';
  static const String collectionNotifications = 'notifications';
  static const String collectionSettings = 'settings';

  // ---------------- Firestore Collections (added beyond original spec) ----------------
  // These two were added in Phase 9 (Challenges & Leaderboard) — the
  // original collection list didn't anticipate needing per-period claim
  // tracking or a denormalized public leaderboard. Both follow the same
  // uid-scoped document pattern as the collections above.
  static const String collectionChallenges = 'challenges';
  static const String collectionLeaderboard = 'leaderboard';
}
