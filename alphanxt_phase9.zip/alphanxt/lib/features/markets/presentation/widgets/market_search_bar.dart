import 'package:flutter/material.dart';
import '../../../../core/constants/app_dimens.dart';

/// Search input for the Markets screen — debouncing itself is handled by
/// [searchResultsProvider], this widget just forwards text changes.
class MarketSearchBar extends StatelessWidget {
  final TextEditingController controller;
  final ValueChanged<String> onChanged;
  final VoidCallback onClear;

  const MarketSearchBar({
    super.key,
    required this.controller,
    required this.onChanged,
    required this.onClear,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      onChanged: onChanged,
      textInputAction: TextInputAction.search,
      decoration: InputDecoration(
        hintText: 'Search coins (e.g. Bitcoin, ETH)',
        prefixIcon: const Icon(Icons.search_rounded, size: AppDimens.iconSmall),
        suffixIcon: controller.text.isNotEmpty
            ? IconButton(
                icon: const Icon(Icons.close_rounded, size: AppDimens.iconSmall),
                onPressed: () {
                  controller.clear();
                  onClear();
                },
              )
            : null,
      ),
    );
  }
}
