import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_dimens.dart';
import '../../../auth/presentation/providers/auth_providers.dart';
import '../providers/challenges_providers.dart';
import '../widgets/leaderboard_tile.dart';

class LeaderboardScreen extends ConsumerStatefulWidget {
  const LeaderboardScreen({super.key});

  @override
  ConsumerState<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends ConsumerState<LeaderboardScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Publishes my own current stats so my entry stays fresh.
    ref.watch(leaderboardSyncProvider);
    final myUid = ref.watch(authRepositoryProvider).currentUid;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Leaderboard'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [Tab(text: 'XP'), Tab(text: 'Returns')],
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: AppDimens.space8),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: AppDimens.space8),
                child: Text(
                  'Visible to other AlphaNXT users — see Profile settings to manage.',
                  style: Theme.of(context).textTheme.bodySmall,
                  textAlign: TextAlign.center,
                ),
              ),
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _buildList(ref.watch(leaderboardByXpProvider), myUid, false),
                    _buildList(ref.watch(leaderboardByReturnsProvider), myUid, true),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildList(AsyncValue entriesAsync, String? myUid, bool showReturns) {
    return entriesAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(
        child: Text('Could not load the leaderboard.', style: Theme.of(context).textTheme.bodyMedium),
      ),
      data: (entries) {
        if (entries.isEmpty) {
          return Center(
            child: Text(
              'No leaderboard data yet — be the first!',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.symmetric(vertical: AppDimens.space8),
          itemCount: entries.length,
          itemBuilder: (context, i) => LeaderboardTile(
            rank: i + 1,
            entry: entries[i],
            isMe: entries[i].uid == myUid,
            showReturns: showReturns,
          ),
        );
      },
    );
  }
}
