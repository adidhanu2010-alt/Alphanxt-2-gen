import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/result.dart';
import '../../../auth/presentation/providers/auth_providers.dart';
import '../../data/datasources/market_remote_datasource.dart';
import '../../data/datasources/watchlist_remote_datasource.dart';
import '../../data/repositories/market_repository_impl.dart';
import '../../domain/entities/asset_entity.dart';
import '../../domain/entities/asset_detail_entity.dart';
import '../../domain/entities/candle_entity.dart';
import '../../domain/entities/chart_range.dart';
import '../../domain/repositories/market_repository.dart';

// ---------------- Data / Repository ----------------

final marketRemoteDataSourceProvider = Provider<MarketRemoteDataSource>((ref) {
  final ds = MarketRemoteDataSource();
  ref.onDispose(() {}); // http.Client left open intentionally (app-lifetime singleton)
  return ds;
});

final watchlistRemoteDataSourceProvider =
    Provider<WatchlistRemoteDataSource>((ref) {
  return WatchlistRemoteDataSource(ref.watch(firestoreProvider));
});

final marketRepositoryProvider = Provider<MarketRepository>((ref) {
  return MarketRepositoryImpl(
    ref.watch(marketRemoteDataSourceProvider),
    ref.watch(watchlistRemoteDataSourceProvider),
  );
});

// ---------------- Trending / list ----------------

final trendingAssetsProvider = FutureProvider.autoDispose<List<AssetEntity>>((ref) async {
  final result = await ref.watch(marketRepositoryProvider).getTrendingAssets();
  return result.when(success: (assets) => assets, failure: (f) => throw f);
});

// ---------------- Search ----------------

final searchQueryProvider = StateProvider.autoDispose<String>((ref) => '');

/// Debounces the search query by 400ms before hitting the network, so
/// typing quickly doesn't fire a request per keystroke.
final searchResultsProvider =
    FutureProvider.autoDispose<List<AssetEntity>>((ref) async {
  final query = ref.watch(searchQueryProvider);
  if (query.trim().isEmpty) return [];

  final completer = Completer<void>();
  final timer = Timer(const Duration(milliseconds: 400), () {
    if (!completer.isCompleted) completer.complete();
  });
  ref.onDispose(() => timer.cancel());
  await completer.future;

  final result = await ref.read(marketRepositoryProvider).searchAssets(query);
  return result.when(success: (assets) => assets, failure: (f) => throw f);
});

// ---------------- Asset detail + price history ----------------

final assetDetailProvider =
    FutureProvider.autoDispose.family<AssetDetailEntity, String>((ref, assetId) async {
  final result =
      await ref.watch(marketRepositoryProvider).getAssetDetails(assetId);
  return result.when(success: (a) => a, failure: (f) => throw f);
});

final chartRangeProvider = StateProvider.autoDispose<ChartRange>(
  (ref) => ChartRange.oneMonth,
);

final priceHistoryProvider = FutureProvider.autoDispose
    .family<List<PricePointEntity>, String>((ref, assetId) async {
  final range = ref.watch(chartRangeProvider);
  final result = await ref
      .watch(marketRepositoryProvider)
      .getPriceHistory(assetId, range);
  return result.when(success: (points) => points, failure: (f) => throw f);
});

// ---------------- Watchlist ----------------

final watchlistIdsProvider = StreamProvider.autoDispose<List<String>>((ref) {
  final uid = ref.watch(authRepositoryProvider).currentUid;
  if (uid == null) return Stream.value(const []);
  return ref.watch(marketRepositoryProvider).watchWatchlistIds(uid);
});

final watchlistAssetsProvider =
    FutureProvider.autoDispose<List<AssetEntity>>((ref) async {
  final ids = await ref.watch(watchlistIdsProvider.future);
  if (ids.isEmpty) return [];
  final result = await ref.watch(marketRepositoryProvider).getAssetsByIds(ids);
  return result.when(success: (assets) => assets, failure: (f) => throw f);
});

/// Drives the watchlist add/remove toggle button on asset tiles/detail.
class WatchlistController extends StateNotifier<AsyncValue<void>> {
  final MarketRepository _repository;
  final String? _uid;

  WatchlistController(this._repository, this._uid)
      : super(const AsyncValue.data(null));

  Future<void> toggle(AssetEntity asset, bool currentlyWatchlisted) async {
    final uid = _uid;
    if (uid == null) return;
    state = const AsyncValue.loading();
    final Result<void> result = currentlyWatchlisted
        ? await _repository.removeFromWatchlist(uid, asset.id)
        : await _repository.addToWatchlist(uid, asset);
    result.when(
      success: (_) => state = const AsyncValue.data(null),
      failure: (f) => state = AsyncValue.error(f.message, StackTrace.current),
    );
  }
}

final watchlistControllerProvider =
    StateNotifierProvider.autoDispose<WatchlistController, AsyncValue<void>>(
        (ref) {
  return WatchlistController(
    ref.watch(marketRepositoryProvider),
    ref.watch(authRepositoryProvider).currentUid,
  );
});
