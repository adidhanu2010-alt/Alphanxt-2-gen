import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/utils/formatters.dart';
import '../../domain/entities/order_enums.dart';
import '../../domain/entities/transaction_entity.dart';

/// Card for a pending limit order — shows the trigger price and lets the
/// user cancel it before it fills.
class PendingOrderCard extends StatelessWidget {
  final TransactionEntity order;
  final VoidCallback onCancel;

  const PendingOrderCard({super.key, required this.order, required this.onCancel});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isBuy = order.side == OrderSide.buy;
    final sideColor = isBuy ? AppColors.bullish : AppColors.bearish;

    return Card(
      margin: const EdgeInsets.only(bottom: AppDimens.space12),
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: sideColor.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(AppDimens.radiusSmall),
              ),
              child: Text(
                isBuy ? 'BUY' : 'SELL',
                style: theme.textTheme.labelSmall
                    ?.copyWith(color: sideColor, fontWeight: FontWeight.w700),
              ),
            ),
            const SizedBox(width: AppDimens.space12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(order.name, style: theme.textTheme.titleSmall),
                  Text(
                    'Limit @ ${Formatters.currency(order.requestedPrice ?? 0)} · '
                    '${order.quantity.toStringAsFixed(6)} ${order.symbol}',
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            IconButton(
              icon: const Icon(Icons.close_rounded, size: AppDimens.iconSmall),
              onPressed: onCancel,
              tooltip: 'Cancel order',
            ),
          ],
        ),
      ),
    );
  }
}
