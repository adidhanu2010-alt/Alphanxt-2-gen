import 'package:equatable/equatable.dart';

/// A user's real progress through one course — lesson read, best quiz
/// score, and the XP actually credited for it.
class CourseProgressEntity extends Equatable {
  final String courseId;
  final bool lessonRead;
  final int? bestQuizScorePercent;
  final int xpEarned;
  final DateTime? completedAt;

  const CourseProgressEntity({
    required this.courseId,
    required this.lessonRead,
    this.bestQuizScorePercent,
    this.xpEarned = 0,
    this.completedAt,
  });

  bool get isCompleted => lessonRead && bestQuizScorePercent != null;

  @override
  List<Object?> get props =>
      [courseId, lessonRead, bestQuizScorePercent, xpEarned, completedAt];
}

/// Static definition of an earnable badge — the earning *logic* lives in
/// [BadgeEvaluator], not here; this is just the display info.
class BadgeDefinitionEntity extends Equatable {
  final String id;
  final String title;
  final String description;
  final String iconKey;

  const BadgeDefinitionEntity({
    required this.id,
    required this.title,
    required this.description,
    required this.iconKey,
  });

  @override
  List<Object?> get props => [id, title, description, iconKey];
}

/// Record of a badge a user has actually earned (real completion data),
/// stored in Firestore once awarded.
class EarnedBadgeEntity extends Equatable {
  final String badgeId;
  final DateTime earnedAt;

  const EarnedBadgeEntity({required this.badgeId, required this.earnedAt});

  @override
  List<Object?> get props => [badgeId, earnedAt];
}
