import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/utils/formatters.dart';

/// Daily profit/loss summary card.
///
/// Genuinely shows ₹0.00 / 0.00% for accounts with no trades yet — this
/// is correct, real data, not a placeholder. Once Paper Trading (Phase 5)
/// and Portfolio (Phase 6) exist, this widget starts receiving live P/L
/// instead of the zero default.
class DailyPnlCard extends StatelessWidget {
  final double dailyPnl;
  final double dailyPnlPercent;

  const DailyPnlCard({
    super.key,
    this.dailyPnl = 0.0,
    this.dailyPnlPercent = 0.0,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isPositive = dailyPnl >= 0;
    final color = dailyPnl == 0
        ? theme.textTheme.bodyMedium?.color
        : (isPositive ? AppColors.bullish : AppColors.bearish);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.today_rounded,
                  size: AppDimens.iconSmall,
                  color: theme.textTheme.bodySmall?.color,
                ),
                const SizedBox(width: AppDimens.space8),
                Text("Today's P/L", style: theme.textTheme.labelMedium),
              ],
            ),
            const SizedBox(height: AppDimens.space12),
            Text(
              '${isPositive ? '+' : ''}${Formatters.currency(dailyPnl)}',
              style: theme.textTheme.titleLarge?.copyWith(color: color),
            ),
            const SizedBox(height: 2),
            Text(
              Formatters.percentSigned(dailyPnlPercent),
              style: theme.textTheme.bodySmall?.copyWith(color: color),
            ),
          ],
        ),
      ),
    );
  }
}
