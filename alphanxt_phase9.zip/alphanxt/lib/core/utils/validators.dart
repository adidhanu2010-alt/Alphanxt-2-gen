/// Shared form-field validators.
///
/// Every validator returns `null` when the input is valid, or a
/// user-facing error string when it isn't — matching the signature
/// TextFormField.validator expects directly.
class Validators {
  Validators._();

  static final RegExp _emailRegex =
      RegExp(r'^[\w\.\-]+@([\w\-]+\.)+[\w\-]{2,4}$');

  static String? email(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Email is required';
    }
    if (!_emailRegex.hasMatch(value.trim())) {
      return 'Enter a valid email address';
    }
    return null;
  }

  static String? password(String? value) {
    if (value == null || value.isEmpty) {
      return 'Password is required';
    }
    if (value.length < 8) {
      return 'Password must be at least 8 characters';
    }
    if (!RegExp(r'[A-Z]').hasMatch(value)) {
      return 'Include at least one uppercase letter';
    }
    if (!RegExp(r'[0-9]').hasMatch(value)) {
      return 'Include at least one number';
    }
    return null;
  }

  static String? confirmPassword(String? value, String original) {
    if (value == null || value.isEmpty) {
      return 'Please confirm your password';
    }
    if (value != original) {
      return 'Passwords do not match';
    }
    return null;
  }

  static String? fullName(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Name is required';
    }
    if (value.trim().length < 2) {
      return 'Name is too short';
    }
    return null;
  }

  static String? required(String? value, {String field = 'This field'}) {
    if (value == null || value.trim().isEmpty) {
      return '$field is required';
    }
    return null;
  }

  /// Validates a trade quantity input (must be a positive integer).
  static String? tradeQuantity(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Enter a quantity';
    }
    final qty = int.tryParse(value.trim());
    if (qty == null || qty <= 0) {
      return 'Enter a valid quantity';
    }
    return null;
  }

  /// Validates a price input (limit/stop-loss/take-profit) — must be a
  /// positive number.
  static String? price(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Enter a price';
    }
    final price = double.tryParse(value.trim());
    if (price == null || price <= 0) {
      return 'Enter a valid price';
    }
    return null;
  }
}
