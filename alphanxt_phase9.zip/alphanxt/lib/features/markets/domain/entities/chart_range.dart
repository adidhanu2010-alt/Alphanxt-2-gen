/// Time ranges available on the Asset Detail price chart.
enum ChartRange {
  oneDay('1D', 1),
  oneWeek('1W', 7),
  oneMonth('1M', 30),
  threeMonths('3M', 90),
  oneYear('1Y', 365);

  final String label;
  final int days;

  const ChartRange(this.label, this.days);
}
