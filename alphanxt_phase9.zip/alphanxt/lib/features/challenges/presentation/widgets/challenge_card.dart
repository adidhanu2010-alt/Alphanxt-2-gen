import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../domain/entities/challenge_entity.dart';
import 'challenge_icons.dart';

class ChallengeCard extends StatelessWidget {
  final ChallengeProgressEntity progress;
  final bool isClaimed;
  final bool isClaiming;
  final VoidCallback onClaim;

  const ChallengeCard({
    super.key,
    required this.progress,
    required this.isClaimed,
    required this.isClaiming,
    required this.onClaim,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final def = progress.definition;
    final canClaim = progress.isCompleted && !isClaimed;

    return Card(
      margin: const EdgeInsets.only(bottom: AppDimens.space12),
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Row(
          children: [
            Container(
              height: 44,
              width: 44,
              decoration: BoxDecoration(
                color: (isClaimed ? AppColors.bullish : AppColors.primary)
                    .withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(AppDimens.radiusMedium),
              ),
              child: Icon(
                isClaimed ? Icons.check_rounded : challengeIconFor(def.iconKey),
                color: isClaimed ? AppColors.bullish : AppColors.primary,
              ),
            ),
            const SizedBox(width: AppDimens.space12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(def.title, style: theme.textTheme.titleSmall),
                  Text(def.description, style: theme.textTheme.bodySmall),
                  const SizedBox(height: AppDimens.space8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(AppDimens.radiusPill),
                    child: LinearProgressIndicator(
                      value: progress.progressFraction,
                      minHeight: 6,
                      backgroundColor: theme.dividerColor.withValues(alpha: 0.3),
                      valueColor: AlwaysStoppedAnimation<Color>(
                        isClaimed ? AppColors.bullish : AppColors.primary,
                      ),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${progress.currentCount}/${def.targetCount} · +${def.xpReward} XP',
                    style: theme.textTheme.labelSmall,
                  ),
                ],
              ),
            ),
            const SizedBox(width: AppDimens.space8),
            if (canClaim)
              FilledButton(
                onPressed: isClaiming ? null : onClaim,
                style: FilledButton.styleFrom(
                  minimumSize: const Size(0, 34),
                  padding: const EdgeInsets.symmetric(horizontal: AppDimens.space12),
                ),
                child: isClaiming
                    ? const SizedBox(
                        height: 14,
                        width: 14,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                    : const Text('Claim'),
              )
            else if (isClaimed)
              const Icon(Icons.check_circle_rounded, color: AppColors.bullish),
          ],
        ),
      ),
    );
  }
}
