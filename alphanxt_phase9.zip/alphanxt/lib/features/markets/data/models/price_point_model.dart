import '../../domain/entities/candle_entity.dart';

/// Parses a single `[timestampMs, price]` pair from CoinGecko's
/// `/coins/{id}/market_chart` response into a domain [PricePointEntity].
class PricePointModel extends PricePointEntity {
  const PricePointModel({required super.timestamp, required super.price});

  factory PricePointModel.fromCoinGeckoPair(List<dynamic> pair) {
    final timestampMs = (pair[0] as num).toInt();
    final price = (pair[1] as num).toDouble();
    return PricePointModel(
      timestamp: DateTime.fromMillisecondsSinceEpoch(timestampMs),
      price: price,
    );
  }
}
