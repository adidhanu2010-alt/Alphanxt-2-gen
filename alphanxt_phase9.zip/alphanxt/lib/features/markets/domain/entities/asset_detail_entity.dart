import 'asset_entity.dart';

/// Extended asset info shown on the Asset Detail screen — adds the
/// "company/coin information" fields that the list/watchlist tiles don't
/// need (description, all-time-high, circulating supply, homepage).
class AssetDetailEntity extends AssetEntity {
  final String? description;
  final double? athPrice;
  final double? athChangePercent;
  final double? circulatingSupply;
  final String? homepageUrl;

  const AssetDetailEntity({
    required super.id,
    required super.symbol,
    required super.name,
    super.imageUrl,
    required super.type,
    required super.currentPrice,
    required super.priceChangePercent24h,
    super.marketCap,
    super.totalVolume24h,
    super.high24h,
    super.low24h,
    super.sparkline,
    this.description,
    this.athPrice,
    this.athChangePercent,
    this.circulatingSupply,
    this.homepageUrl,
  });

  @override
  List<Object?> get props => [
        ...super.props,
        description,
        athPrice,
        athChangePercent,
        circulatingSupply,
        homepageUrl,
      ];
}
