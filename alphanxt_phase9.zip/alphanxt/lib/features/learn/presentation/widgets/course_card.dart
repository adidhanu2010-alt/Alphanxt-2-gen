import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../domain/entities/course_entity.dart';
import 'learn_icons.dart';

class CourseCard extends StatelessWidget {
  final CourseEntity course;
  final bool isCompleted;
  final int? bestQuizScore;
  final VoidCallback onTap;

  const CourseCard({
    super.key,
    required this.course,
    required this.isCompleted,
    required this.bestQuizScore,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      margin: const EdgeInsets.only(bottom: AppDimens.space12),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppDimens.radiusXLarge),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(AppDimens.space16),
          child: Row(
            children: [
              Container(
                height: 48,
                width: 48,
                decoration: BoxDecoration(
                  color: (isCompleted ? AppColors.bullish : AppColors.primary)
                      .withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(AppDimens.radiusMedium),
                ),
                child: Icon(
                  learnIconFor(course.iconKey),
                  color: isCompleted ? AppColors.bullish : AppColors.primary,
                ),
              ),
              const SizedBox(width: AppDimens.space12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(course.title, style: theme.textTheme.titleSmall),
                    const SizedBox(height: 2),
                    Text(
                      course.description,
                      style: theme.textTheme.bodySmall,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(Icons.schedule_rounded,
                            size: 12, color: theme.textTheme.bodySmall?.color),
                        const SizedBox(width: 4),
                        Text('${course.estimatedMinutes} min',
                            style: theme.textTheme.labelSmall),
                        const SizedBox(width: AppDimens.space12),
                        Icon(Icons.bolt_rounded, size: 12, color: AppColors.warning),
                        const SizedBox(width: 4),
                        Text('${course.xpReward} XP', style: theme.textTheme.labelSmall),
                        if (bestQuizScore != null) ...[
                          const SizedBox(width: AppDimens.space12),
                          Icon(Icons.check_circle_rounded, size: 12, color: AppColors.bullish),
                          const SizedBox(width: 4),
                          Text('$bestQuizScore%', style: theme.textTheme.labelSmall),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: theme.textTheme.bodySmall?.color),
            ],
          ),
        ),
      ),
    );
  }
}
