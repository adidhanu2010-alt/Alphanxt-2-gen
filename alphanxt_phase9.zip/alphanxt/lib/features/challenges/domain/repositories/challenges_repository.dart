import '../../../../core/errors/result.dart';
import '../entities/challenge_entity.dart';

/// Handles the one piece of challenge state that genuinely needs
/// persistence: which challenge+period combos have already had their XP
/// claimed. Progress itself is always computed live — see
/// [ChallengeEvaluator].
abstract class ChallengesRepository {
  Stream<List<ClaimedChallengeEntity>> watchClaimedChallenges(String uid);

  Future<Result<void>> claimChallenge({
    required String uid,
    required String challengeId,
    required String periodKey,
  });
}
