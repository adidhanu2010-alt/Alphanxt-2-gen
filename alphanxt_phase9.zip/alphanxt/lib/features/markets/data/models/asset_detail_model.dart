import '../../domain/entities/asset_detail_entity.dart';
import '../../domain/entities/asset_entity.dart';

/// Parses CoinGecko's `/coins/{id}` full detail response into the
/// domain [AssetDetailEntity].
class AssetDetailModel extends AssetDetailEntity {
  const AssetDetailModel({
    required super.id,
    required super.symbol,
    required super.name,
    super.imageUrl,
    required super.type,
    required super.currentPrice,
    required super.priceChangePercent24h,
    super.marketCap,
    super.totalVolume24h,
    super.high24h,
    super.low24h,
    super.sparkline,
    super.description,
    super.athPrice,
    super.athChangePercent,
    super.circulatingSupply,
    super.homepageUrl,
  });

  factory AssetDetailModel.fromCoinGeckoDetail(
    Map<String, dynamic> json, {
    String vsCurrency = 'inr',
  }) {
    final marketData = json['market_data'] as Map<String, dynamic>? ?? {};

    double? _fromCurrencyMap(dynamic map) {
      if (map is Map && map[vsCurrency] != null) {
        return (map[vsCurrency] as num).toDouble();
      }
      return null;
    }

    final links = json['links'] as Map<String, dynamic>?;
    final homepageList = links?['homepage'] as List?;
    final homepage = (homepageList != null && homepageList.isNotEmpty)
        ? homepageList.first as String?
        : null;

    final descriptionMap = json['description'] as Map<String, dynamic>?;
    final description = descriptionMap?['en'] as String?;

    final image = json['image'] as Map<String, dynamic>?;

    return AssetDetailModel(
      id: json['id'] as String? ?? '',
      symbol: (json['symbol'] as String? ?? '').toUpperCase(),
      name: json['name'] as String? ?? '',
      imageUrl: image?['large'] as String? ?? image?['small'] as String?,
      type: AssetType.crypto,
      currentPrice: _fromCurrencyMap(marketData['current_price']) ?? 0,
      priceChangePercent24h:
          (marketData['price_change_percentage_24h'] as num?)?.toDouble() ?? 0,
      marketCap: _fromCurrencyMap(marketData['market_cap']),
      totalVolume24h: _fromCurrencyMap(marketData['total_volume']),
      high24h: _fromCurrencyMap(marketData['high_24h']),
      low24h: _fromCurrencyMap(marketData['low_24h']),
      description: (description != null && description.isNotEmpty)
          ? description
          : null,
      athPrice: _fromCurrencyMap(marketData['ath']),
      athChangePercent: _fromCurrencyMap(marketData['ath_change_percentage']),
      circulatingSupply: (marketData['circulating_supply'] as num?)?.toDouble(),
      homepageUrl: (homepage != null && homepage.isNotEmpty) ? homepage : null,
    );
  }
}
