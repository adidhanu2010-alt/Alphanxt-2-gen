import 'package:flutter/material.dart';
import '../constants/app_dimens.dart';

/// Temporary stand-in for screens/features not yet built in the current
/// development phase (see project README for the phase roadmap).
///
/// This exists ONLY so the router compiles and is navigable end-to-end
/// while later phases are pending — it is replaced feature-by-feature as
/// each phase lands, never left as the final implementation.
class ComingSoonScreen extends StatelessWidget {
  final String featureName;

  const ComingSoonScreen({super.key, required this.featureName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(featureName)),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(AppDimens.space24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.construction_rounded,
                size: 48,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(height: AppDimens.space16),
              Text(
                '$featureName is coming in a future phase',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleMedium,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
