import '../../learn/domain/entities/course_progress_entity.dart';
import '../../paper_trade/domain/entities/order_enums.dart';
import '../../paper_trade/domain/entities/transaction_entity.dart';
import 'entities/challenge_entity.dart';

/// Computes the current period's start/end window and a stable
/// `periodKey` string for a given [ChallengePeriod], anchored to "now".
class ChallengePeriodWindow {
  final DateTime start;
  final DateTime end;
  final String key;

  const ChallengePeriodWindow({required this.start, required this.end, required this.key});

  static ChallengePeriodWindow forPeriod(ChallengePeriod period, DateTime now) {
    switch (period) {
      case ChallengePeriod.daily:
        final start = DateTime(now.year, now.month, now.day);
        final end = start.add(const Duration(days: 1));
        final key = '${now.year.toString().padLeft(4, '0')}-'
            '${now.month.toString().padLeft(2, '0')}-'
            '${now.day.toString().padLeft(2, '0')}';
        return ChallengePeriodWindow(start: start, end: end, key: 'd_$key');

      case ChallengePeriod.weekly:
        final weekday = now.weekday; // 1 = Monday
        final start = DateTime(now.year, now.month, now.day)
            .subtract(Duration(days: weekday - 1));
        final end = start.add(const Duration(days: 7));
        // ISO-ish week key: yearweekstart date is enough to be stable/unique.
        final key = '${start.year}-${start.month.toString().padLeft(2, '0')}-'
            '${start.day.toString().padLeft(2, '0')}';
        return ChallengePeriodWindow(start: start, end: end, key: 'w_$key');

      case ChallengePeriod.monthly:
        final start = DateTime(now.year, now.month, 1);
        final end = DateTime(now.year, now.month + 1, 1);
        final key = '${now.year}-${now.month.toString().padLeft(2, '0')}';
        return ChallengePeriodWindow(start: start, end: end, key: 'm_$key');
    }
  }
}

class ChallengeEvaluator {
  ChallengeEvaluator._();

  /// Computes live progress for every challenge in [definitions] against
  /// real transaction/course-progress data, using "now" to determine
  /// each challenge's current period window.
  static List<ChallengeProgressEntity> evaluateAll({
    required List<ChallengeDefinitionEntity> definitions,
    required List<TransactionEntity> transactions,
    required List<CourseProgressEntity> courseProgress,
    required DateTime now,
  }) {
    return definitions.map((def) {
      final window = ChallengePeriodWindow.forPeriod(def.period, now);
      final count = _countForMetric(
        metric: def.metric,
        transactions: transactions,
        courseProgress: courseProgress,
        window: window,
      );
      return ChallengeProgressEntity(
        definition: def,
        currentCount: count,
        periodKey: window.key,
      );
    }).toList();
  }

  static int _countForMetric({
    required ChallengeMetric metric,
    required List<TransactionEntity> transactions,
    required List<CourseProgressEntity> courseProgress,
    required ChallengePeriodWindow window,
  }) {
    bool inWindow(DateTime d) => !d.isBefore(window.start) && d.isBefore(window.end);

    switch (metric) {
      case ChallengeMetric.tradesPlaced:
        return transactions
            .where((t) =>
                t.status == TransactionStatus.filled &&
                inWindow(t.filledAt ?? t.createdAt))
            .length;

      case ChallengeMetric.profitableTradesClosed:
        return transactions
            .where((t) =>
                t.status == TransactionStatus.filled &&
                t.side == OrderSide.sell &&
                (t.realizedPnl ?? 0) > 0 &&
                inWindow(t.filledAt ?? t.createdAt))
            .length;

      case ChallengeMetric.coursesCompleted:
        return courseProgress
            .where((p) => p.isCompleted && p.completedAt != null && inWindow(p.completedAt!))
            .length;
    }
  }
}
