import '../../domain/entities/course_entity.dart';
import 'advanced_courses.dart';
import 'beginner_courses.dart';
import 'intermediate_courses.dart';

/// The complete, static AlphaNXT course catalog — all 12 topics across
/// Beginner, Intermediate, and Advanced levels.
class CourseCatalog {
  CourseCatalog._();

  static final List<CourseEntity> all = [
    ...BeginnerCourses.all,
    ...IntermediateCourses.all,
    ...AdvancedCourses.all,
  ];

  static CourseEntity? byId(String id) {
    for (final c in all) {
      if (c.id == id) return c;
    }
    return null;
  }

  static List<CourseEntity> byLevel(CourseLevel level) =>
      all.where((c) => c.level == level).toList();
}
