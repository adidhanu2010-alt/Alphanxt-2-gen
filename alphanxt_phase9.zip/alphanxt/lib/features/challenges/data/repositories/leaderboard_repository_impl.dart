import '../../../../core/errors/failures.dart';
import '../../../../core/errors/result.dart';
import '../../../../core/utils/app_logger.dart';
import '../../domain/entities/leaderboard_entry_entity.dart';
import '../../domain/repositories/leaderboard_repository.dart';
import '../datasources/leaderboard_remote_datasource.dart';

class LeaderboardRepositoryImpl implements LeaderboardRepository {
  final LeaderboardRemoteDataSource _remote;

  LeaderboardRepositoryImpl(this._remote);

  @override
  Future<Result<void>> updateMyEntry({
    required String uid,
    required String displayName,
    String? photoUrl,
    required int totalXp,
    required double portfolioReturnPercent,
  }) async {
    try {
      await _remote.updateMyEntry(
        uid: uid,
        displayName: displayName,
        photoUrl: photoUrl,
        totalXp: totalXp,
        portfolioReturnPercent: portfolioReturnPercent,
      );
      return Result.success(null);
    } catch (e, st) {
      AppLogger.error('updateMyEntry failed', e, st);
      return Result.failure(const DataFailure('Could not update leaderboard entry.'));
    }
  }

  @override
  Stream<List<LeaderboardEntryEntity>> watchTopByXp({int limit = 50}) {
    return _remote.watchTopByXp(limit: limit);
  }

  @override
  Stream<List<LeaderboardEntryEntity>> watchTopByReturns({int limit = 50}) {
    return _remote.watchTopByReturns(limit: limit);
  }
}
