/// Buy or sell side of an order.
enum OrderSide { buy, sell }

/// Market orders fill immediately at the current price. Limit orders sit
/// pending until the market reaches the requested price — see
/// [TradingRepository.checkPendingTriggers] docs for how filling works
/// in this client-only architecture.
enum OrderType { market, limit }

/// Lifecycle status of a transaction/order record.
enum TransactionStatus { pending, filled, cancelled }

/// Lifecycle status of a position.
enum PositionStatus { open, closed }

extension OrderSideX on OrderSide {
  String get label => this == OrderSide.buy ? 'Buy' : 'Sell';
}

extension OrderTypeX on OrderType {
  String get label => this == OrderType.market ? 'Market' : 'Limit';
}
