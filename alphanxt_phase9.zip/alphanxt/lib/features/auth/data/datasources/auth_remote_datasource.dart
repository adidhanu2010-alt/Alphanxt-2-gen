import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb;
import 'package:google_sign_in/google_sign_in.dart';

import '../../../../core/constants/app_strings.dart';
import '../models/app_user_model.dart';

/// Raw Firebase Auth + Firestore calls for the auth feature.
///
/// This is the only place in the app that talks to `firebase_auth`,
/// `cloud_firestore` (for the `users` collection), and `google_sign_in`
/// directly. `AuthRepositoryImpl` wraps this in try/catch and converts
/// results/exceptions into the app's `Result<T>` type.
class AuthRemoteDataSource {
  final fb.FirebaseAuth _auth;
  final FirebaseFirestore _firestore;
  final GoogleSignIn _googleSignIn;

  AuthRemoteDataSource({
    required fb.FirebaseAuth auth,
    required FirebaseFirestore firestore,
    required GoogleSignIn googleSignIn,
  })  : _auth = auth,
        _firestore = firestore,
        _googleSignIn = googleSignIn;

  fb.User? get currentFirebaseUser => _auth.currentUser;

  Stream<fb.User?> authStateChanges() => _auth.authStateChanges();

  CollectionReference<Map<String, dynamic>> get _usersRef =>
      _firestore.collection(AppStrings.collectionUsers);

  Stream<AppUserModel?> watchUserProfile(String uid) {
    return _usersRef.doc(uid).snapshots().map((snap) {
      if (!snap.exists || snap.data() == null) return null;
      return AppUserModel.fromMap(snap.data()!, uid);
    });
  }

  Future<AppUserModel?> getUserProfile(String uid) async {
    final doc = await _usersRef.doc(uid).get();
    if (!doc.exists || doc.data() == null) return null;
    return AppUserModel.fromMap(doc.data()!, uid);
  }

  /// Creates the Firestore `users/{uid}` profile document with the
  /// ₹1,00,000 starting virtual balance. Called once, right after a
  /// successful sign-up (email or Google) — never overwrites an existing
  /// profile, so returning users keep their real balance.
  Future<AppUserModel> createUserProfileIfNotExists({
    required String uid,
    required String email,
    required String displayName,
    String? photoUrl,
  }) async {
    final docRef = _usersRef.doc(uid);
    final existing = await docRef.get();

    if (existing.exists && existing.data() != null) {
      return AppUserModel.fromMap(existing.data()!, uid);
    }

    final newUser = AppUserModel(
      uid: uid,
      email: email,
      displayName: displayName,
      photoUrl: photoUrl,
      emailVerified: _auth.currentUser?.emailVerified ?? false,
      virtualBalance: AppStrings.startingVirtualBalance,
      createdAt: DateTime.now(),
    );

    await docRef.set(newUser.toMap());
    return newUser;
  }

  Future<fb.UserCredential> signUpWithEmail({
    required String email,
    required String password,
  }) {
    return _auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );
  }

  Future<fb.UserCredential> signInWithEmail({
    required String email,
    required String password,
  }) {
    return _auth.signInWithEmailAndPassword(email: email, password: password);
  }

  Future<fb.UserCredential> signInWithGoogle() async {
    final googleUser = await _googleSignIn.signIn();
    if (googleUser == null) {
      throw fb.FirebaseAuthException(
        code: 'google-sign-in-cancelled',
        message: 'Google sign-in was cancelled.',
      );
    }
    final googleAuth = await googleUser.authentication;
    final credential = fb.GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );
    return _auth.signInWithCredential(credential);
  }

  Future<void> sendPasswordResetEmail(String email) {
    return _auth.sendPasswordResetEmail(email: email);
  }

  Future<void> sendEmailVerification() async {
    final user = _auth.currentUser;
    if (user != null && !user.emailVerified) {
      await user.sendEmailVerification();
    }
  }

  Future<bool> reloadAndCheckEmailVerified() async {
    await _auth.currentUser?.reload();
    return _auth.currentUser?.emailVerified ?? false;
  }

  /// Syncs FirebaseAuth's `emailVerified` flag into the Firestore profile
  /// once verification completes, so the rest of the app can read it
  /// straight from the profile stream without re-checking FirebaseAuth.
  Future<void> syncEmailVerifiedFlag(String uid, bool verified) {
    return _usersRef.doc(uid).update({'emailVerified': verified});
  }

  Future<void> signOut() async {
    await Future.wait([
      _auth.signOut(),
      _googleSignIn.signOut(),
    ]);
  }
}
