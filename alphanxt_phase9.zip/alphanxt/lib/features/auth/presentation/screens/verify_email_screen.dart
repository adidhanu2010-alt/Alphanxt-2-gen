import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/widgets/app_snackbar.dart';
import '../../../../core/widgets/primary_button.dart';
import '../providers/auth_providers.dart';

/// Shown right after registration until the user clicks the verification
/// link in their email. Polls FirebaseAuth every few seconds so the app
/// auto-advances to Home the moment verification completes — no manual
/// "I've verified" button needed.
class VerifyEmailScreen extends ConsumerStatefulWidget {
  const VerifyEmailScreen({super.key});

  @override
  ConsumerState<VerifyEmailScreen> createState() => _VerifyEmailScreenState();
}

class _VerifyEmailScreenState extends ConsumerState<VerifyEmailScreen> {
  Timer? _pollTimer;
  int _resendCooldown = 0;
  Timer? _cooldownTimer;

  @override
  void initState() {
    super.initState();
    _pollTimer = Timer.periodic(const Duration(seconds: 4), (_) {
      // Router redirect reacts automatically once currentUserProfileProvider
      // reflects emailVerified == true (synced inside checkEmailVerified).
      ref.read(authControllerProvider.notifier).checkEmailVerified();
    });
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _cooldownTimer?.cancel();
    super.dispose();
  }

  Future<void> _resend() async {
    final controller = ref.read(authControllerProvider.notifier);
    final success = await controller.resendVerificationEmail();
    if (!mounted) return;
    if (success) {
      AppSnackbar.success(context, 'Verification email resent.');
      setState(() => _resendCooldown = 30);
      _cooldownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
        if (_resendCooldown <= 1) {
          t.cancel();
          setState(() => _resendCooldown = 0);
        } else {
          setState(() => _resendCooldown -= 1);
        }
      });
    } else {
      final error = ref.read(authControllerProvider).errorMessage;
      if (error != null) AppSnackbar.error(context, error);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final actionState = ref.watch(authControllerProvider);
    final email =
        ref.watch(currentUserProfileProvider).value?.email ?? 'your email';

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: AppDimens.space24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 96,
                width: 96,
                decoration: BoxDecoration(
                  color: AppColors.primary.withValues(alpha: 0.12),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.mark_email_unread_rounded,
                  color: AppColors.primary,
                  size: 48,
                ),
              ).animate().scale(duration: 400.ms, curve: Curves.easeOutBack),
              const SizedBox(height: AppDimens.space24),
              Text(
                AppStrings.verifyEmailTitle,
                style: theme.textTheme.headlineSmall,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: AppDimens.space8),
              Text(
                "We've sent a verification link to $email. "
                "Please check your inbox — this page updates automatically "
                'once verified.',
                style: theme.textTheme.bodyMedium,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: AppDimens.space32),
              SizedBox(
                height: 20,
                width: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2.2,
                  valueColor: AlwaysStoppedAnimation<Color>(
                    theme.colorScheme.primary,
                  ),
                ),
              ),
              const SizedBox(height: AppDimens.space32),
              PrimaryButton(
                label: _resendCooldown > 0
                    ? 'Resend in ${_resendCooldown}s'
                    : 'Resend Email',
                isLoading: actionState.isLoading,
                onPressed: _resendCooldown > 0 ? null : _resend,
              ),
              const SizedBox(height: AppDimens.space16),
              TextButton(
                onPressed: () =>
                    ref.read(authControllerProvider.notifier).signOut(),
                child: const Text('Use a different account'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
