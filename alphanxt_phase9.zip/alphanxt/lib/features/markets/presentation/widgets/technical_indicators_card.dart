import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/utils/technical_indicators.dart';
import '../../domain/entities/candle_entity.dart';

/// Shows SMA(20), RSI(14), trend, and volatility computed live from the
/// asset's actual fetched price history — real math on real data, not
/// mocked values.
class TechnicalIndicatorsCard extends StatelessWidget {
  final List<PricePointEntity> priceHistory;

  const TechnicalIndicatorsCard({super.key, required this.priceHistory});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final closes = priceHistory.map((p) => p.price).toList();

    final sma20 = TechnicalIndicators.sma(closes, 20);
    final rsi14 = TechnicalIndicators.rsi(closes);
    final trend = TechnicalIndicators.trendLabel(closes);
    final volatility = TechnicalIndicators.volatilityPercent(closes);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Technical Indicators', style: theme.textTheme.titleSmall),
            const SizedBox(height: AppDimens.space16),
            Row(
              children: [
                Expanded(
                  child: _indicatorTile(
                    context,
                    label: 'Trend',
                    value: trend,
                    valueColor: trend == 'Uptrend'
                        ? AppColors.bullish
                        : trend == 'Downtrend'
                            ? AppColors.bearish
                            : null,
                  ),
                ),
                Expanded(
                  child: _indicatorTile(
                    context,
                    label: 'RSI (14)',
                    value: rsi14 == null ? '—' : rsi14.toStringAsFixed(1),
                    valueColor: rsi14 == null
                        ? null
                        : rsi14 > 70
                            ? AppColors.bearish
                            : rsi14 < 30
                                ? AppColors.bullish
                                : null,
                    subtitle: rsi14 == null
                        ? null
                        : rsi14 > 70
                            ? 'Overbought'
                            : rsi14 < 30
                                ? 'Oversold'
                                : 'Neutral',
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppDimens.space16),
            Row(
              children: [
                Expanded(
                  child: _indicatorTile(
                    context,
                    label: 'SMA (20)',
                    value: sma20 == null
                        ? '—'
                        : sma20.toStringAsFixed(sma20 > 100 ? 0 : 2),
                  ),
                ),
                Expanded(
                  child: _indicatorTile(
                    context,
                    label: 'Volatility',
                    value: volatility == null
                        ? '—'
                        : '${volatility.toStringAsFixed(2)}%',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _indicatorTile(
    BuildContext context, {
    required String label,
    required String value,
    Color? valueColor,
    String? subtitle,
  }) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: theme.textTheme.bodySmall),
        const SizedBox(height: 4),
        Text(
          value,
          style: theme.textTheme.titleMedium?.copyWith(color: valueColor),
        ),
        if (subtitle != null)
          Text(
            subtitle,
            style: theme.textTheme.bodySmall?.copyWith(color: valueColor),
          ),
      ],
    );
  }
}
