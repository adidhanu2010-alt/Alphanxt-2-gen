import '../../../../core/errors/result.dart';
import '../../../markets/domain/entities/asset_entity.dart';
import '../entities/order_enums.dart';
import '../entities/position_entity.dart';
import '../entities/transaction_entity.dart';

/// Contract for all paper-trading operations: placing orders, and
/// streaming positions/history.
///
/// IMPORTANT — client-side limit/SL/TP execution: AlphaNXT has no
/// backend server, so pending limit orders and stop-loss/take-profit
/// triggers are checked via [checkPendingTriggers], called whenever the
/// Paper Trade or Portfolio screens are open (and on a light interval
/// while they stay open). This means an order fills as soon as the
/// condition is met *while the app is being used* — it is NOT a
/// guaranteed real-time execution engine that fires while the app is
/// closed. A production system would run this same matching logic in a
/// scheduled Cloud Function against a live price feed instead. This
/// limitation is surfaced to the user in the Paper Trade UI copy.
abstract class TradingRepository {
  /// Places a market order — fills immediately at [currentMarketPrice].
  /// For a buy, [stopLoss]/[takeProfit] are attached to the resulting
  /// position. For a sell, [positionId] must reference the open position
  /// being reduced/closed.
  Future<Result<void>> placeMarketOrder({
    required String uid,
    required AssetEntity asset,
    required OrderSide side,
    required double quantity,
    required double currentMarketPrice,
    double? stopLoss,
    double? takeProfit,
    String? positionId,
  });

  /// Places a limit order — recorded as pending until
  /// [checkPendingTriggers] finds the market price has crossed
  /// [limitPrice].
  Future<Result<void>> placeLimitOrder({
    required String uid,
    required AssetEntity asset,
    required OrderSide side,
    required double quantity,
    required double limitPrice,
    double? stopLoss,
    double? takeProfit,
    String? positionId,
  });

  Future<Result<void>> cancelPendingOrder(String uid, String transactionId);

  /// Checks all of [uid]'s pending limit orders and open positions with
  /// stop-loss/take-profit against [latestPrices] (assetId -> current
  /// price), filling/closing anything whose condition is met. See class
  /// doc for the client-side execution caveat.
  Future<Result<void>> checkPendingTriggers({
    required String uid,
    required Map<String, double> latestPrices,
  });

  Stream<List<PositionEntity>> watchOpenPositions(String uid);
  Stream<List<PositionEntity>> watchClosedPositions(String uid);
  Stream<List<TransactionEntity>> watchPendingOrders(String uid);
  Stream<List<TransactionEntity>> watchTransactionHistory(String uid);
}
