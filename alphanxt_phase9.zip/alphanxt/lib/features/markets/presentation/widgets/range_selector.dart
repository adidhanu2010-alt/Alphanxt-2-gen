import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../domain/entities/chart_range.dart';

/// Row of tappable chips (1D / 1W / 1M / 3M / 1Y) for switching the
/// price chart's time range.
class RangeSelector extends StatelessWidget {
  final ChartRange selected;
  final ValueChanged<ChartRange> onSelected;

  const RangeSelector({super.key, required this.selected, required this.onSelected});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: ChartRange.values.map((range) {
        final isSelected = range == selected;
        return InkWell(
          borderRadius: BorderRadius.circular(AppDimens.radiusPill),
          onTap: () => onSelected(range),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.symmetric(
              horizontal: AppDimens.space16,
              vertical: AppDimens.space8,
            ),
            decoration: BoxDecoration(
              color: isSelected ? AppColors.primary : Colors.transparent,
              borderRadius: BorderRadius.circular(AppDimens.radiusPill),
            ),
            child: Text(
              range.label,
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: isSelected
                        ? Colors.white
                        : Theme.of(context).textTheme.bodySmall?.color,
                    fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                  ),
            ),
          ),
        );
      }).toList(),
    );
  }
}
