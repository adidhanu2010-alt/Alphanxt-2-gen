import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../../core/constants/app_strings.dart';
import '../../domain/entities/asset_entity.dart';

/// Firestore access for the `watchlist` collection.
///
/// Documents are keyed as `{uid}_{assetId}` so add/remove are simple
/// idempotent `set`/`delete` calls with no query needed, while
/// [watchWatchlistIds] still queries by `uid` to list everything a user
/// has saved.
class WatchlistRemoteDataSource {
  final FirebaseFirestore _firestore;

  WatchlistRemoteDataSource(this._firestore);

  CollectionReference<Map<String, dynamic>> get _ref =>
      _firestore.collection(AppStrings.collectionWatchlist);

  String _docId(String uid, String assetId) => '${uid}_$assetId';

  Stream<List<String>> watchWatchlistIds(String uid) {
    return _ref.where('uid', isEqualTo: uid).snapshots().map(
          (snap) => snap.docs
              .map((d) => d.data()['assetId'] as String? ?? '')
              .where((id) => id.isNotEmpty)
              .toList(),
        );
  }

  Future<void> addToWatchlist(String uid, AssetEntity asset) {
    return _ref.doc(_docId(uid, asset.id)).set({
      'uid': uid,
      'assetId': asset.id,
      'symbol': asset.symbol,
      'name': asset.name,
      'assetType': asset.type.name,
      'addedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> removeFromWatchlist(String uid, String assetId) {
    return _ref.doc(_docId(uid, assetId)).delete();
  }
}
