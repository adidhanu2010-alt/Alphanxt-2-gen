import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../../../../core/errors/result.dart';
import '../../data/datasources/auth_remote_datasource.dart';
import '../../data/repositories/auth_repository_impl.dart';
import '../../domain/entities/app_user_entity.dart';
import '../../domain/repositories/auth_repository.dart';

// ---------------- Firebase SDK instances ----------------

final firebaseAuthProvider = Provider<FirebaseAuth>((ref) {
  return FirebaseAuth.instance;
});

final firestoreProvider = Provider<FirebaseFirestore>((ref) {
  return FirebaseFirestore.instance;
});

final googleSignInProvider = Provider<GoogleSignIn>((ref) {
  return GoogleSignIn(scopes: ['email']);
});

// ---------------- Data / Repository ----------------

final authRemoteDataSourceProvider = Provider<AuthRemoteDataSource>((ref) {
  return AuthRemoteDataSource(
    auth: ref.watch(firebaseAuthProvider),
    firestore: ref.watch(firestoreProvider),
    googleSignIn: ref.watch(googleSignInProvider),
  );
});

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  return AuthRepositoryImpl(ref.watch(authRemoteDataSourceProvider));
});

// ---------------- Streams consumed by the UI / router ----------------

/// True while a user is signed in to Firebase Auth (regardless of email
/// verification). Used by the router's redirect guard.
final isSignedInProvider = StreamProvider<bool>((ref) {
  return ref.watch(authRepositoryProvider).isSignedInStream;
});

/// Live AlphaNXT profile (name, virtual balance, verification status,
/// etc.) for whoever is currently signed in. This is the single source
/// of truth the whole app reads the virtual balance from — updating in
/// real time as trades happen in later phases.
final currentUserProfileProvider = StreamProvider<AppUserEntity?>((ref) {
  return ref.watch(authRepositoryProvider).watchCurrentUserProfile();
});

// ---------------- Auth actions (login/register/etc) ----------------

/// UI-facing state for auth actions: idle, in-progress, or failed with
/// a human-readable message. Screens watch this to drive button loading
/// spinners and error banners.
class AuthActionState {
  final bool isLoading;
  final String? errorMessage;

  const AuthActionState({this.isLoading = false, this.errorMessage});

  static const idle = AuthActionState();
  static const loading = AuthActionState(isLoading: true);

  factory AuthActionState.error(String message) =>
      AuthActionState(errorMessage: message);
}

/// Drives all auth screens' actions (sign up, sign in, Google sign-in,
/// password reset, sign out). Screens call these methods and watch
/// [AuthActionState] for loading/error UI — actual navigation on success
/// happens via the router's redirect reacting to [isSignedInProvider].
class AuthController extends StateNotifier<AuthActionState> {
  final AuthRepository _repository;

  AuthController(this._repository) : super(AuthActionState.idle);

  Future<bool> signUp({
    required String name,
    required String email,
    required String password,
  }) async {
    state = AuthActionState.loading;
    final result = await _repository.signUp(
      name: name,
      email: email,
      password: password,
    );
    return _handle(result);
  }

  Future<bool> signIn({required String email, required String password}) async {
    state = AuthActionState.loading;
    final result = await _repository.signIn(email: email, password: password);
    return _handle(result);
  }

  Future<bool> signInWithGoogle() async {
    state = AuthActionState.loading;
    final result = await _repository.signInWithGoogle();
    return _handle(result);
  }

  Future<bool> sendPasswordResetEmail(String email) async {
    state = AuthActionState.loading;
    final result = await _repository.sendPasswordResetEmail(email);
    return _handle(result);
  }

  Future<bool> resendVerificationEmail() async {
    state = AuthActionState.loading;
    final result = await _repository.sendEmailVerification();
    return _handle(result);
  }

  Future<bool> checkEmailVerified() async {
    final result = await _repository.checkEmailVerified();
    return result.when(success: (verified) => verified, failure: (_) => false);
  }

  Future<void> signOut() async {
    state = AuthActionState.loading;
    await _repository.signOut();
    state = AuthActionState.idle;
  }

  bool _handle(Result<dynamic> result) {
    return result.when(
      success: (_) {
        state = AuthActionState.idle;
        return true;
      },
      failure: (f) {
        state = AuthActionState.error(f.message);
        return false;
      },
    );
  }
}

final authControllerProvider =
    StateNotifierProvider<AuthController, AuthActionState>((ref) {
  return AuthController(ref.watch(authRepositoryProvider));
});
