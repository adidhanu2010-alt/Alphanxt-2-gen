import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_dimens.dart';
import '../../../../core/widgets/app_snackbar.dart';
import '../../domain/entities/challenge_entity.dart';
import '../providers/challenges_providers.dart';
import '../widgets/challenge_card.dart';
import 'leaderboard_screen.dart';

class ChallengesScreen extends ConsumerStatefulWidget {
  const ChallengesScreen({super.key});

  @override
  ConsumerState<ChallengesScreen> createState() => _ChallengesScreenState();
}

class _ChallengesScreenState extends ConsumerState<ChallengesScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: ChallengePeriod.values.length, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final allProgress = ref.watch(challengeProgressProvider);
    final claimedIds = (ref.watch(claimedChallengesProvider).valueOrNull ?? [])
        .map((c) => '${c.challengeId}_${c.periodKey}')
        .toSet();
    final claimState = ref.watch(challengeClaimControllerProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Challenges'),
        bottom: TabBar(
          controller: _tabController,
          tabs: ChallengePeriod.values.map((p) => Tab(text: p.label)).toList(),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.leaderboard_rounded),
            tooltip: 'Leaderboard',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const LeaderboardScreen()),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: TabBarView(
          controller: _tabController,
          children: ChallengePeriod.values.map((period) {
            final items = allProgress.where((p) => p.definition.period == period).toList();
            return ListView(
              padding: const EdgeInsets.all(AppDimens.space16),
              children: items.map((progress) {
                final key = '${progress.definition.id}_${progress.periodKey}';
                final isClaimed = claimedIds.contains(key);
                return ChallengeCard(
                  progress: progress,
                  isClaimed: isClaimed,
                  isClaiming: claimState.isLoading,
                  onClaim: () async {
                    final success = await ref
                        .read(challengeClaimControllerProvider.notifier)
                        .claim(progress);
                    if (success && context.mounted) {
                      AppSnackbar.success(
                        context,
                        '+${progress.definition.xpReward} XP claimed!',
                      );
                    }
                  },
                );
              }).toList(),
            );
          }).toList(),
        ),
      ),
    );
  }
}
