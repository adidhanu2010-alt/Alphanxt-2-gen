import 'package:equatable/equatable.dart';

/// The kind of tradable asset. Currently only [crypto] has a live data
/// source wired up (via CoinGecko). [stock] is modeled now so equities
/// can be added later behind the same [MarketRepository] interface once
/// a licensed NSE/BSE data provider is integrated — see project README.
enum AssetType { crypto, stock }

/// Domain-layer representation of a tradable asset (market listing),
/// independent of which data provider it came from.
class AssetEntity extends Equatable {
  final String id;
  final String symbol;
  final String name;
  final String? imageUrl;
  final AssetType type;
  final double currentPrice;
  final double priceChangePercent24h;
  final double? marketCap;
  final double? totalVolume24h;
  final double? high24h;
  final double? low24h;

  /// Last ~7 days of prices for the mini sparkline chart in list tiles.
  final List<double> sparkline;

  const AssetEntity({
    required this.id,
    required this.symbol,
    required this.name,
    this.imageUrl,
    required this.type,
    required this.currentPrice,
    required this.priceChangePercent24h,
    this.marketCap,
    this.totalVolume24h,
    this.high24h,
    this.low24h,
    this.sparkline = const [],
  });

  bool get isPositive24h => priceChangePercent24h >= 0;

  @override
  List<Object?> get props => [
        id,
        symbol,
        name,
        imageUrl,
        type,
        currentPrice,
        priceChangePercent24h,
        marketCap,
        totalVolume24h,
        high24h,
        low24h,
        sparkline,
      ];
}
