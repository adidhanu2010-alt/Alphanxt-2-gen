import '../../markets/domain/entities/candle_entity.dart';
import '../../paper_trade/domain/entities/position_entity.dart';
import '../../../core/utils/technical_indicators.dart';
import 'entities/trade_metrics.dart';

/// Computes [TradeMetrics] for a closed position from real data only.
///
/// Two known approximations, documented rather than hidden:
/// 1. **Position size %** uses the CURRENT total account value as the
///    denominator, not the account value at the moment the trade was
///    opened (AlphaNXT doesn't retroactively track historical balance
///    per-trade). For most learners this is still a directionally
///    useful number; it's labeled as an approximation in the UI.
/// 2. **Trend / volatility** are computed from price history covering
///    the holding period (fetched from the same real market data used
///    everywhere else in the app), using the same [TechnicalIndicators]
///    math as the Markets feature.
class TradeMetricsCalculator {
  TradeMetricsCalculator._();

  static TradeMetrics calculate({
    required PositionEntity closedPosition,
    required List<PricePointEntity> priceHistoryDuringHold,
    required double currentTotalAccountValue,
  }) {
    final entry = closedPosition.avgBuyPrice;
    final exit = closedPosition.closePrice ?? entry;
    final quantity = closedPosition.quantity == 0
        ? 1.0 // fully-closed positions zero out quantity; use 1 unit basis
        : closedPosition.quantity;

    double? riskPercent;
    double? rewardRisk;
    if (closedPosition.stopLoss != null && entry > closedPosition.stopLoss!) {
      final riskPerUnit = entry - closedPosition.stopLoss!;
      riskPercent = (riskPerUnit / entry) * 100;
      if (closedPosition.takeProfit != null) {
        final rewardPerUnit = closedPosition.takeProfit! - entry;
        rewardRisk = riskPerUnit == 0 ? null : rewardPerUnit / riskPerUnit;
      }
    }

    final closes = priceHistoryDuringHold.map((p) => p.price).toList();
    final trend = TechnicalIndicators.trendLabel(closes);
    final volatility = TechnicalIndicators.volatilityPercent(closes);

    final positionSizeValue = entry * quantity;
    final positionSizePercent = currentTotalAccountValue <= 0
        ? 0.0
        : (positionSizeValue / currentTotalAccountValue) * 100;

    final holdingTime = (closedPosition.closedAt ?? closedPosition.openedAt)
        .difference(closedPosition.openedAt);

    return TradeMetrics(
      entryPrice: entry,
      exitPrice: exit,
      stopLoss: closedPosition.stopLoss,
      takeProfit: closedPosition.takeProfit,
      riskPercent: riskPercent,
      rewardRiskRatio: rewardRisk,
      trend: trend,
      holdingTime: holdingTime,
      positionSizeValue: positionSizeValue,
      positionSizePercent: positionSizePercent,
      volatilityPercent: volatility,
      realizedPnl: closedPosition.realizedPnl,
      realizedPnlPercent:
          entry == 0 ? 0 : ((exit - entry) / entry) * 100,
      quantity: quantity,
    );
  }
}
