import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/portfolio_snapshot_entity.dart';

class PortfolioSnapshotModel extends PortfolioSnapshotEntity {
  const PortfolioSnapshotModel({
    required super.date,
    required super.totalValue,
    required super.cashBalance,
    required super.investedValue,
  });

  factory PortfolioSnapshotModel.fromMap(Map<String, dynamic> map) {
    return PortfolioSnapshotModel(
      date: (map['date'] as Timestamp).toDate(),
      totalValue: (map['totalValue'] as num?)?.toDouble() ?? 0,
      cashBalance: (map['cashBalance'] as num?)?.toDouble() ?? 0,
      investedValue: (map['investedValue'] as num?)?.toDouble() ?? 0,
    );
  }

  Map<String, dynamic> toMap(String uid) {
    return {
      'uid': uid,
      'type': 'snapshot',
      'date': Timestamp.fromDate(DateTime(date.year, date.month, date.day)),
      'totalValue': totalValue,
      'cashBalance': cashBalance,
      'investedValue': investedValue,
    };
  }
}
