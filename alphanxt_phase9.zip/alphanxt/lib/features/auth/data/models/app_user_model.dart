import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/app_user_entity.dart';

/// Data-layer model — adds Firestore (de)serialization on top of the
/// domain [AppUserEntity]. Only the data layer (repositories/datasources)
/// should ever construct or read this class directly.
class AppUserModel extends AppUserEntity {
  const AppUserModel({
    required super.uid,
    required super.email,
    required super.displayName,
    super.photoUrl,
    required super.emailVerified,
    required super.virtualBalance,
    required super.createdAt,
  });

  factory AppUserModel.fromMap(Map<String, dynamic> map, String uid) {
    return AppUserModel(
      uid: uid,
      email: map['email'] as String? ?? '',
      displayName: map['displayName'] as String? ?? '',
      photoUrl: map['photoUrl'] as String?,
      emailVerified: map['emailVerified'] as bool? ?? false,
      virtualBalance: (map['virtualBalance'] as num?)?.toDouble() ?? 0.0,
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  factory AppUserModel.fromEntity(AppUserEntity entity) {
    return AppUserModel(
      uid: entity.uid,
      email: entity.email,
      displayName: entity.displayName,
      photoUrl: entity.photoUrl,
      emailVerified: entity.emailVerified,
      virtualBalance: entity.virtualBalance,
      createdAt: entity.createdAt,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'email': email,
      'displayName': displayName,
      'photoUrl': photoUrl,
      'emailVerified': emailVerified,
      'virtualBalance': virtualBalance,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }
}
