import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/asset_model.dart';
import '../models/asset_detail_model.dart';
import '../models/price_point_model.dart';

/// Raw HTTP calls to the CoinGecko public API (v3).
///
/// CoinGecko's free public tier requires no API key and has a stable,
/// well-documented schema — used here for real, live crypto market data
/// so Markets works out of the box with zero setup. All quotes are
/// requested in INR ([_vsCurrency]) to match AlphaNXT's virtual balance
/// currency.
///
/// NOTE: The free tier is rate-limited (roughly 10-30 requests/minute
/// per IP). For production scale, add a CoinGecko Pro API key via
/// `COINGECKO_API_KEY` in `.env` and attach it as the `x-cg-pro-api-key`
/// header — the call sites below are structured so that's a one-line
/// change in [_headers].
///
/// Equities (NSE/BSE) are NOT covered by this data source — real stock
/// market data generally requires a licensed/paid provider. See
/// [MarketRepository] docs for how to plug one in behind the same
/// interface without touching the UI.
class MarketRemoteDataSource {
  static const String _baseUrl = 'https://api.coingecko.com/api/v3';
  static const String _vsCurrency = 'inr';

  final http.Client _client;

  MarketRemoteDataSource({http.Client? client}) : _client = client ?? http.Client();

  Map<String, String> get _headers => const {'Accept': 'application/json'};

  Future<List<AssetModel>> getTrendingAssets({int limit = 50}) async {
    final uri = Uri.parse('$_baseUrl/coins/markets').replace(queryParameters: {
      'vs_currency': _vsCurrency,
      'order': 'market_cap_desc',
      'per_page': '$limit',
      'page': '1',
      'sparkline': 'true',
      'price_change_percentage': '24h',
    });

    final response = await _client.get(uri, headers: _headers);
    _throwIfError(response);

    final list = jsonDecode(response.body) as List;
    return list
        .map((e) => AssetModel.fromCoinGeckoMarket(e as Map<String, dynamic>))
        .toList();
  }

  Future<List<AssetModel>> getAssetsByIds(List<String> ids) async {
    if (ids.isEmpty) return [];
    final uri = Uri.parse('$_baseUrl/coins/markets').replace(queryParameters: {
      'vs_currency': _vsCurrency,
      'ids': ids.join(','),
      'sparkline': 'true',
      'price_change_percentage': '24h',
    });

    final response = await _client.get(uri, headers: _headers);
    _throwIfError(response);

    final list = jsonDecode(response.body) as List;
    return list
        .map((e) => AssetModel.fromCoinGeckoMarket(e as Map<String, dynamic>))
        .toList();
  }

  /// Two-step search: CoinGecko's `/search` endpoint returns matches
  /// without price data, so we follow up with a `/coins/markets?ids=`
  /// call to enrich the top matches with live price/24h-change data.
  Future<List<AssetModel>> searchAssets(String query) async {
    if (query.trim().isEmpty) return [];

    final searchUri =
        Uri.parse('$_baseUrl/search').replace(queryParameters: {'query': query});
    final searchResponse = await _client.get(searchUri, headers: _headers);
    _throwIfError(searchResponse);

    final searchJson = jsonDecode(searchResponse.body) as Map<String, dynamic>;
    final coins = (searchJson['coins'] as List?) ?? [];
    if (coins.isEmpty) return [];

    final ids = coins
        .take(15)
        .map((c) => (c as Map<String, dynamic>)['id'] as String)
        .toList();

    return getAssetsByIds(ids);
  }

  Future<AssetDetailModel> getAssetDetails(String assetId) async {
    final uri = Uri.parse('$_baseUrl/coins/$assetId').replace(queryParameters: {
      'localization': 'false',
      'tickers': 'false',
      'market_data': 'true',
      'community_data': 'false',
      'developer_data': 'false',
      'sparkline': 'false',
    });

    final response = await _client.get(uri, headers: _headers);
    _throwIfError(response);

    final json = jsonDecode(response.body) as Map<String, dynamic>;
    return AssetDetailModel.fromCoinGeckoDetail(json, vsCurrency: _vsCurrency);
  }

  Future<List<PricePointModel>> getPriceHistory(
    String assetId,
    int days,
  ) async {
    final uri = Uri.parse('$_baseUrl/coins/$assetId/market_chart')
        .replace(queryParameters: {
      'vs_currency': _vsCurrency,
      'days': '$days',
    });

    final response = await _client.get(uri, headers: _headers);
    _throwIfError(response);

    final json = jsonDecode(response.body) as Map<String, dynamic>;
    final prices = (json['prices'] as List?) ?? [];
    return prices
        .map((pair) => PricePointModel.fromCoinGeckoPair(pair as List))
        .toList();
  }

  void _throwIfError(http.Response response) {
    if (response.statusCode == 429) {
      throw Exception(
        'Market data rate limit reached — please wait a moment and try again.',
      );
    }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Market data request failed (${response.statusCode}).');
    }
  }
}
