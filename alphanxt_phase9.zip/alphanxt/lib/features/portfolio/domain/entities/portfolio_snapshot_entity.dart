import 'package:equatable/equatable.dart';

/// A single day's recorded portfolio value — the building block for the
/// Portfolio Value chart and (once at least 2 days exist) an accurate
/// Daily P/L figure on Home.
///
/// IMPORTANT — how this data accumulates: AlphaNXT has no backend
/// server, so a snapshot is recorded client-side the first time the
/// Portfolio screen is opened on a given calendar day (idempotent — at
/// most one snapshot per user per day). This means the history builds
/// up genuinely from real values, but a day the user never opens the
/// app simply has no snapshot, rather than an interpolated/fake one. A
/// production system would instead run this on a scheduled Cloud
/// Function at a fixed time daily regardless of app usage.
class PortfolioSnapshotEntity extends Equatable {
  final DateTime date;
  final double totalValue;
  final double cashBalance;
  final double investedValue;

  const PortfolioSnapshotEntity({
    required this.date,
    required this.totalValue,
    required this.cashBalance,
    required this.investedValue,
  });

  @override
  List<Object?> get props => [date, totalValue, cashBalance, investedValue];
}
