import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../auth/presentation/providers/auth_providers.dart';
import '../../../markets/presentation/providers/market_providers.dart';
import '../../../paper_trade/domain/entities/order_enums.dart';
import '../../../paper_trade/domain/entities/position_entity.dart';
import '../../../paper_trade/domain/entities/transaction_entity.dart';
import '../../../paper_trade/presentation/providers/trading_providers.dart';
import '../../../portfolio/presentation/providers/portfolio_providers.dart';
import '../../data/datasources/ai_analysis_cache_datasource.dart';
import '../../data/datasources/claude_ai_datasource.dart';
import '../../data/repositories/ai_coach_repository_impl.dart';
import '../../domain/entities/trade_analysis_entity.dart';
import '../../domain/repositories/ai_coach_repository.dart';

/// Null when no API key is configured — repository/UI handle this
/// gracefully with a "not configured" state rather than crashing.
final claudeAiDataSourceProvider = Provider<ClaudeAiDataSource?>((ref) {
  final key = dotenv.env['AI_COACH_API_KEY'];
  if (key == null || key.trim().isEmpty) return null;
  return ClaudeAiDataSource(apiKey: key.trim());
});

final aiAnalysisCacheDataSourceProvider =
    Provider<AiAnalysisCacheDataSource>((ref) {
  return AiAnalysisCacheDataSource(ref.watch(firestoreProvider));
});

final aiCoachRepositoryProvider = Provider<AiCoachRepository>((ref) {
  return AiCoachRepositoryImpl(
    aiDataSource: ref.watch(claudeAiDataSourceProvider),
    cacheDataSource: ref.watch(aiAnalysisCacheDataSourceProvider),
    marketRepository: ref.watch(marketRepositoryProvider),
    getCurrentTotalAccountValue: () =>
        ref.read(portfolioSummaryProvider).totalValue,
  );
});

/// Finds the sell transaction that closed a given position, so the
/// analysis can be cached against a stable doc id. Falls back to null
/// if not found (e.g. data still syncing) — the UI shows a brief
/// "preparing" state in that case rather than erroring.
final closingTransactionProvider =
    Provider.autoDispose.family<TransactionEntity?, String>((ref, positionId) {
  final history = ref.watch(transactionHistoryProvider).valueOrNull ?? [];
  TransactionEntity? closingTxn;
  for (final t in history) {
    if (t.positionId == positionId && t.side == OrderSide.sell) {
      if (closingTxn == null || t.createdAt.isAfter(closingTxn.createdAt)) {
        closingTxn = t;
      }
    }
  }
  return closingTxn;
});

final tradeAnalysisProvider = FutureProvider.autoDispose
    .family<TradeAnalysisEntity, PositionEntity>((ref, position) async {
  final uid = ref.watch(authRepositoryProvider).currentUid;
  final closingTxn = ref.watch(closingTransactionProvider(position.id));

  if (uid == null || closingTxn == null) {
    throw Exception('Trade record not found yet — please try again shortly.');
  }

  final result = await ref.read(aiCoachRepositoryProvider).analyzeTrade(
        uid: uid,
        closedPosition: position,
        closingTransactionId: closingTxn.id,
      );

  return result.when(success: (a) => a, failure: (f) => throw Exception(f.message));
});
