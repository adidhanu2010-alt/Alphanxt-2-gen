import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/app_dimens.dart';
import '../../../../core/routing/route_names.dart';
import '../providers/market_providers.dart';
import '../widgets/asset_list_tile.dart';
import '../widgets/market_search_bar.dart';

class MarketsScreen extends ConsumerStatefulWidget {
  const MarketsScreen({super.key});

  @override
  ConsumerState<MarketsScreen> createState() => _MarketsScreenState();
}

class _MarketsScreenState extends ConsumerState<MarketsScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _openAsset(String assetId) {
    context.push(RouteNames.assetDetailPath(assetId));
  }

  @override
  Widget build(BuildContext context) {
    final query = ref.watch(searchQueryProvider);
    final isSearching = query.trim().isNotEmpty;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Markets'),
        bottom: isSearching
            ? null
            : TabBar(
                controller: _tabController,
                tabs: const [Tab(text: 'Trending'), Tab(text: 'Watchlist')],
              ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: AppDimens.space16),
          child: Column(
            children: [
              const SizedBox(height: AppDimens.space12),
              MarketSearchBar(
                controller: _searchController,
                onChanged: (v) =>
                    ref.read(searchQueryProvider.notifier).state = v,
                onClear: () => ref.read(searchQueryProvider.notifier).state = '',
              ),
              const SizedBox(height: AppDimens.space8),
              Expanded(
                child: isSearching
                    ? _buildSearchResults()
                    : TabBarView(
                        controller: _tabController,
                        children: [
                          _buildTrendingTab(),
                          _buildWatchlistTab(),
                        ],
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSearchResults() {
    final resultsAsync = ref.watch(searchResultsProvider);
    final watchlistIds = ref.watch(watchlistIdsProvider).valueOrNull ?? [];

    return resultsAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => _errorState(() => ref.invalidate(searchResultsProvider)),
      data: (assets) {
        if (assets.isEmpty) {
          return Center(
            child: Text(
              'No results found',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          );
        }
        return ListView.separated(
          itemCount: assets.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (context, i) {
            final asset = assets[i];
            return AssetListTile(
              asset: asset,
              onTap: () => _openAsset(asset.id),
              isWatchlisted: watchlistIds.contains(asset.id),
              onWatchlistTap: () => ref
                  .read(watchlistControllerProvider.notifier)
                  .toggle(asset, watchlistIds.contains(asset.id)),
            );
          },
        );
      },
    );
  }

  Widget _buildTrendingTab() {
    final trendingAsync = ref.watch(trendingAssetsProvider);
    final watchlistIds = ref.watch(watchlistIdsProvider).valueOrNull ?? [];

    return trendingAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => _errorState(() => ref.invalidate(trendingAssetsProvider)),
      data: (assets) => RefreshIndicator(
        onRefresh: () => ref.refresh(trendingAssetsProvider.future),
        child: ListView.separated(
          itemCount: assets.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (context, i) {
            final asset = assets[i];
            return AssetListTile(
              asset: asset,
              onTap: () => _openAsset(asset.id),
              isWatchlisted: watchlistIds.contains(asset.id),
              onWatchlistTap: () => ref
                  .read(watchlistControllerProvider.notifier)
                  .toggle(asset, watchlistIds.contains(asset.id)),
            );
          },
        ),
      ),
    );
  }

  Widget _buildWatchlistTab() {
    final watchlistAsync = ref.watch(watchlistAssetsProvider);

    return watchlistAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => _errorState(() => ref.invalidate(watchlistAssetsProvider)),
      data: (assets) {
        if (assets.isEmpty) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(AppDimens.space24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.bookmark_border_rounded,
                    size: 40,
                    color: Theme.of(context).textTheme.bodySmall?.color,
                  ),
                  const SizedBox(height: AppDimens.space12),
                  Text(
                    'Your watchlist is empty.\nTap the bookmark icon on any asset to add it.',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
          );
        }
        return RefreshIndicator(
          onRefresh: () => ref.refresh(watchlistAssetsProvider.future),
          child: ListView.separated(
            itemCount: assets.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, i) {
              final asset = assets[i];
              return AssetListTile(
                asset: asset,
                onTap: () => _openAsset(asset.id),
                isWatchlisted: true,
                onWatchlistTap: () => ref
                    .read(watchlistControllerProvider.notifier)
                    .toggle(asset, true),
              );
            },
          ),
        );
      },
    );
  }

  Widget _errorState(VoidCallback onRetry) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.cloud_off_rounded,
              size: 40,
              color: Theme.of(context).textTheme.bodySmall?.color,
            ),
            const SizedBox(height: AppDimens.space12),
            Text(
              'Could not load market data.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: AppDimens.space12),
            OutlinedButton(onPressed: onRetry, child: const Text('Retry')),
          ],
        ),
      ),
    );
  }
}
