import 'package:equatable/equatable.dart';
import 'order_enums.dart';

/// A single order/trade record — covers both pending limit orders and
/// filled market/limit executions, distinguished by [status].
///
/// This doubles as AlphaNXT's "orders" and "trade history" model, kept
/// in one Firestore collection (`transactions`) rather than a separate
/// `orders` collection, matching the collection set defined for this
/// project.
class TransactionEntity extends Equatable {
  final String id;
  final String uid;
  final String assetId;
  final String symbol;
  final String name;
  final String? imageUrl;
  final OrderSide side;
  final OrderType orderType;
  final TransactionStatus status;

  /// The limit price the user requested (null for market orders).
  final double? requestedPrice;

  /// The price the order actually filled at (null while pending).
  final double? executedPrice;

  final double quantity;

  /// Only set on buy orders — carried onto the resulting position.
  final double? stopLoss;
  final double? takeProfit;

  /// Only set on sell fills — the realized profit/loss from this
  /// specific sell, used by the AI Trading Coach in Phase 7.
  final double? realizedPnl;

  final String? positionId;
  final DateTime createdAt;
  final DateTime? filledAt;

  /// Set when a pending order is auto-cancelled (e.g. insufficient
  /// balance at fill time) — shown in the order's history entry so the
  /// user understands what happened.
  final String? cancelReason;

  const TransactionEntity({
    required this.id,
    required this.uid,
    required this.assetId,
    required this.symbol,
    required this.name,
    this.imageUrl,
    required this.side,
    required this.orderType,
    required this.status,
    this.requestedPrice,
    this.executedPrice,
    required this.quantity,
    this.stopLoss,
    this.takeProfit,
    this.realizedPnl,
    this.positionId,
    required this.createdAt,
    this.filledAt,
    this.cancelReason,
  });

  double? get totalValue =>
      executedPrice != null ? executedPrice! * quantity : null;

  @override
  List<Object?> get props => [
        id,
        uid,
        assetId,
        symbol,
        name,
        imageUrl,
        side,
        orderType,
        status,
        requestedPrice,
        executedPrice,
        quantity,
        stopLoss,
        takeProfit,
        realizedPnl,
        positionId,
        createdAt,
        filledAt,
        cancelReason,
      ];
}
