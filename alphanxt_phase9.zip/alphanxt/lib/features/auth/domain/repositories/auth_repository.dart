import '../../../../core/errors/result.dart';
import '../entities/app_user_entity.dart';

/// Contract for all authentication + user-profile operations.
///
/// The presentation layer (controllers/providers) depends only on this
/// interface — never on `AuthRepositoryImpl` or Firebase types directly —
/// so auth logic stays testable and swappable.
abstract class AuthRepository {
  /// Emits the raw signed-in/signed-out state. Used for routing guards.
  Stream<bool> get isSignedInStream;

  /// Currently signed-in user's uid, or null if signed out.
  String? get currentUid;

  /// Streams the live AlphaNXT user profile document (Firestore) for the
  /// currently signed-in user, including their live virtual balance.
  /// Emits null when signed out or the profile doesn't exist yet.
  Stream<AppUserEntity?> watchCurrentUserProfile();

  /// Registers a new account, creates their Firestore profile with the
  /// ₹1,00,000 starting virtual balance, and sends a verification email.
  Future<Result<AppUserEntity>> signUp({
    required String name,
    required String email,
    required String password,
  });

  Future<Result<AppUserEntity>> signIn({
    required String email,
    required String password,
  });

  /// Signs in (or registers, on first use) via Google. Creates the
  /// Firestore profile with the starting balance if one doesn't exist yet.
  Future<Result<AppUserEntity>> signInWithGoogle();

  Future<Result<void>> sendPasswordResetEmail(String email);

  Future<Result<void>> sendEmailVerification();

  /// Reloads the current FirebaseAuth user and returns whether their
  /// email is now verified — used for polling on the Verify Email screen.
  Future<Result<bool>> checkEmailVerified();

  Future<Result<void>> signOut();
}
