import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/utils/formatters.dart';
import '../providers/portfolio_providers.dart';

/// 2x2 grid: Total Value, Total P/L, Win Rate, Risk Score.
class PortfolioSummaryGrid extends StatelessWidget {
  final PortfolioSummary summary;
  final double? winRatePercent;
  final int totalClosedTrades;
  final double riskScore;
  final String riskLabel;

  const PortfolioSummaryGrid({
    super.key,
    required this.summary,
    required this.winRatePercent,
    required this.totalClosedTrades,
    required this.riskScore,
    required this.riskLabel,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _statCard(
                context,
                label: 'Total Value',
                value: Formatters.currency(summary.totalValue),
                icon: Icons.account_balance_wallet_rounded,
              ),
            ),
            const SizedBox(width: AppDimens.space12),
            Expanded(
              child: _statCard(
                context,
                label: 'Total P/L',
                value:
                    '${summary.totalPnl >= 0 ? '+' : ''}${Formatters.currency(summary.totalPnl)}',
                icon: Icons.trending_up_rounded,
                valueColor: summary.totalPnl >= 0 ? AppColors.bullish : AppColors.bearish,
              ),
            ),
          ],
        ),
        const SizedBox(height: AppDimens.space12),
        Row(
          children: [
            Expanded(
              child: _statCard(
                context,
                label: 'Win Rate',
                value: winRatePercent == null ? '—' : '${winRatePercent!.toStringAsFixed(0)}%',
                icon: Icons.track_changes_rounded,
                subtitle: totalClosedTrades == 0 ? 'No closed trades' : '$totalClosedTrades trades',
              ),
            ),
            const SizedBox(width: AppDimens.space12),
            Expanded(
              child: _statCard(
                context,
                label: 'Risk Score',
                value: summary.investedValue == 0 ? '—' : riskScore.toStringAsFixed(0),
                icon: Icons.shield_outlined,
                subtitle: summary.investedValue == 0 ? null : riskLabel,
                valueColor: summary.investedValue == 0
                    ? null
                    : riskScore < 33
                        ? AppColors.bullish
                        : riskScore < 66
                            ? AppColors.warning
                            : AppColors.bearish,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _statCard(
    BuildContext context, {
    required String label,
    required String value,
    required IconData icon,
    Color? valueColor,
    String? subtitle,
  }) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: AppDimens.iconSmall, color: theme.textTheme.bodySmall?.color),
                const SizedBox(width: AppDimens.space8),
                Text(label, style: theme.textTheme.labelMedium),
              ],
            ),
            const SizedBox(height: AppDimens.space12),
            Text(
              value,
              style: theme.textTheme.titleLarge?.copyWith(color: valueColor),
            ),
            if (subtitle != null)
              Text(subtitle, style: theme.textTheme.bodySmall?.copyWith(color: valueColor)),
          ],
        ),
      ),
    );
  }
}
