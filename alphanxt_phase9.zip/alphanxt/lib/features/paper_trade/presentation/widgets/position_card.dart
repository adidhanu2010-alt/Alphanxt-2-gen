import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/utils/formatters.dart';
import '../../domain/entities/position_entity.dart';

/// Card for an open position — live unrealized P/L against [currentPrice],
/// SL/TP badges if set, and a Sell button.
class PositionCard extends StatelessWidget {
  final PositionEntity position;
  final double? currentPrice;
  final VoidCallback onSell;

  const PositionCard({
    super.key,
    required this.position,
    required this.currentPrice,
    required this.onSell,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final price = currentPrice ?? position.avgBuyPrice;
    final pnl = position.unrealizedPnl(price);
    final pnlPercent = position.unrealizedPnlPercent(price);
    final isPositive = pnl >= 0;
    final color = isPositive ? AppColors.bullish : AppColors.bearish;

    return Card(
      margin: const EdgeInsets.only(bottom: AppDimens.space12),
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(position.name, style: theme.textTheme.titleSmall),
                      Text(
                        '${position.quantity.toStringAsFixed(6)} ${position.symbol}',
                        style: theme.textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(Formatters.currency(price), style: theme.textTheme.titleSmall),
                    Text(
                      '${isPositive ? '+' : ''}${Formatters.currency(pnl)} (${Formatters.percentSigned(pnlPercent)})',
                      style: theme.textTheme.bodySmall?.copyWith(color: color),
                    ),
                  ],
                ),
              ],
            ),
            if (position.stopLoss != null || position.takeProfit != null) ...[
              const SizedBox(height: AppDimens.space8),
              Wrap(
                spacing: AppDimens.space8,
                children: [
                  if (position.stopLoss != null)
                    _badge(context, 'SL ${Formatters.currency(position.stopLoss!)}',
                        AppColors.bearish),
                  if (position.takeProfit != null)
                    _badge(context, 'TP ${Formatters.currency(position.takeProfit!)}',
                        AppColors.bullish),
                ],
              ),
            ],
            const SizedBox(height: AppDimens.space12),
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Avg buy ${Formatters.currency(position.avgBuyPrice)}',
                    style: theme.textTheme.bodySmall,
                  ),
                ),
                OutlinedButton(
                  onPressed: onSell,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.danger,
                    side: const BorderSide(color: AppColors.danger),
                    minimumSize: const Size(0, 36),
                    padding: const EdgeInsets.symmetric(horizontal: AppDimens.space16),
                  ),
                  child: const Text('Sell'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _badge(BuildContext context, String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(AppDimens.radiusSmall),
      ),
      child: Text(
        text,
        style: Theme.of(context)
            .textTheme
            .labelSmall
            ?.copyWith(color: color, fontWeight: FontWeight.w700),
      ),
    );
  }
}
