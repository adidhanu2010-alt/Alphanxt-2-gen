import 'package:equatable/equatable.dart';
import 'order_enums.dart';

/// A holding resulting from one or more buy fills on the same asset.
///
/// AlphaNXT uses a simple average-cost, single-open-position-per-asset
/// model (no per-lot tracking, no shorting) — the standard approach for
/// beginner-focused paper trading education. Buys average into
/// [avgBuyPrice]; sells reduce [quantity] and realize P/L against that
/// average; the position closes when quantity reaches zero.
class PositionEntity extends Equatable {
  final String id;
  final String uid;
  final String assetId;
  final String symbol;
  final String name;
  final String? imageUrl;
  final double quantity;
  final double avgBuyPrice;
  final double? stopLoss;
  final double? takeProfit;
  final PositionStatus status;
  final DateTime openedAt;
  final DateTime? closedAt;
  final double? closePrice;

  /// Sum of realized P/L from all partial/full sells against this
  /// position so far (0 while fully open with no sells yet).
  final double realizedPnl;

  const PositionEntity({
    required this.id,
    required this.uid,
    required this.assetId,
    required this.symbol,
    required this.name,
    this.imageUrl,
    required this.quantity,
    required this.avgBuyPrice,
    this.stopLoss,
    this.takeProfit,
    required this.status,
    required this.openedAt,
    this.closedAt,
    this.closePrice,
    this.realizedPnl = 0,
  });

  double get costBasis => quantity * avgBuyPrice;

  double unrealizedPnl(double currentPrice) =>
      (currentPrice - avgBuyPrice) * quantity;

  double unrealizedPnlPercent(double currentPrice) =>
      avgBuyPrice == 0 ? 0 : (currentPrice - avgBuyPrice) / avgBuyPrice;

  double marketValue(double currentPrice) => quantity * currentPrice;

  @override
  List<Object?> get props => [
        id,
        uid,
        assetId,
        symbol,
        name,
        imageUrl,
        quantity,
        avgBuyPrice,
        stopLoss,
        takeProfit,
        status,
        openedAt,
        closedAt,
        closePrice,
        realizedPnl,
      ];
}
