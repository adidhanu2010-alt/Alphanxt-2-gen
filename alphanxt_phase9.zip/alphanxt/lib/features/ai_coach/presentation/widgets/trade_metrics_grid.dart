import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/utils/formatters.dart';
import '../../domain/entities/trade_metrics.dart';

/// Displays every real metric the AI Coach's narrative is built from —
/// entry, exit, SL/TP, risk %, reward:risk, trend, holding time,
/// position size, volatility — so the user can see the coach isn't
/// working from a black box.
class TradeMetricsGrid extends StatelessWidget {
  final TradeMetrics metrics;

  const TradeMetricsGrid({super.key, required this.metrics});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isPositive = metrics.realizedPnl >= 0;

    final items = <(String, String, Color?)>[
      ('Entry', Formatters.currency(metrics.entryPrice), null),
      ('Exit', Formatters.currency(metrics.exitPrice), null),
      (
        'Realized P/L',
        '${isPositive ? '+' : ''}${Formatters.currency(metrics.realizedPnl)}',
        isPositive ? AppColors.bullish : AppColors.bearish,
      ),
      (
        'Stop Loss',
        metrics.stopLoss == null ? 'Not set' : Formatters.currency(metrics.stopLoss!),
        null,
      ),
      (
        'Take Profit',
        metrics.takeProfit == null ? 'Not set' : Formatters.currency(metrics.takeProfit!),
        null,
      ),
      (
        'Risk %',
        metrics.riskPercent == null ? '—' : '${metrics.riskPercent!.toStringAsFixed(1)}%',
        null,
      ),
      (
        'Reward:Risk',
        metrics.rewardRiskRatio == null
            ? '—'
            : '1:${metrics.rewardRiskRatio!.toStringAsFixed(2)}',
        null,
      ),
      ('Trend', metrics.trend, null),
      ('Holding Time', Formatters.holdingDuration(metrics.holdingTime), null),
      (
        'Position Size',
        '${Formatters.currency(metrics.positionSizeValue)} (~${metrics.positionSizePercent.toStringAsFixed(1)}%)',
        null,
      ),
      (
        'Volatility',
        metrics.volatilityPercent == null
            ? '—'
            : '${metrics.volatilityPercent!.toStringAsFixed(2)}%',
        null,
      ),
    ];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Trade Metrics', style: theme.textTheme.titleSmall),
            const SizedBox(height: AppDimens.space16),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: AppDimens.space16,
                crossAxisSpacing: AppDimens.space12,
                childAspectRatio: 2.6,
              ),
              itemCount: items.length,
              itemBuilder: (context, i) {
                final (label, value, color) = items[i];
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label, style: theme.textTheme.bodySmall),
                    const SizedBox(height: 2),
                    Text(
                      value,
                      style: theme.textTheme.titleSmall?.copyWith(color: color),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
