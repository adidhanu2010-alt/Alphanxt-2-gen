import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/app_dimens.dart';
import '../../../../core/routing/route_names.dart';
import '../../../paper_trade/presentation/providers/trading_providers.dart';
import '../../../paper_trade/presentation/widgets/position_card.dart';
import '../providers/portfolio_providers.dart';
import '../widgets/allocation_pie_chart.dart';
import '../widgets/portfolio_summary_grid.dart';
import '../widgets/portfolio_value_chart.dart';
import '../widgets/risk_score_gauge.dart';

class PortfolioScreen extends ConsumerWidget {
  const PortfolioScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Keeps SL/TP + pending limit orders checked while Portfolio is open too.
    ref.watch(triggerCheckerProvider);
    // Records today's value snapshot once, if not already recorded.
    ref.watch(snapshotRecorderProvider);

    final summary = ref.watch(portfolioSummaryProvider);
    final risk = ref.watch(riskScoreProvider);
    final closedPositions = ref.watch(closedPositionsProvider).value ?? [];
    final openPositionsAsync = ref.watch(openPositionsProvider);
    final marketData = ref.watch(heldAssetMarketDataProvider).value ?? {};
    final snapshotsAsync = ref.watch(portfolioSnapshotsProvider);

    final wins = closedPositions.where((p) => p.realizedPnl > 0).length;
    final winRate = closedPositions.isEmpty ? null : (wins / closedPositions.length) * 100;

    return Scaffold(
      appBar: AppBar(title: const Text('Portfolio')),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async {
            ref.invalidate(openPositionsProvider);
            ref.invalidate(heldAssetMarketDataProvider);
          },
          child: ListView(
            padding: const EdgeInsets.all(AppDimens.space16),
            children: [
              PortfolioSummaryGrid(
                summary: summary,
                winRatePercent: winRate,
                totalClosedTrades: closedPositions.length,
                riskScore: risk.score,
                riskLabel: risk.label,
              ),
              const SizedBox(height: AppDimens.space16),

              snapshotsAsync.when(
                loading: () => const SizedBox(
                  height: 100,
                  child: Center(child: CircularProgressIndicator()),
                ),
                error: (e, _) => const SizedBox.shrink(),
                data: (snapshots) => PortfolioValueChart(snapshots: snapshots),
              ),
              const SizedBox(height: AppDimens.space16),

              openPositionsAsync.maybeWhen(
                data: (positions) => AllocationPieChart(
                  positions: positions,
                  currentPrices: {
                    for (final e in marketData.entries) e.key: e.value.price
                  },
                ),
                orElse: () => const SizedBox.shrink(),
              ),
              const SizedBox(height: AppDimens.space16),

              RiskScoreGauge(
                result: risk,
                hasHoldings: summary.investedValue > 0,
              ),
              const SizedBox(height: AppDimens.space20),

              Text('Holdings', style: Theme.of(context).textTheme.titleSmall),
              const SizedBox(height: AppDimens.space12),
              openPositionsAsync.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (e, _) => Text(
                  'Could not load holdings.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                data: (positions) {
                  if (positions.isEmpty) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: AppDimens.space16),
                      child: Column(
                        children: [
                          Text(
                            "You don't have any open positions yet.",
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                          const SizedBox(height: AppDimens.space12),
                          OutlinedButton(
                            onPressed: () => context.go(RouteNames.markets),
                            child: const Text('Browse Markets'),
                          ),
                        ],
                      ),
                    );
                  }
                  return Column(
                    children: positions
                        .map((p) => PositionCard(
                              position: p,
                              currentPrice: marketData[p.assetId]?.price,
                              onSell: () => context.push(
                                RouteNames.tradeFormPath(p.assetId, side: 'sell'),
                              ),
                            ))
                        .toList(),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
