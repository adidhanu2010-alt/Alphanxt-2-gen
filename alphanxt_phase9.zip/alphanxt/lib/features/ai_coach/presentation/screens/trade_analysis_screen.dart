import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimens.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../paper_trade/domain/entities/position_entity.dart';
import '../providers/ai_coach_providers.dart';
import '../widgets/coach_section_card.dart';
import '../widgets/trade_metrics_grid.dart';

class TradeAnalysisScreen extends ConsumerWidget {
  final PositionEntity position;

  const TradeAnalysisScreen({super.key, required this.position});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final analysisAsync = ref.watch(tradeAnalysisProvider(position));
    final theme = Theme.of(context);
    final isPositive = position.realizedPnl >= 0;

    return Scaffold(
      appBar: AppBar(
        title: Text('${position.symbol} Trade Analysis'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            tooltip: 'Regenerate analysis',
            onPressed: () => ref.invalidate(tradeAnalysisProvider(position)),
          ),
        ],
      ),
      body: SafeArea(
        child: analysisAsync.when(
          loading: () => Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const CircularProgressIndicator(),
                const SizedBox(height: AppDimens.space16),
                Text(
                  'Your AI Coach is reviewing this trade…',
                  style: theme.textTheme.bodyMedium,
                ),
              ],
            ),
          ),
          error: (e, _) => Center(
            child: Padding(
              padding: const EdgeInsets.all(AppDimens.space24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.smart_toy_outlined, size: 40),
                  const SizedBox(height: AppDimens.space12),
                  Text(
                    e.toString().replaceFirst('Exception: ', ''),
                    textAlign: TextAlign.center,
                    style: theme.textTheme.bodyMedium,
                  ),
                  const SizedBox(height: AppDimens.space16),
                  OutlinedButton(
                    onPressed: () => ref.invalidate(tradeAnalysisProvider(position)),
                    child: const Text('Retry'),
                  ),
                ],
              ),
            ),
          ),
          data: (analysis) => ListView(
            padding: const EdgeInsets.all(AppDimens.space16),
            children: [
              Container(
                padding: const EdgeInsets.all(AppDimens.space16),
                decoration: BoxDecoration(
                  color: (isPositive ? AppColors.bullish : AppColors.bearish)
                      .withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(AppDimens.radiusLarge),
                  border: Border.all(
                    color: (isPositive ? AppColors.bullish : AppColors.bearish)
                        .withValues(alpha: 0.25),
                  ),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.auto_awesome_rounded,
                      color: isPositive ? AppColors.bullish : AppColors.bearish,
                    ),
                    const SizedBox(width: AppDimens.space12),
                    Expanded(
                      child: Text(analysis.summary, style: theme.textTheme.bodyMedium),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppDimens.space16),

              TradeMetricsGrid(metrics: analysis.metrics),
              const SizedBox(height: AppDimens.space16),

              CoachSectionCard(
                title: 'What Went Well',
                icon: Icons.check_circle_outline_rounded,
                color: AppColors.bullish,
                items: analysis.whatWentWell,
              ),
              CoachSectionCard(
                title: 'Mistakes to Learn From',
                icon: Icons.error_outline_rounded,
                color: AppColors.bearish,
                items: analysis.mistakes,
              ),
              CoachSectionCard(
                title: 'Risk Management',
                icon: Icons.shield_outlined,
                color: AppColors.warning,
                items: analysis.riskManagementTips,
              ),
              CoachSectionCard(
                title: 'Entry & Exit Ideas',
                icon: Icons.timeline_rounded,
                color: AppColors.primary,
                items: analysis.entryExitTips,
              ),
              CoachSectionCard(
                title: 'Lessons for Next Time',
                icon: Icons.school_outlined,
                color: AppColors.secondary,
                items: analysis.lessons,
              ),

              const SizedBox(height: AppDimens.space8),
              Text(
                AppStrings.noGuaranteeDisclaimer,
                textAlign: TextAlign.center,
                style: theme.textTheme.bodySmall,
              ),
              const SizedBox(height: AppDimens.space16),
            ],
          ),
        ),
      ),
    );
  }
}
