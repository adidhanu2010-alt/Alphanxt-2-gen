import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../../core/constants/app_strings.dart';
import '../../../markets/domain/entities/asset_entity.dart';
import '../../domain/entities/order_enums.dart';
import '../models/position_model.dart';
import '../models/transaction_model.dart';

/// Thrown for trading-specific failures (insufficient balance, invalid
/// sell quantity, etc.) so the repository layer can map them to a
/// friendly [TradeFailure] message.
class TradingException implements Exception {
  final String message;
  const TradingException(this.message);
  @override
  String toString() => message;
}

/// Raw Firestore reads/writes for the paper-trading engine.
///
/// Buy and sell fills run inside a single [FirebaseFirestore.runTransaction]
/// so the user's balance, their position, and the trade record all update
/// atomically — no partial state if something fails mid-write.
///
/// KNOWN LIMITATION: finding "the current open position for this asset"
/// (for averaging into an existing buy) is a plain query run *before*
/// the transaction starts, because Firestore's mobile SDK transactions
/// only support `get()` on a known `DocumentReference`, not arbitrary
/// queries. For a single user acting from one device (the expected use
/// case here) this is safe in practice; a high-concurrency multi-device
/// system would want a Cloud Function-based order processor instead.
class TradingRemoteDataSource {
  final FirebaseFirestore _firestore;

  TradingRemoteDataSource(this._firestore);

  CollectionReference<Map<String, dynamic>> get _usersRef =>
      _firestore.collection(AppStrings.collectionUsers);
  CollectionReference<Map<String, dynamic>> get _portfolioRef =>
      _firestore.collection(AppStrings.collectionPortfolio);
  CollectionReference<Map<String, dynamic>> get _transactionsRef =>
      _firestore.collection(AppStrings.collectionTransactions);

  Future<DocumentSnapshot<Map<String, dynamic>>?> _findOpenPosition(
    String uid,
    String assetId,
  ) async {
    final query = await _portfolioRef
        .where('uid', isEqualTo: uid)
        .where('assetId', isEqualTo: assetId)
        .where('status', isEqualTo: 'open')
        .limit(1)
        .get();
    return query.docs.isEmpty ? null : query.docs.first;
  }

  // ---------------- Market Buy ----------------

  Future<void> executeMarketBuy({
    required String uid,
    required AssetEntity asset,
    required double quantity,
    required double price,
    double? stopLoss,
    double? takeProfit,
    OrderType orderType = OrderType.market,
    double? requestedPrice,
  }) async {
    final existing = await _findOpenPosition(uid, asset.id);
    final userRef = _usersRef.doc(uid);
    final positionRef =
        existing != null ? existing.reference : _portfolioRef.doc();
    final txnRef = _transactionsRef.doc();
    final now = DateTime.now();

    await _firestore.runTransaction((transaction) async {
      final userSnap = await transaction.get(userRef);
      final balance =
          (userSnap.data()?['virtualBalance'] as num?)?.toDouble() ?? 0;
      final cost = quantity * price;

      if (balance < cost) {
        throw const TradingException(
          'Insufficient virtual balance to place this order.',
        );
      }

      if (existing != null) {
        final data = existing.data()!;
        final oldQty = (data['quantity'] as num).toDouble();
        final oldAvg = (data['avgBuyPrice'] as num).toDouble();
        final newQty = oldQty + quantity;
        final newAvg = ((oldQty * oldAvg) + (quantity * price)) / newQty;

        transaction.update(positionRef, {
          'quantity': newQty,
          'avgBuyPrice': newAvg,
          if (stopLoss != null) 'stopLoss': stopLoss,
          if (takeProfit != null) 'takeProfit': takeProfit,
        });
      } else {
        final position = PositionModel(
          id: positionRef.id,
          uid: uid,
          assetId: asset.id,
          symbol: asset.symbol,
          name: asset.name,
          imageUrl: asset.imageUrl,
          quantity: quantity,
          avgBuyPrice: price,
          stopLoss: stopLoss,
          takeProfit: takeProfit,
          status: PositionStatus.open,
          openedAt: now,
        );
        transaction.set(positionRef, position.toMap());
      }

      transaction.update(userRef, {'virtualBalance': balance - cost});

      final txn = TransactionModel(
        id: txnRef.id,
        uid: uid,
        assetId: asset.id,
        symbol: asset.symbol,
        name: asset.name,
        imageUrl: asset.imageUrl,
        side: OrderSide.buy,
        orderType: orderType,
        status: TransactionStatus.filled,
        requestedPrice: requestedPrice,
        executedPrice: price,
        quantity: quantity,
        stopLoss: stopLoss,
        takeProfit: takeProfit,
        positionId: positionRef.id,
        createdAt: now,
        filledAt: now,
      );
      transaction.set(txnRef, txn.toMap());
    });
  }

  // ---------------- Market Sell ----------------

  Future<void> executeMarketSell({
    required String uid,
    required String positionId,
    required double quantity,
    required double price,
    OrderType orderType = OrderType.market,
    double? requestedPrice,
  }) async {
    final userRef = _usersRef.doc(uid);
    final positionRef = _portfolioRef.doc(positionId);
    final txnRef = _transactionsRef.doc();
    final now = DateTime.now();

    await _firestore.runTransaction((transaction) async {
      final positionSnap = await transaction.get(positionRef);
      if (!positionSnap.exists) {
        throw const TradingException('Position not found.');
      }
      final data = positionSnap.data()!;
      final ownedQty = (data['quantity'] as num).toDouble();
      final avgBuyPrice = (data['avgBuyPrice'] as num).toDouble();
      final existingRealized = (data['realizedPnl'] as num?)?.toDouble() ?? 0;
      final symbol = data['symbol'] as String? ?? '';
      final name = data['name'] as String? ?? '';
      final assetId = data['assetId'] as String? ?? '';
      final imageUrl = data['imageUrl'] as String?;

      if (quantity > ownedQty + 1e-8) {
        throw const TradingException('Cannot sell more than you own.');
      }

      final proceeds = quantity * price;
      final realizedThisSell = (price - avgBuyPrice) * quantity;
      final newQty = ownedQty - quantity;
      final isFullyClosed = newQty <= 1e-8;

      transaction.update(positionRef, {
        'quantity': isFullyClosed ? 0 : newQty,
        'realizedPnl': existingRealized + realizedThisSell,
        if (isFullyClosed) 'status': 'closed',
        if (isFullyClosed) 'closedAt': Timestamp.fromDate(now),
        if (isFullyClosed) 'closePrice': price,
      });

      final userSnap = await transaction.get(userRef);
      final balance =
          (userSnap.data()?['virtualBalance'] as num?)?.toDouble() ?? 0;
      transaction.update(userRef, {'virtualBalance': balance + proceeds});

      final txn = TransactionModel(
        id: txnRef.id,
        uid: uid,
        assetId: assetId,
        symbol: symbol,
        name: name,
        imageUrl: imageUrl,
        side: OrderSide.sell,
        orderType: orderType,
        status: TransactionStatus.filled,
        requestedPrice: requestedPrice,
        executedPrice: price,
        quantity: quantity,
        realizedPnl: realizedThisSell,
        positionId: positionId,
        createdAt: now,
        filledAt: now,
      );
      transaction.set(txnRef, txn.toMap());
    });
  }

  // ---------------- Limit Orders (pending) ----------------

  Future<String> createPendingOrder({
    required String uid,
    required AssetEntity asset,
    required OrderSide side,
    required double quantity,
    required double limitPrice,
    double? stopLoss,
    double? takeProfit,
    String? positionId,
  }) async {
    final txnRef = _transactionsRef.doc();
    final txn = TransactionModel(
      id: txnRef.id,
      uid: uid,
      assetId: asset.id,
      symbol: asset.symbol,
      name: asset.name,
      imageUrl: asset.imageUrl,
      side: side,
      orderType: OrderType.limit,
      status: TransactionStatus.pending,
      requestedPrice: limitPrice,
      quantity: quantity,
      stopLoss: stopLoss,
      takeProfit: takeProfit,
      positionId: positionId,
      createdAt: DateTime.now(),
    );
    await txnRef.set(txn.toMap());
    return txnRef.id;
  }

  Future<void> cancelPendingOrder(String transactionId, {String? reason}) {
    return _transactionsRef.doc(transactionId).update({
      'status': 'cancelled',
      if (reason != null) 'cancelReason': reason,
    });
  }

  /// Removes a pending order doc once it has filled — the fill itself is
  /// recorded as a brand-new 'filled' transaction by
  /// [executeMarketBuy]/[executeMarketSell], so the original pending
  /// record is no longer needed and should NOT be marked 'cancelled'
  /// (it wasn't cancelled, it filled).
  Future<void> deleteOrder(String transactionId) {
    return _transactionsRef.doc(transactionId).delete();
  }

  Future<List<TransactionModel>> getPendingOrders(String uid) async {
    final snap = await _transactionsRef
        .where('uid', isEqualTo: uid)
        .where('status', isEqualTo: 'pending')
        .get();
    return snap.docs
        .map((d) => TransactionModel.fromMap(d.data(), d.id))
        .toList();
  }

  Future<List<PositionModel>> getOpenPositionsWithTriggers(String uid) async {
    final snap = await _portfolioRef
        .where('uid', isEqualTo: uid)
        .where('status', isEqualTo: 'open')
        .get();
    return snap.docs
        .map((d) => PositionModel.fromMap(d.data(), d.id))
        .where((p) => p.stopLoss != null || p.takeProfit != null)
        .toList();
  }

  // ---------------- Streams ----------------

  Stream<List<PositionModel>> watchOpenPositions(String uid) {
    return _portfolioRef
        .where('uid', isEqualTo: uid)
        .where('status', isEqualTo: 'open')
        .snapshots()
        .map((snap) => snap.docs
            .map((d) => PositionModel.fromMap(d.data(), d.id))
            .toList()
          ..sort((a, b) => b.openedAt.compareTo(a.openedAt)));
  }

  Stream<List<PositionModel>> watchClosedPositions(String uid) {
    return _portfolioRef
        .where('uid', isEqualTo: uid)
        .where('status', isEqualTo: 'closed')
        .snapshots()
        .map((snap) => snap.docs
            .map((d) => PositionModel.fromMap(d.data(), d.id))
            .toList()
          ..sort((a, b) =>
              (b.closedAt ?? b.openedAt).compareTo(a.closedAt ?? a.openedAt)));
  }

  Stream<List<TransactionModel>> watchPendingOrders(String uid) {
    return _transactionsRef
        .where('uid', isEqualTo: uid)
        .where('status', isEqualTo: 'pending')
        .snapshots()
        .map((snap) => snap.docs
            .map((d) => TransactionModel.fromMap(d.data(), d.id))
            .toList()
          ..sort((a, b) => b.createdAt.compareTo(a.createdAt)));
  }

  Stream<List<TransactionModel>> watchTransactionHistory(String uid) {
    return _transactionsRef
        .where('uid', isEqualTo: uid)
        .where('status', whereIn: ['filled', 'cancelled'])
        .snapshots()
        .map((snap) => snap.docs
            .map((d) => TransactionModel.fromMap(d.data(), d.id))
            .toList()
          ..sort((a, b) =>
              (b.filledAt ?? b.createdAt).compareTo(a.filledAt ?? a.createdAt)));
  }
}
