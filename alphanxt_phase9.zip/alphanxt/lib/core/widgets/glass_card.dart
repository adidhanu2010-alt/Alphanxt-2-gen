import 'dart:ui';
import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_dimens.dart';

/// A reusable glassmorphism container — frosted-glass background with a
/// subtle border, used for hero stat cards (e.g. Home balance card,
/// Portfolio summary) where a premium, layered look is desired.
///
/// Kept as a hand-rolled BackdropFilter (rather than always depending on
/// the `glassmorphism` package) so it can sit directly on top of
/// gradients/images and remain themeable per light/dark mode.
class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double borderRadius;
  final Gradient? backgroundGradient;

  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(AppDimens.space20),
    this.borderRadius = AppDimens.radiusXLarge,
    this.backgroundGradient,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: AppDimens.glassBlurSigma,
          sigmaY: AppDimens.glassBlurSigma,
        ),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            gradient: backgroundGradient,
            color: backgroundGradient == null
                ? (isDark ? AppColors.glassDark : AppColors.glassLight)
                : null,
            borderRadius: BorderRadius.circular(borderRadius),
            border: Border.all(
              color: isDark
                  ? AppColors.glassBorderDark
                  : AppColors.glassBorderLight,
              width: AppDimens.glassBorderWidth,
            ),
          ),
          child: child,
        ),
      ),
    );
  }
}
