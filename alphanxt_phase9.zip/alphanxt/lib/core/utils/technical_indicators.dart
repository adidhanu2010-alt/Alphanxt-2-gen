/// Client-side technical indicator calculations, computed from real
/// historical price data returned by the market data provider.
///
/// Kept in `core/utils` (rather than the markets feature) since the same
/// math is reused by the AI Trading Coach in Phase 7 to describe a
/// trade's context (trend, volatility) at entry/exit time.
class TechnicalIndicators {
  TechnicalIndicators._();

  /// Simple Moving Average over the last [period] closes. Returns null
  /// if there isn't enough data yet.
  static double? sma(List<double> closes, int period) {
    if (closes.length < period) return null;
    final window = closes.sublist(closes.length - period);
    return window.reduce((a, b) => a + b) / period;
  }

  /// Exponential Moving Average over the full series, seeded with an SMA
  /// of the first [period] values.
  static double? ema(List<double> closes, int period) {
    if (closes.length < period) return null;
    final multiplier = 2 / (period + 1);
    double emaValue = closes.sublist(0, period).reduce((a, b) => a + b) / period;
    for (int i = period; i < closes.length; i++) {
      emaValue = (closes[i] - emaValue) * multiplier + emaValue;
    }
    return emaValue;
  }

  /// Relative Strength Index (Wilder's smoothing), standard 0-100 scale.
  /// Returns null if there isn't enough data (needs period + 1 closes).
  static double? rsi(List<double> closes, {int period = 14}) {
    if (closes.length < period + 1) return null;

    double gainSum = 0;
    double lossSum = 0;
    for (int i = 1; i <= period; i++) {
      final change = closes[i] - closes[i - 1];
      if (change >= 0) {
        gainSum += change;
      } else {
        lossSum -= change;
      }
    }
    double avgGain = gainSum / period;
    double avgLoss = lossSum / period;

    for (int i = period + 1; i < closes.length; i++) {
      final change = closes[i] - closes[i - 1];
      final gain = change > 0 ? change : 0.0;
      final loss = change < 0 ? -change : 0.0;
      avgGain = (avgGain * (period - 1) + gain) / period;
      avgLoss = (avgLoss * (period - 1) + loss) / period;
    }

    if (avgLoss == 0) return 100;
    final rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }

  /// Simple realized volatility proxy: standard deviation of daily
  /// percentage returns over the series, expressed as a percentage.
  static double? volatilityPercent(List<double> closes) {
    if (closes.length < 2) return null;
    final returns = <double>[];
    for (int i = 1; i < closes.length; i++) {
      if (closes[i - 1] == 0) continue;
      returns.add((closes[i] - closes[i - 1]) / closes[i - 1]);
    }
    if (returns.isEmpty) return null;
    final mean = returns.reduce((a, b) => a + b) / returns.length;
    final variance =
        returns.map((r) => (r - mean) * (r - mean)).reduce((a, b) => a + b) /
            returns.length;
    return (variance <= 0 ? 0 : _sqrt(variance)) * 100;
  }

  /// Basic trend label from price position relative to its SMA(20).
  static String trendLabel(List<double> closes) {
    final sma20 = sma(closes, 20);
    if (sma20 == null || closes.isEmpty) return 'Insufficient data';
    final last = closes.last;
    final diffPercent = ((last - sma20) / sma20) * 100;
    if (diffPercent > 2) return 'Uptrend';
    if (diffPercent < -2) return 'Downtrend';
    return 'Sideways';
  }

  static double _sqrt(double value) {
    if (value == 0) return 0;
    double x = value;
    double last;
    do {
      last = x;
      x = (x + value / x) / 2;
    } while ((x - last).abs() > 1e-9);
    return x;
  }
}
