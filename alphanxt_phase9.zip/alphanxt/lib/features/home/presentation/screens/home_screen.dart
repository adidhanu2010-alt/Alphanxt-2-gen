import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/app_dimens.dart';
import '../../../../core/routing/route_names.dart';
import '../../../auth/presentation/providers/auth_providers.dart';
import '../../../markets/presentation/providers/market_providers.dart';
import '../../../markets/presentation/widgets/asset_list_tile.dart';
import '../../../paper_trade/presentation/providers/trading_providers.dart';
import '../../../portfolio/domain/entities/portfolio_snapshot_entity.dart';
import '../../../portfolio/presentation/providers/portfolio_providers.dart';
import '../widgets/balance_hero_card.dart';
import '../widgets/coming_soon_section_card.dart';
import '../widgets/daily_pnl_card.dart';
import '../widgets/daily_tip_card.dart';
import '../widgets/win_rate_card.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  String _greeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileAsync = ref.watch(currentUserProfileProvider);
    final theme = Theme.of(context);

    // Ensures today's portfolio value snapshot gets recorded as soon as
    // the user opens the app, not only when they visit Portfolio — see
    // PortfolioSnapshotEntity docs for the recording mechanism.
    ref.watch(snapshotRecorderProvider);

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async {
            // currentUserProfileProvider is already a live Firestore
            // stream, so pull-to-refresh here is mostly a UX affordance;
            // real manual refresh becomes meaningful once Markets (Phase 4)
            // adds polled data.
            await Future.delayed(const Duration(milliseconds: 400));
          },
          child: ListView(
            padding: const EdgeInsets.fromLTRB(
              AppDimens.space20,
              AppDimens.space8,
              AppDimens.space20,
              AppDimens.space32,
            ),
            children: [
              // ---------------- Header ----------------
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_greeting(), style: theme.textTheme.bodyMedium),
                        Text(
                          profileAsync.value?.displayName.isNotEmpty == true
                              ? profileAsync.value!.displayName
                              : 'Trader',
                          style: theme.textTheme.headlineSmall,
                        ),
                      ],
                    ),
                  ),
                  InkWell(
                    borderRadius: BorderRadius.circular(100),
                    onTap: () => context.go(RouteNames.profile),
                    child: CircleAvatar(
                      radius: 22,
                      backgroundColor: theme.colorScheme.primary.withValues(alpha: 0.15),
                      backgroundImage: profileAsync.value?.photoUrl != null
                          ? NetworkImage(profileAsync.value!.photoUrl!)
                          : null,
                      child: profileAsync.value?.photoUrl == null
                          ? Icon(Icons.person_rounded, color: theme.colorScheme.primary)
                          : null,
                    ),
                  ),
                ],
              ).animate().fadeIn(duration: 300.ms),

              const SizedBox(height: AppDimens.space20),

              // ---------------- Balance Hero ----------------
              BalanceHeroCard(
                virtualBalance: profileAsync.value?.virtualBalance ?? 0,
                isLoading: profileAsync.isLoading,
              ).animate().fadeIn(delay: 80.ms, duration: 300.ms).slideY(begin: 0.06, end: 0),

              const SizedBox(height: AppDimens.space16),

              // ---------------- Stats Row ----------------
              Consumer(
                builder: (context, ref, _) {
                  final closed = ref.watch(closedPositionsProvider).value ?? [];
                  final wins = closed.where((p) => p.realizedPnl > 0).length;
                  final winRate =
                      closed.isEmpty ? null : (wins / closed.length) * 100;

                  // Real day-over-day P/L: today's total value vs. the
                  // most recent snapshot from a prior day. Zero/no-data
                  // until at least one prior day's snapshot exists — see
                  // PortfolioSnapshotEntity docs for why history only
                  // builds up on days the app is opened.
                  final summary = ref.watch(portfolioSummaryProvider);
                  final snapshots = ref.watch(portfolioSnapshotsProvider).value ?? [];
                  final today = DateTime.now();
                  PortfolioSnapshotEntity? priorSnapshot;
                  for (final s in snapshots.reversed) {
                    final isSameDay = s.date.year == today.year &&
                        s.date.month == today.month &&
                        s.date.day == today.day;
                    if (!isSameDay) {
                      priorSnapshot = s;
                      break;
                    }
                  }
                  final dailyPnl = priorSnapshot == null
                      ? 0.0
                      : summary.totalValue - priorSnapshot.totalValue;
                  final dailyPnlPercent = priorSnapshot == null || priorSnapshot.totalValue == 0
                      ? 0.0
                      : dailyPnl / priorSnapshot.totalValue;

                  return Row(
                    children: [
                      Expanded(
                        child: DailyPnlCard(
                          dailyPnl: dailyPnl,
                          dailyPnlPercent: dailyPnlPercent,
                        ),
                      ),
                      const SizedBox(width: AppDimens.space12),
                      Expanded(
                        child: WinRateCard(
                          winRatePercent: winRate,
                          totalTrades: closed.length,
                        ),
                      ),
                    ],
                  );
                },
              ).animate().fadeIn(delay: 140.ms, duration: 300.ms),

              const SizedBox(height: AppDimens.space16),

              // ---------------- AI Daily Tip ----------------
              const DailyTipCard().animate().fadeIn(delay: 180.ms, duration: 300.ms),

              const SizedBox(height: AppDimens.space16),

              // ---------------- Watchlist ----------------
              _buildWatchlistSection(context, ref)
                  .animate()
                  .fadeIn(delay: 220.ms, duration: 300.ms),

              const SizedBox(height: AppDimens.space16),

              // ---------------- Trending Assets ----------------
              _buildTrendingSection(context, ref)
                  .animate()
                  .fadeIn(delay: 260.ms, duration: 300.ms),

              const SizedBox(height: AppDimens.space16),

              // ---------------- Market News (needs a news API — future phase) ----------------
              const ComingSoonSectionCard(
                title: 'Market News',
                icon: Icons.newspaper_rounded,
                message: 'Market news will appear here once a news data source is connected.',
              ).animate().fadeIn(delay: 300.ms, duration: 300.ms),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildWatchlistSection(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final watchlistAsync = ref.watch(watchlistAssetsProvider);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.bookmark_outline_rounded,
                    size: AppDimens.iconSmall, color: theme.textTheme.bodySmall?.color),
                const SizedBox(width: AppDimens.space8),
                Text('Watchlist', style: theme.textTheme.labelMedium),
                const Spacer(),
                TextButton(
                  onPressed: () => context.go(RouteNames.markets),
                  child: const Text('View All'),
                ),
              ],
            ),
            watchlistAsync.when(
              loading: () => const Padding(
                padding: EdgeInsets.symmetric(vertical: AppDimens.space16),
                child: Center(child: CircularProgressIndicator()),
              ),
              error: (_, __) => Padding(
                padding: const EdgeInsets.symmetric(vertical: AppDimens.space12),
                child: Text('Could not load your watchlist.', style: theme.textTheme.bodySmall),
              ),
              data: (assets) {
                if (assets.isEmpty) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: AppDimens.space16),
                    child: Column(
                      children: [
                        Text(
                          'Add assets from Markets to track them here.',
                          textAlign: TextAlign.center,
                          style: theme.textTheme.bodySmall,
                        ),
                        const SizedBox(height: AppDimens.space8),
                        TextButton(
                          onPressed: () => context.go(RouteNames.markets),
                          child: const Text('Browse Markets'),
                        ),
                      ],
                    ),
                  );
                }
                final preview = assets.take(3).toList();
                return Column(
                  children: preview
                      .map((asset) => AssetListTile(
                            asset: asset,
                            onTap: () =>
                                context.push(RouteNames.assetDetailPath(asset.id)),
                          ))
                      .toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTrendingSection(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final trendingAsync = ref.watch(trendingAssetsProvider);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.space16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.trending_up_rounded,
                    size: AppDimens.iconSmall, color: theme.textTheme.bodySmall?.color),
                const SizedBox(width: AppDimens.space8),
                Text('Trending Assets', style: theme.textTheme.labelMedium),
                const Spacer(),
                TextButton(
                  onPressed: () => context.go(RouteNames.markets),
                  child: const Text('View All'),
                ),
              ],
            ),
            trendingAsync.when(
              loading: () => const Padding(
                padding: EdgeInsets.symmetric(vertical: AppDimens.space16),
                child: Center(child: CircularProgressIndicator()),
              ),
              error: (_, __) => Padding(
                padding: const EdgeInsets.symmetric(vertical: AppDimens.space12),
                child: Text('Could not load market data.', style: theme.textTheme.bodySmall),
              ),
              data: (assets) => Column(
                children: assets
                    .take(5)
                    .map((asset) => AssetListTile(
                          asset: asset,
                          onTap: () =>
                              context.push(RouteNames.assetDetailPath(asset.id)),
                        ))
                    .toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
